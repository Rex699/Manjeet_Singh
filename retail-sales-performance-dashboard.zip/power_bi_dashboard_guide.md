# Power BI Dashboard Guide: Retail Sales Performance Dashboard

This guide provides step-by-step, beginner-friendly instructions to import your generated Excel spreadsheet into **Power BI Desktop**, write the required DAX measures, and design an executive-level, interactive dashboard.

---

## Part 1: Importing Data into Power BI

1. **Launch Power BI Desktop**: Open Microsoft Power BI Desktop.
2. **Get Data**: On the Home tab of the ribbon, click **Get data** and select **Excel workbook**.
3. **Select Your File**: Locate and select your generated `retail_sales_dashboard.xlsx` file. Click **Open**.
4. **Navigator Panel**: 
   - You will see the worksheets in your workbook.
   - Select **Cleaned_Data** (this contains our formatted, tabular record set with custom columns).
   - Click **Transform Data** (highly recommended for Data Analysts!) to open the Power Query Editor.
5. **Data Cleaning & Types in Power Query**:
   - Verify that column headers are correct. If not, click **Use First Row as Headers** in the Home tab.
   - Check the Data Types:
     - `Order_ID` $\rightarrow$ Text
     - `Order_Date` $\rightarrow$ Date
     - `Customer_Name`, `Product`, `Category`, `Region`, `Salesperson`, `Payment_Method`, `Order_Status`, `Month` $\rightarrow$ Text
     - `Quantity` $\rightarrow$ Whole Number
     - `Unit_Price`, `Discount`, `Sales_Amount`, `Cost_Amount`, `Profit` $\rightarrow$ Fixed Decimal Number (Currency)
     - `Profit_Margin` $\rightarrow$ Percentage / Decimal Number
   - Click **Close & Apply** in the Home tab of Power Query to load the data into the Power BI Data Model.

---

## Part 2: Writing the DAX Measures

Creating explicit DAX measures is standard best practice for Business Analysts and Data Analysts. Follow these instructions to create them.

To create a measure: Right-click the **Cleaned_Data** table in the Data pane on the right side and select **New measure**. Enter these exact formulas:

### 1. Total Sales
*Calculates the overall revenue generated from completed and in-progress transactions.*
```dax
Total Sales = SUM(Cleaned_Data[Sales_Amount])
```
*Formatting: Set Format as **Currency ($)**, choosing **English (India) / ₹** or your standard local currency, with **0 decimal places**.*

### 2. Total Profit
*Calculates the net profit margin across all orders.*
```dax
Total Profit = SUM(Cleaned_Data[Profit])
```
*Formatting: Set Format as **Currency**, **0 decimal places**.*

### 3. Total Orders
*Counts the total number of transactions recorded.*
```dax
Total Orders = COUNTROWS(Cleaned_Data)
```
*Formatting: Set Format as **Whole Number** with comma separator.*

### 4. Average Order Value (AOV)
*Calculates the average amount spent per order transaction.*
```dax
Average Order Value = DIVIDE([Total Sales], [Total Orders], 0)
```
*Formatting: Set Format as **Currency**, **0 decimal places**.*

### 5. Profit Margin
*Calculates the overall profit rate as a percentage of sales.*
```dax
Profit Margin = DIVIDE([Total Profit], [Total Sales], 0)
```
*Formatting: Set Format as **Percentage (%)**, with **1 decimal place**.*

### 6. Completed Orders
*Filters the dataset to count only completed orders.*
```dax
Completed Orders = CALCULATE([Total Orders], Cleaned_Data[Order_Status] = "Completed")
```
*Formatting: Set Format as **Whole Number**.*

### 7. Returned Orders
*Filters the dataset to count returned orders (valuable for tracking reverse logistics).*
```dax
Returned Orders = CALCULATE([Total Orders], Cleaned_Data[Order_Status] = "Returned")
```
*Formatting: Set Format as **Whole Number**.*

### 8. Cancelled Orders
*Filters the dataset to count cancelled orders.*
```dax
Cancelled Orders = CALCULATE([Total Orders], Cleaned_Data[Order_Status] = "Cancelled")
```
*Formatting: Set Format as **Whole Number**.*

---

## Part 3: Designing the Visual Layout

We will build a professional, cohesive single-page layout. Use a **Slate Teal** theme (using soft greens, blues, and dark gray accents to mirror the Excel sheet).

### 1. Page Setup & Header
- Set Page size to standard 16:9.
- Insert a **Text Box** at the very top:
  - Text: `Retail Sales Performance Dashboard`
  - Style: Font **Segoe UI Semibold**, Size **18**, Color **White**, background filled with **Dark Slate Blue** or **Teal** (`#0D3C3E` or `#1F497D`).
  - Align: Left, with standard padding.

### 2. KPI Cards (Row 1)
Place five **Card** visuals across the top of the canvas, underneath the header banner:
- **Card 1 (Total Sales)**: Drag `[Total Sales]` measure. Set category label OFF. Add a title: `Total Sales`.
- **Card 2 (Total Profit)**: Drag `[Total Profit]` measure.
- **Card 3 (Total Orders)**: Drag `[Total Orders]` measure.
- **Card 4 (Average Order Value)**: Drag `[Average Order Value]` measure.
- **Card 5 (Profit Margin)**: Drag `[Profit Margin]` measure.
- *Visual Design:* Enable **Border** (light gray, 1px, rounded corners 4px) and **Shadow** (very soft) for a modern, crisp layout.

### 3. Slicers (Left Sidebar or Top Panel)
Add **Slicer** visuals to enable interactive filtering. Slicers make the dashboard dynamic for business executives:
- **Month Slicer**: Drag `Month` column. Set slicer style to **Tile** or **Dropdown** (Horizontal grid of months looks extremely clean!).
- **Region Slicer**: Drag `Region` column. Set slicer style to **Dropdown** or **Tile**.
- **Category Slicer**: Drag `Category` column. Set style to **Vertical List**.
- **Salesperson Slicer**: Drag `Salesperson` column. Set style to **Dropdown**.
- **Order Status Slicer**: Drag `Order_Status` column. Set style to **Tile**.

### 4. Interactive Charts (Main Canvas Grid)

#### Chart A: Monthly Sales Trend
- **Visual Type**: **Line Chart** or **Area Chart**
- **X-Axis**: `Month`
- **Y-Axis**: `[Total Sales]` and `[Total Profit]` (showing both on one chart reveals the sales-to-profit relationship over time!)
- **Formatting**: Set line colors to Teal (Sales) and Light Green (Profit). Enable **Data Labels** for key milestones.

#### Chart B: Regional Performance
- **Visual Type**: **Clustered Bar Chart** (Horizontal)
- **Y-Axis**: `Region`
- **X-Axis**: `[Total Sales]`
- **Tooltips**: Add `[Profit Margin]` to the tooltips so hovering reveals the regional profit rate.
- **Formatting**: Sort descending by sales. Highlight the leading region in Dark Blue and others in medium gray.

#### Chart C: Category Sales & Margin
- **Visual Type**: **Donut Chart** or **Treemap**
- **Legend / Group**: `Category`
- **Values**: `[Total Sales]`
- **Formatting**: Use distinct, soft corporate tones. Add Category + Percentage share as labels.

#### Chart D: Salesperson Performance
- **Visual Type**: **Clustered Column Chart** (Vertical)
- **X-Axis**: `Salesperson`
- **Y-Axis**: `[Total Sales]`
- **Legend**: `Order_Status` or show `[Total Profit]` in tooltips.
- **Formatting**: Sort descending to immediately spot who the star performer is!

#### Chart E: Top Five Products
- **Visual Type**: **Bar Chart** (Horizontal)
- **Filters Pane**: Drag `Product` to the Filters card, set Filter type to **Top N**, enter **5**, and show items by value **Total Sales**. Click **Apply Filter**.
- **Y-Axis**: `Product`
- **X-Axis**: `[Total Sales]`

#### Chart F: Order Status Distribution
- **Visual Type**: **Donut Chart**
- **Legend**: `Order_Status` (Completed, Returned, Cancelled)
- **Values**: `[Total Orders]`
- **Formatting**: Set color for `Completed` to Soft Green, `Returned` to Amber/Orange, and `Cancelled` to Soft Red.

---

## Part 4: Analytical Adjustments & Polish

1. **Grid Alignment**: Turn on **Snap to Grid** (Format menu) to ensure perfect alignment of all visual blocks.
2. **Interactive Filtering**: 
   - Select any visual, go to **Format** $\rightarrow$ **Edit interactions**. 
   - Verify that clicking on a bar in "Category Performance" correctly filters all KPI cards and trends!
3. **Tooltip Customization**: Ensure hover tooltips are enabled on all charts to provide granular metric details without cluttering the screen.
