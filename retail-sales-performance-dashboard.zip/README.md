# Retail Sales Performance Dashboard

A comprehensive, beginner-friendly data analysis portfolio project designed for **Data Analyst**, **MIS Executive**, **Finance Operations**, and **Business Analyst** roles. 

This project is tailored specifically for B.Com (Bachelor of Commerce) graduates and business professionals. It showcases core competencies in data cleaning, formula-based auditing, pivot table synthesis, dashboard design, and interactive business reporting using **Microsoft Excel** and **Microsoft Power BI**—without relying on programming languages like Python or SQL.

---

## Project Overview & Objective

The objective of this project is to analyze a dataset of **150 realistic retail sales records** from January to June 2026, across five Indian product categories and regions, to extract actionable business insights.

The dashboard tracks and visualizes critical commercial metrics:
* **Total Sales** & **Total Profit**
* **Total Orders** & **Average Order Value (AOV)**
* **Profit Margin (%)**
* **Monthly sales and profit trends**
* **Sales by geographic region**
* **Sales by product category**
* **Top-performing products**
* **Salesperson performance & contribution**
* **Payment-method distribution**
* **Order fulfillment and status rates** (Fulfillment funnel)

---

## Dataset Schema

The raw dataset (`retail_sales_data.csv`) contains approximately 150 rows spanning January 2026 to June 2026 with the following columns:

| Column Name | Data Type | Description |
| :--- | :--- | :--- |
| **Order_ID** | Text | Unique alphanumeric identifier for each order (ORD1001 to ORD1150). |
| **Order_Date** | Date | Transaction date (YYYY-MM-DD format). |
| **Customer_Name**| Text | Customer's full name. |
| **Product** | Text | Item sold (e.g., Headphones, Sneakers, Study Desk). |
| **Category** | Text | High-level category (Electronics, Furniture, Clothing, Grocery, Office Supplies). |
| **Quantity** | Integer | Number of units purchased (1 to 5). |
| **Unit_Price** | Currency | Base price per single unit (in INR ₹). |
| **Discount** | Currency | Direct promotional discount applied (in INR ₹). |
| **Sales_Amount** | Currency | Net revenue generated. Formula: `(Quantity × Unit_Price) − Discount`. |
| **Cost_Amount** | Currency | Total wholesale cost to the business. Formula: `Quantity × Cost_Price`. |
| **Profit** | Currency | Net financial return. Formula: `Sales_Amount − Cost_Amount`. |
| **Region** | Text | Customer region (North, South, East, West, Central). |
| **Salesperson** | Text | Assigned sales representative. |
| **Payment_Method**| Text | Settlement method (UPI, Cash, Credit Card, Debit Card, Bank Transfer). |
| **Order_Status** | Text | Transaction outcome (Completed, Returned, Cancelled). |

---

## Directory Structure

```text
├── README.md                     # Project summary, resume points, and interview script
├── retail_sales_data.csv         # Raw 150-record CSV dataset
├── retail_sales_dashboard.xlsx   # Full Excel workbook (Raw, Cleaned, Pivot, Dashboard)
└── power_bi_dashboard_guide.md   # Step-by-step Power BI setup and DAX formulas guide
```

---

## Excel Workflow & Tasks Completed

The Excel workbook `retail_sales_dashboard.xlsx` contains four structured worksheets to show a complete, professional data pipeline:

1. **`Raw_Data`**: The raw tabular records as originally collected, with standard column formats.
2. **`Cleaned_Data`**: The primary working spreadsheet with data formatted as an official Excel Table.
   - **Formulas Implemented**:
     - *Sales Amount*: `=F2*G2-H2` (Qty × Unit Price − Discount)
     - *Profit*: `=I2-J2` (Sales Amount − Cost Amount)
     - *Month Column*: `=TEXT(B2,"yyyy-mm")` (Derived chronologically from Order Date)
     - *Profit Margin*: `=IF(I2>0, K2/I2, 0)` (Profit / Sales Amount, formatted as `%`)
   - **Conditional Formatting**: Added subtle fill colors to highlight performance:
     - **Negative Profit (Losses/Returns)**: Highlighted in **Soft Red** (`#FFD3D3` fill, `#900000` bold text).
     - **Outstanding Profit ($\ge$ ₹1,500)**: Highlighted in **Soft Green** (`#D4EDDA` fill, `#155724` bold text).
3. **`Pivot_Analysis`**: Clean, non-cluttered summary reports created using SUMIFS, COUNTIFS, and logical formulas linked directly to the cleaned data table:
   - **Monthly Sales Trend**: Aggregates sales, profit, order counts, and Average Order Value (AOV) by month.
   - **Category Performance**: Summarizes revenue, profits, and net profit margins across the five core product groups.
   - **Regional Distribution**: Tracks regional sales volumes and percentage sales share.
   - **Salesperson Performance**: Analyzes representative sales volumes, profits, and contribution to net margins.
4. **`Dashboard`**: A professional, executive-ready single-page layout:
   - **Dynamic KPI Cards**: Double-layered merged blocks with prominent figures referencing live summary totals (`=SUM(Cleaned_Data!I2:I151)`, etc.).
   - **Visual Summary Tables**: Fully styled grids that drive standard charts (Monthly Performance, Category Shares, Top Products).
   - **Slicer & Chart Guides**: Integrated layout frames with step-by-step prompts to add slicers (Month, Region, Category, Salesperson, Status) and charts.

---

## Power BI Setup & Measures

The accompanying guide `power_bi_dashboard_guide.md` details how to recreate this setup in Power BI. Key accomplishments include writing explicit, performant DAX measures:

* **Total Sales** = `SUM(Cleaned_Data[Sales_Amount])`
* **Total Profit** = `SUM(Cleaned_Data[Profit])`
* **Total Orders** = `COUNTROWS(Cleaned_Data)`
* **Average Order Value (AOV)** = `DIVIDE([Total Sales], [Total Orders], 0)`
* **Profit Margin** = `DIVIDE([Total Profit], [Total Sales], 0)`
* **Completed Orders** = `CALCULATE([Total Orders], Cleaned_Data[Order_Status] = "Completed")`
* **Returned Orders** = `CALCULATE([Total Orders], Cleaned_Data[Order_Status] = "Returned")`
* **Cancelled Orders** = `CALCULATE([Total Orders], Cleaned_Data[Order_Status] = "Cancelled")`

---

## Key Business Insights (Based on Actual Generated Data)

Analyzing the full 150-record dataset yields the following five core commercial insights:

1. **Peak Sales Month (June 2026)**: **June** was the highest-performing month with **₹2,12,350 in Sales**, which accounts for **27.8%** of the entire half-year revenue. This indicates a strong mid-year surge, contrasting with February which was the slowest month (₹88,700).
2. **Electronics Category Dominance**: **Electronics** is the leading category, generating **₹2,75,450 in Sales (36.1% share)** and the highest net profit of **₹92,250**, representing a robust **33.5% Profit Margin**. Furniture was a close second in sales (₹2,17,500), but had a lower profit margin (32.2%).
3. **Top Geographic Performer (North Region)**: The **North region** led all regional divisions with **₹1,97,200 in total sales (25.9% share)**. Conversely, the **South region** was the weakest performer, bringing in ₹88,500 (11.6% share), representing a prime opportunity for targeted promotional campaigns.
4. **Champion Sales Representative**: **Neha Singh** was the star salesperson, driving **₹2,03,700 in sales** and generating **₹67,550 in profit (26.8% of the company's total profit)**. Rahul Mehta was the second-best performer with ₹1,77,750 in sales.
5. **Top Product Revenue Driver**: **Sneakers** (Clothing category) was the single highest-selling product by revenue, generating **₹98,750 in sales**, followed by **Study Desk** (Furniture) at **₹78,200** and **Headphones** (Electronics) at **₹72,000**.
6. **Order Fulfillment Funnel Analysis**: Out of 150 placed orders, **132 were Completed successfully (88%)**, **10 were Returned (6.7%)**, and **8 were Cancelled (5.3%)**. The combined return/cancellation leakage rate of **12%** represents ₹83,400 in reversed transactions, pointing to potential product descriptions or delivery improvements.

---

## Resume Bullet Points (ATS-Friendly)

Add these high-impact, results-driven bullet points to your resume under your Projects section:

* **Retail Sales Performance Dashboard | Excel & Power BI Portfolio Project**
  * *Developed an interactive sales performance dashboard in MS Excel and Power BI to analyze a 150-record commercial dataset, tracking ₹762K+ in sales and ₹251K+ in profits.*
  * *Created automated financial workbooks utilizing advanced Excel formulas (SUMIFS, COUNTIFS, AVERAGEIFS, IF) and Pivot Tables, reducing manual report compilation time.*
  * *Wrote DAX measures in Power BI (including DIVIDE and CALCULATE filters) to analyze Average Order Value (AOV), profit margins, and return rates, identifying Neha Singh as the star sales representative (₹203K+ revenue contribution).*
  * *Designed professional executive layouts with dynamic KPI cards, conditional formatting rules, and interactive slicers, highlighting a 12% return/cancellation leakage rate to guide commercial operational decisions.*

---

## 45-Second Interview Explanation Script

*Here is a highly professional, structured response to practice when an interviewer asks: **"Can you tell me about a project you worked on?"***

> "Certainly! I recently completed a **Retail Sales Performance Dashboard** project designed to analyze six months of commercial transactions. 
> 
> Using a dataset of 150 sales records across regions and categories, I first built a data pipeline in **Microsoft Excel**. I converted the raw data into an official Table, added calculated columns for months and profit margins using advanced logical formulas, and set up conditional formatting to immediately highlight high-profit orders and loss-making returns. 
> 
> Next, I summarized this data using SUMIFS-driven pivot tables and built a clean, executive dashboard containing key KPIs and trend charts. I also imported this file into **Power BI**, where I wrote custom DAX measures like CALCULATE and DIVIDE to isolate completed, returned, and cancelled orders. 
> 
> Through this analysis, I identified that **June was our peak sales month** and that **Electronics led all categories with a 33.5% profit margin**. I also discovered a **12% leakage rate** due to returned and cancelled orders, which I highlighted as a critical area for operational improvement. This project demonstrates my ability to transform raw financial data into clear, actionable business recommendations."

---

## How to Open and Use the Project

### To explore the Excel Dashboard:
1. Open `retail_sales_dashboard.xlsx` in **Microsoft Excel** (Excel 2016 or newer recommended).
2. Go to the `Dashboard` worksheet to view the high-level KPI cards and formatted visual data.
3. Switch to `Cleaned_Data` to inspect the conditional formatting (green for high profit, red for losses) and the calculated columns (`Sales_Amount`, `Profit`, `Month`, `Profit_Margin`).
4. Switch to `Pivot_Analysis` to examine how SUMIFS and COUNTIFS formulas are used to summarize data dynamically rather than using standard static pivots.

### To build the Power BI Dashboard:
1. Ensure **Power BI Desktop** is installed on your machine.
2. Follow the detailed steps in `power_bi_dashboard_guide.md` to load `retail_sales_dashboard.xlsx` (specifically the `Cleaned_Data` sheet), write the DAX measures, and drag and drop visuals to complete your dashboard page.
