/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface SalesRecord {
  Order_ID: string;
  Order_Date: string; // YYYY-MM-DD
  Customer_Name: string;
  Product: string;
  Category: 'Electronics' | 'Furniture' | 'Clothing' | 'Grocery' | 'Office Supplies';
  Quantity: number;
  Unit_Price: number;
  Discount: number;
  Sales_Amount: number;
  Cost_Amount: number;
  Profit: number;
  Region: 'North' | 'South' | 'East' | 'West' | 'Central';
  Salesperson: string;
  Payment_Method: 'UPI' | 'Cash' | 'Credit Card' | 'Debit Card' | 'Bank Transfer';
  Order_Status: 'Completed' | 'Returned' | 'Cancelled';
}

export interface DashboardFilters {
  month: string; // 'All' or specific month (YYYY-MM)
  region: string; // 'All' or specific region
  category: string; // 'All' or specific category
  salesperson: string; // 'All' or specific salesperson
  orderStatus: string; // 'All' or specific status
}

export interface KPIValues {
  totalSales: number;
  totalProfit: number;
  totalOrders: number;
  averageOrderValue: number;
  profitMargin: number;
  completedOrders: number;
  returnedOrders: number;
  cancelledOrders: number;
}

export interface ChartDataPoint {
  label: string;
  sales: number;
  profit: number;
}
