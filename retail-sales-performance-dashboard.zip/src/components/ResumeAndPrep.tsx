/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Award, 
  Copy, 
  Check, 
  Play, 
  Square, 
  RotateCcw,
  BookOpen, 
  ChevronDown, 
  ChevronUp, 
  MessageSquare,
  Briefcase,
  UserCheck
} from 'lucide-react';

export const ResumeAndPrep: React.FC = () => {
  // Target Role selection for custom resume bullet tailoring!
  const [selectedRole, setSelectedRole] = useState<'da' | 'mis' | 'fin' | 'ba'>('da');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  // Speech Practice Timer
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);
  const [timeLeft, setTimeLeft] = useState<number>(45);
  const [hasFinishedSpeech, setHasFinishedSpeech] = useState<boolean>(false);

  // Expanded Q&A state
  const [expandedQuestion, setExpandedQuestion] = useState<number | null>(null);

  // Resume Bullets tailored by role
  const resumeBullets = {
    da: [
      {
        bold: "Analyzed Commercial Retail Transactions",
        text: "Developed an interactive sales performance dashboard in MS Excel and Power BI to analyze a 150-record commercial dataset, tracking ₹762K+ in sales and ₹251K+ in net profits."
      },
      {
        bold: "Automated Reporting Workflows",
        text: "Constructed dynamic, formula-driven audit sheets in Excel utilizing SUMIFS, COUNTIFS, and AVERAGEIFS linked to interactive slicers, reducing report consolidation times."
      },
      {
        bold: "Wrote Explicit DAX Measures",
        text: "Programmed performant DAX measures in Power BI (including CALCULATE filters and DIVIDE logic) to isolate key metrics like Average Order Value (AOV), profit margins (33.0% overall), and salesperson volumes."
      },
      {
        bold: "Identified Revenue Leakage Insights",
        text: "Analyzed commercial transactions to uncover a 12% revenue leakage rate stemming from returns and cancellations, presenting structured visual recommendations to leadership."
      }
    ],
    mis: [
      {
        bold: "Streamlined MIS Sales Pipelines",
        text: "Implemented a comprehensive data compilation workflow in Excel converting raw CSV records into polished tables, managing data integrity check for 150 consecutive orders."
      },
      {
        bold: "Formulated Metric Consolidation Workbooks",
        text: "Created Excel Pivot Tables and structured formula templates for monthly trends (identifying June 2026 peak of ₹212K+), facilitating automated monthly operational reviews."
      },
      {
        bold: "Engineered Executive Dashboards",
        text: "Designed single-page business dashboards with coordinated slicer cards, conditional formatting rules, and visual indicator rows for C-suite executive reporting."
      },
      {
        bold: "Delivered Weekly Representative Audits",
        text: "Maintained regular salesperson productivity matrices showing individual contributions, identifying Neha Singh as the star performer (₹203K+ revenue contribution)."
      }
    ],
    fin: [
      {
        bold: "Audited Commercial Ledger Sheets",
        text: "Analyzed 150 transactional sales records covering Jan-Jun 2026, verifying sales pricing, tax promotional discounts, and wholesale cost parameters."
      },
      {
        bold: "Formulated Profit & Loss Models",
        text: "Created exact margin audits using Excel `=IF(Sales_Amount>0, Profit/Sales_Amount, 0)` formulas and green/red conditional highlights to flag low-profit margin items."
      },
      {
        bold: "Tracked Average Order Values (AOV)",
        text: "Monitored AOV metrics (₹5,084 baseline) and category profit rates (Electronics leading at 33.5% margin) using explicit DAX calculations to guide product pricing models."
      },
      {
        bold: "Consolidated Reverse Logistics Data",
        text: "Categorized and tracked returned and cancelled transactions, quantifying ₹83K+ in reversed transactions to assess logistics refund risks."
      }
    ],
    ba: [
      {
        bold: "Conducted Sales Performance Analysis",
        text: "Built interactive reporting models in MS Excel and Power BI mapping 150 customer orders to track regional sales shares and product category margins (₹762K+ total revenue audited)."
      },
      {
        bold: "Formulated Strategic Business Forecasts",
        text: "Uncovered seasonal peaks (June accounting for 27.8% of total revenue) and category growth leaders (Electronics accounting for 36.1% of sales volume) to recommend inventory adjustments."
      },
      {
        bold: "Constructed Interactive Slicer Dashboards",
        text: "Enabled dynamic regional filtering for corporate stakeholders by integrating cross-sheet slicers, bar charts, and Treemaps across standard visual layers."
      },
      {
        bold: "Mapped Salesperson Contribution Metrics",
        text: "Synthesized sales representative conversion scores, showing Neha Singh drove 26.8% of net profit, guiding incentive structures."
      }
    ]
  };

  // Timer Side effect
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isTimerRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(t => t - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      setIsTimerRunning(false);
      setHasFinishedSpeech(true);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning, timeLeft]);

  const handleStartTimer = () => {
    setIsTimerRunning(true);
    setHasFinishedSpeech(false);
  };

  const handleStopTimer = () => {
    setIsTimerRunning(false);
  };

  const handleResetTimer = () => {
    setIsTimerRunning(false);
    setTimeLeft(45);
    setHasFinishedSpeech(false);
  };

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  // Sample interview Q&As based on actual dataset numbers
  const interviewQuestions = [
    {
      q: "What were the key results from your analysis of this retail dataset?",
      a: "Our analysis audited 150 total orders from Jan to June 2026, generating ₹7,62,550 in Total Sales and ₹2,51,600 in Total Profit, translating to an overall Profit Margin of 33.0%. The Average Order Value was ₹5,084. June was our absolute peak sales month bringing in ₹2,12,350, while Electronics dominated all product categories making up 36.1% of sales (₹2,75,450) and carrying a high profit margin of 33.5%."
    },
    {
      q: "How did you implement data cleaning and calculations in Excel?",
      a: "I converted the raw records into an official Excel Table for structured referencing. I wrote formulas in uppercase: Sales Amount as Qty × Unit Price − Discount, and Profit as Sales Amount − Cost Amount. I also used `=TEXT(Order_Date, \"yyyy-mm\")` to dynamically create a chronological Month column. I then used conditional formatting to highlight exceptional records—green for profits over ₹1,500 and light red for negative profits (losses/returns) to draw immediate management attention."
    },
    {
      q: "Why did you build explicit measures in Power BI instead of using implicit ones?",
      a: "As a Data Analyst, writing explicit measures using DAX is a core best practice. It ensures mathematical consistency, allows reusability across other charts, and ensures performance efficiency. For instance, I wrote explicit measures for Total Sales, Total Profit, and Average Order Value using the DIVIDE function, which safely handles division-by-zero errors without crashing the model. I also wrote CALCULATE measures to isolate completed, returned, and cancelled orders."
    },
    {
      q: "What was the most critical business recommendations you derived from this dashboard?",
      a: "The most significant recommendation comes from the Order Fulfillment Funnel. We discovered that out of 150 orders, 10 were Returned (6.7%) and 8 were Cancelled (5.3%). This combines for a 12% transaction leakage rate, costing the business ₹83,400 in reversed sales. I recommend audit teams investigate returns in Clothing (like sneakers) or delivery delays to address cancellations. Secondly, because the South region was our lowest performer (only 11.6% share), we should reallocate some of Neha Singh's successful North region (25.9% share) strategies to South sales representatives."
    },
    {
      q: "What Excel formulas did you use to build the Pivot sheet without using the Pivot Wizard?",
      a: "To showcase advanced workbook formulation skills, I built formula-driven pivot tables. I used `=SUMIFS` to sum sales and profit based on specific months or categories, and `=COUNTIFS` to count order occurrences. This approach is highly appreciated by managers because unlike traditional Pivot Tables which are static and require a manual 'Refresh', formula-driven tables are fully dynamic and update immediately when raw data is modified."
    }
  ];

  return (
    <div className="space-y-6">
      {/* Target Role Selector */}
      <div className="bg-white p-6 rounded-xl border border-slate-200/85 shadow-[0_1px_3px_rgba(0,0,0,0.01)]">
        <div className="mb-5">
          <h3 className="font-display font-semibold text-slate-800 text-base flex items-center gap-2.5">
            <span className="w-2.5 h-5 bg-indigo-600 rounded-xs inline-block"></span>
            1. ATS Resume Bullet Point Builder
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">Select your target career track to view tailored, high-impact resume accomplishments.</p>
        </div>

        {/* Role Select Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-5 select-none">
          <button
            onClick={() => setSelectedRole('da')}
            className={`py-2 px-3 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-all border cursor-pointer ${
              selectedRole === 'da'
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Briefcase className="w-3.5 h-3.5" />
            Data Analyst
          </button>
          <button
            onClick={() => setSelectedRole('mis')}
            className={`py-2 px-3 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-all border cursor-pointer ${
              selectedRole === 'mis'
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            MIS Executive
          </button>
          <button
            onClick={() => setSelectedRole('fin')}
            className={`py-2 px-3 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-all border cursor-pointer ${
              selectedRole === 'fin'
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            Finance Operations
          </button>
          <button
            onClick={() => setSelectedRole('ba')}
            className={`py-2 px-3 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-all border cursor-pointer ${
              selectedRole === 'ba'
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Award className="w-3.5 h-3.5" />
            Business Analyst
          </button>
        </div>

        {/* Tailored Resume Bullets List */}
        <div className="space-y-3">
          {resumeBullets[selectedRole].map((bullet, idx) => {
            const bulletText = `• ${bullet.text}`;
            return (
              <div key={idx} className="group relative bg-slate-50/60 hover:bg-slate-50 border border-slate-200/80 rounded-lg p-4 transition-all flex items-start gap-3.5">
                <span className="w-5.5 h-5.5 bg-indigo-50 border border-indigo-100 rounded-full inline-flex items-center justify-center text-[10px] text-indigo-700 font-bold mt-0.5 shrink-0 select-none">
                  {idx + 1}
                </span>
                <p className="text-xs text-slate-700 leading-relaxed pr-8">
                  <strong className="text-slate-900 font-semibold">{bullet.bold}:</strong> {bullet.text.substring(bullet.text.indexOf(':') + 1 || bullet.text.indexOf('analyze') - 1 || 0)}
                </p>
                <button
                  onClick={() => handleCopy(bulletText, idx)}
                  className="absolute right-4 top-4 text-slate-400 hover:text-indigo-600 transition-all cursor-pointer p-1"
                  title="Copy Bullet Point"
                >
                  {copiedIndex === idx ? (
                    <Check className="w-4 h-4 text-emerald-600" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Speech Practice Section */}
      <div className="bg-white p-6 rounded-xl border border-slate-200/85 shadow-[0_1px_3px_rgba(0,0,0,0.01)]">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="font-display font-semibold text-slate-800 text-base flex items-center gap-2.5">
              <span className="w-2.5 h-5 bg-indigo-600 rounded-xs inline-block"></span>
              2. 45-Second Interview Elevator Pitch Coach
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Use our active timer to practice explaining this project comfortably during an interview.</p>
          </div>

          {/* Visual Stopwatch */}
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3.5 py-1.5 rounded-lg select-none">
            <span className={`w-2.5 h-2.5 rounded-full ${isTimerRunning ? 'bg-rose-500 animate-pulse' : 'bg-slate-400'}`} />
            <span className="font-mono font-bold text-slate-800 text-sm">00:{timeLeft < 10 ? `0${timeLeft}` : timeLeft}</span>
            <div className="flex gap-1.5 ml-2.5 border-l border-slate-200 pl-2.5">
              {!isTimerRunning ? (
                <button 
                  onClick={handleStartTimer} 
                  disabled={timeLeft === 0}
                  className="p-1 text-indigo-600 hover:bg-indigo-50 rounded-md transition-all cursor-pointer"
                  title="Start Timer"
                >
                  <Play className="w-3.5 h-3.5 fill-indigo-600" />
                </button>
              ) : (
                <button 
                  onClick={handleStopTimer} 
                  className="p-1 text-rose-600 hover:bg-rose-50 rounded-md transition-all cursor-pointer"
                  title="Pause Timer"
                >
                  <Square className="w-3.5 h-3.5 fill-rose-600" />
                </button>
              )}
              <button 
                onClick={handleResetTimer} 
                className="p-1 text-slate-500 hover:bg-slate-100 rounded-md transition-all cursor-pointer"
                title="Reset Timer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Speech Card Box */}
        <div className="bg-slate-50/60 border border-slate-200/80 p-5 rounded-lg relative overflow-hidden">
          <p className="text-[10px] font-bold text-indigo-700 uppercase tracking-wider mb-2 select-none">Practice Script (Read Aloud):</p>
          <p className="text-xs text-slate-700 leading-relaxed font-sans italic">
            "Certainly! I recently completed a <strong className="text-slate-900 not-italic font-semibold">Retail Sales Performance Dashboard</strong> project designed to analyze six months of commercial transactions. 
            Using a dataset of 150 sales records across regions and categories, I first built a data pipeline in <strong className="text-slate-900 not-italic font-semibold">Microsoft Excel</strong>. I converted raw data into an official Table, wrote calculated columns for months and margins using logical formulas, and highlighted exceptions with conditional formatting. Next, I summarized this data using SUMIFS-driven pivots and created KPI cards. 
            I also loaded this data into <strong className="text-slate-900 not-italic font-semibold">Power BI</strong> to write explicit DAX measures isolating completed, returned, and cancelled orders. Through this analysis, I identified that <strong className="text-slate-900 not-italic font-semibold">June was our peak sales month</strong>, and <strong className="text-slate-900 not-italic font-semibold">Electronics led categories with a 33.5% profit margin</strong>. I also highlighted a <strong className="text-slate-900 not-italic font-semibold">12% leakage rate</strong> from cancellations and returns, representing ₹83,400 in reversed transactions—which served as a critical operational recommendation for cost savings."
          </p>

          {/* Toast on complete */}
          {hasFinishedSpeech && (
            <div className="absolute inset-0 bg-[#0f172a]/95 flex flex-col items-center justify-center text-center p-4 transition-all">
              <Award className="w-8 h-8 text-amber-400 mb-1 animate-bounce" />
              <h4 className="text-sm font-semibold text-white">45-Second Timer Complete!</h4>
              <p className="text-[11px] text-slate-300 mt-1 max-w-sm">Great job! Speaking at this speed is optimal. Try again to refine your voice tone and emphasis.</p>
              <button 
                onClick={handleResetTimer}
                className="mt-3.5 bg-indigo-600 text-white font-bold px-4 py-1.5 text-xs rounded-lg shadow-md hover:bg-indigo-700 transition-all cursor-pointer"
              >
                Reset and Try Again
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Technical Q&A Practice Board */}
      <div className="bg-white p-6 rounded-xl border border-slate-200/85 shadow-[0_1px_3px_rgba(0,0,0,0.01)]">
        <div className="mb-4">
          <h3 className="font-display font-semibold text-slate-800 text-base flex items-center gap-2.5">
            <span className="w-2.5 h-5 bg-indigo-600 rounded-xs inline-block"></span>
            3. Technical & Situational Q&A Practice Board
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">Click any question to expand the perfect, data-verified model answer to prepare for interview panels.</p>
        </div>

        {/* Questions Grid */}
        <div className="space-y-2.5">
          {interviewQuestions.map((q, idx) => (
            <div 
              key={idx} 
              className={`border rounded-lg transition-all overflow-hidden ${
                expandedQuestion === idx 
                  ? 'border-indigo-200 bg-indigo-50/10' 
                  : 'border-slate-200 bg-white hover:bg-slate-50/30'
              }`}
            >
              <button
                onClick={() => setExpandedQuestion(expandedQuestion === idx ? null : idx)}
                className="w-full text-left py-3 px-4 flex items-center justify-between gap-4 font-medium text-xs text-slate-800 cursor-pointer"
              >
                <span className="flex items-center gap-2.5">
                  <span className="w-5.5 h-5.5 bg-slate-100 text-slate-600 rounded-full inline-flex items-center justify-center font-bold text-[9px] select-none">Q</span>
                  {q.q}
                </span>
                {expandedQuestion === idx ? (
                  <ChevronUp className="w-4 h-4 text-indigo-600 shrink-0" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                )}
              </button>

              {expandedQuestion === idx && (
                <div className="px-4 pb-4 pt-1 text-xs text-slate-600 border-t border-slate-100 leading-relaxed font-sans">
                  <div className="bg-white p-3.5 rounded-lg border border-indigo-100 flex items-start gap-3 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
                    <MessageSquare className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold text-indigo-800 mb-1 uppercase tracking-wider text-[10px]">Model Interview Answer:</p>
                      <p className="text-slate-700 leading-relaxed text-[11.5px]">{q.a}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
