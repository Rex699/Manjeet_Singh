/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import { SalesRecord, DashboardFilters, KPIValues } from '../types';
import { 
  DollarSign, 
  ShoppingBag, 
  Layers, 
  TrendingUp, 
  CheckCircle, 
  Info,
  ChevronRight,
  TrendingDown,
  User,
  MapPin,
  HelpCircle,
  Clock
} from 'lucide-react';

interface DashboardPreviewProps {
  records: SalesRecord[];
  filters: DashboardFilters;
  setFilters: React.Dispatch<React.SetStateAction<DashboardFilters>>;
  viewMode: 'excel' | 'powerbi';
}

export const DashboardPreview: React.FC<DashboardPreviewProps> = ({
  records,
  filters,
  setFilters,
  viewMode
}) => {
  // --- 1. FILTER DATA IN REAL-TIME ---
  const filteredRecords = useMemo(() => {
    return records.filter(r => {
      const matchMonth = filters.month === 'All' || r.Order_Date.startsWith(filters.month);
      const matchRegion = filters.region === 'All' || r.Region === filters.region;
      const matchCategory = filters.category === 'All' || r.Category === filters.category;
      const matchSalesperson = filters.salesperson === 'All' || r.Salesperson === filters.salesperson;
      const matchStatus = filters.orderStatus === 'All' || r.Order_Status === filters.orderStatus;
      return matchMonth && matchRegion && matchCategory && matchSalesperson && matchStatus;
    });
  }, [records, filters]);

  // --- 2. CALCULATE KPIs ---
  const kpis = useMemo<KPIValues>(() => {
    const totalSales = filteredRecords.reduce((sum, r) => sum + r.Sales_Amount, 0);
    const totalProfit = filteredRecords.reduce((sum, r) => sum + r.Profit, 0);
    const totalOrders = filteredRecords.length;
    const averageOrderValue = totalOrders > 0 ? totalSales / totalOrders : 0;
    const profitMargin = totalSales > 0 ? totalProfit / totalSales : 0;

    const completedOrders = filteredRecords.filter(r => r.Order_Status === 'Completed').length;
    const returnedOrders = filteredRecords.filter(r => r.Order_Status === 'Returned').length;
    const cancelledOrders = filteredRecords.filter(r => r.Order_Status === 'Cancelled').length;

    return {
      totalSales,
      totalProfit,
      totalOrders,
      averageOrderValue,
      profitMargin,
      completedOrders,
      returnedOrders,
      cancelledOrders
    };
  }, [filteredRecords]);

  // --- 3. AGGREGATE CHART DATA ---
  // A. Monthly Trend
  const monthlyData = useMemo(() => {
    const months = ['2026-01', '2026-02', '2026-03', '2026-04', '2026-05', '2026-06'];
    return months.map(m => {
      const subset = filteredRecords.filter(r => r.Order_Date.startsWith(m));
      const sales = subset.reduce((sum, r) => sum + r.Sales_Amount, 0);
      const profit = subset.reduce((sum, r) => sum + r.Profit, 0);
      // Format month label
      const name = m === '2026-01' ? 'Jan' : (m === '2026-02' ? 'Feb' : (m === '2026-03' ? 'Mar' : (m === '2026-04' ? 'Apr' : (m === '2026-05' ? 'May' : 'Jun'))));
      return { label: name, rawMonth: m, sales, profit };
    });
  }, [filteredRecords]);

  // B. Regional Performance
  const regionalData = useMemo(() => {
    const regions: ('North' | 'South' | 'East' | 'West' | 'Central')[] = ['North', 'South', 'East', 'West', 'Central'];
    return regions.map(reg => {
      const subset = filteredRecords.filter(r => r.Region === reg);
      const sales = subset.reduce((sum, r) => sum + r.Sales_Amount, 0);
      const profit = subset.reduce((sum, r) => sum + r.Profit, 0);
      return { label: reg, sales, profit };
    }).sort((a, b) => b.sales - a.sales);
  }, [filteredRecords]);

  // C. Category Breakdown
  const categoryData = useMemo(() => {
    const categories = ['Electronics', 'Furniture', 'Clothing', 'Grocery', 'Office Supplies'] as const;
    return categories.map(cat => {
      const subset = filteredRecords.filter(r => r.Category === cat);
      const sales = subset.reduce((sum, r) => sum + r.Sales_Amount, 0);
      const profit = subset.reduce((sum, r) => sum + r.Profit, 0);
      return { label: cat, sales, profit };
    }).sort((a, b) => b.sales - a.sales);
  }, [filteredRecords]);

  // D. Salesperson Leaderboard
  const salespersonData = useMemo(() => {
    const salespeople = ['Amit Verma', 'Neha Singh', 'Rahul Mehta', 'Priya Patel', 'Rajesh Sharma'];
    return salespeople.map(sp => {
      const subset = filteredRecords.filter(r => r.Salesperson === sp);
      const sales = subset.reduce((sum, r) => sum + r.Sales_Amount, 0);
      const profit = subset.reduce((sum, r) => sum + r.Profit, 0);
      return { label: sp, sales, profit };
    }).sort((a, b) => b.sales - a.sales);
  }, [filteredRecords]);

  // E. Top Products (Top 5)
  const topProductsData = useMemo(() => {
    const productSales: Record<string, { category: string; sales: number; qty: number }> = {};
    filteredRecords.forEach(r => {
      if (!productSales[r.Product]) {
        productSales[r.Product] = { category: r.Category, sales: 0, qty: 0 };
      }
      productSales[r.Product].sales += r.Sales_Amount;
      productSales[r.Product].qty += r.Quantity;
    });

    return Object.entries(productSales)
      .map(([name, d]) => ({ label: name, sales: d.sales, qty: d.qty, category: d.category }))
      .sort((a, b) => b.sales - a.sales)
      .slice(0, 5);
  }, [filteredRecords]);

  // Slicer Lists
  const monthOptions = ['All', '2026-01', '2026-02', '2026-03', '2026-04', '2026-05', '2026-06'];
  const regionOptions = ['All', 'North', 'South', 'East', 'West', 'Central'];
  const categoryOptions = ['All', 'Electronics', 'Furniture', 'Clothing', 'Grocery', 'Office Supplies'];
  const salespersonOptions = ['All', 'Amit Verma', 'Neha Singh', 'Rahul Mehta', 'Priya Patel', 'Rajesh Sharma'];
  const statusOptions = ['All', 'Completed', 'Returned', 'Cancelled'];

  const resetFilters = () => {
    setFilters({
      month: 'All',
      region: 'All',
      category: 'All',
      salesperson: 'All',
      orderStatus: 'All'
    });
  };

  // Helper for Indian formatting of numbers
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(val);
  };

  const hasFiltersApplied = Object.values(filters).some(v => v !== 'All');

  // Sparkline max values for rendering
  const maxMonthlySales = Math.max(...monthlyData.map(d => d.sales), 1);
  const maxRegionalSales = Math.max(...regionalData.map(d => d.sales), 1);
  const maxCategorySales = Math.max(...categoryData.map(d => d.sales), 1);
  const maxSalespersonSales = Math.max(...salespersonData.map(d => d.sales), 1);
  const maxProductSales = Math.max(...topProductsData.map(d => d.sales), 1);

  return (
    <div className="space-y-6">
      {/* Interactive Slicers Panel (Filters Dashboard) */}
      <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-[0_1px_3px_rgba(0,0,0,0.01)]">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 pb-4 border-b border-slate-100">
          <div>
            <h3 className="font-display font-semibold text-slate-800 text-base flex items-center gap-2.5">
              <span className="w-2.5 h-5 bg-indigo-600 rounded-xs inline-block"></span>
              Interactive Slicers & Filters
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">Toggle filters below to update the dashboard preview in real-time.</p>
          </div>
          {hasFiltersApplied && (
            <button 
              onClick={resetFilters}
              className="mt-3 md:mt-0 text-xs font-semibold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100/85 px-3.5 py-1.5 rounded-lg flex items-center gap-1.5 transition-all self-start cursor-pointer"
            >
              Reset All Filters
            </button>
          )}
        </div>

        {/* Filters Slicers Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
          {/* Month Slicer */}
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 tracking-wider uppercase block">Month</label>
            <select 
              value={filters.month}
              onChange={(e) => setFilters(f => ({ ...f, month: e.target.value }))}
              className="w-full text-xs py-2 px-3 rounded-lg border border-slate-200 bg-slate-50/50 text-slate-800 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none font-medium transition-all"
            >
              {monthOptions.map(m => (
                <option key={m} value={m}>
                  {m === 'All' ? 'All Months' : m === '2026-01' ? 'January 2026' : m === '2026-02' ? 'February 2026' : m === '2026-03' ? 'March 2026' : m === '2026-04' ? 'April 2026' : m === '2026-05' ? 'May 2026' : 'June 2026'}
                </option>
              ))}
            </select>
          </div>

          {/* Region Slicer */}
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 tracking-wider uppercase block">Region</label>
            <select 
              value={filters.region}
              onChange={(e) => setFilters(f => ({ ...f, region: e.target.value }))}
              className="w-full text-xs py-2 px-3 rounded-lg border border-slate-200 bg-slate-50/50 text-slate-800 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none font-medium transition-all"
            >
              {regionOptions.map(r => (
                <option key={r} value={r}>{r === 'All' ? 'All Regions' : `${r} Region`}</option>
              ))}
            </select>
          </div>

          {/* Category Slicer */}
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 tracking-wider uppercase block">Category</label>
            <select 
              value={filters.category}
              onChange={(e) => setFilters(f => ({ ...f, category: e.target.value }))}
              className="w-full text-xs py-2 px-3 rounded-lg border border-slate-200 bg-slate-50/50 text-slate-800 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none font-medium transition-all"
            >
              {categoryOptions.map(c => (
                <option key={c} value={c}>{c === 'All' ? 'All Categories' : c}</option>
              ))}
            </select>
          </div>

          {/* Salesperson Slicer */}
          <div className="space-y-1.5">
            <label className="text-[10px] font-bold text-slate-400 tracking-wider uppercase block">Salesperson</label>
            <select 
              value={filters.salesperson}
              onChange={(e) => setFilters(f => ({ ...f, salesperson: e.target.value }))}
              className="w-full text-xs py-2 px-3 rounded-lg border border-slate-200 bg-slate-50/50 text-slate-800 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none font-medium transition-all"
            >
              {salespersonOptions.map(s => (
                <option key={s} value={s}>{s === 'All' ? 'All Salespeople' : s}</option>
              ))}
            </select>
          </div>

          {/* Order Status Slicer */}
          <div className="space-y-1.5 col-span-2 sm:col-span-1">
            <label className="text-[10px] font-bold text-slate-400 tracking-wider uppercase block">Order Status</label>
            <select 
              value={filters.orderStatus}
              onChange={(e) => setFilters(f => ({ ...f, orderStatus: e.target.value }))}
              className="w-full text-xs py-2 px-3 rounded-lg border border-slate-200 bg-slate-50/50 text-slate-800 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none font-medium transition-all"
            >
              {statusOptions.map(s => (
                <option key={s} value={s}>{s === 'All' ? 'All Statuses' : s}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Active Filter Badges */}
        <div className="flex flex-wrap items-center gap-2 mt-4 pt-3.5 border-t border-slate-100 text-xs">
          <span className="text-slate-400 font-medium">Active Filters:</span>
          {!hasFiltersApplied ? (
            <span className="text-slate-500 bg-slate-50 border border-slate-200/50 px-2.5 py-0.5 rounded-md font-medium">None (Showing all 150 records)</span>
          ) : (
            <>
              {filters.month !== 'All' && <span className="bg-indigo-50 text-indigo-700 border border-indigo-100 px-2.5 py-0.5 rounded-full font-medium">Month: {filters.month}</span>}
              {filters.region !== 'All' && <span className="bg-indigo-50 text-indigo-700 border border-indigo-100 px-2.5 py-0.5 rounded-full font-medium">Region: {filters.region}</span>}
              {filters.category !== 'All' && <span className="bg-indigo-50 text-indigo-700 border border-indigo-100 px-2.5 py-0.5 rounded-full font-medium">Category: {filters.category}</span>}
              {filters.salesperson !== 'All' && <span className="bg-indigo-50 text-indigo-700 border border-indigo-100 px-2.5 py-0.5 rounded-full font-medium">Salesperson: {filters.salesperson}</span>}
              {filters.orderStatus !== 'All' && (
                <span className={`px-2.5 py-0.5 rounded-full font-medium border ${
                  filters.orderStatus === 'Completed' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 
                  filters.orderStatus === 'Returned' ? 'bg-amber-50 text-amber-700 border-amber-100' : 'bg-rose-50 text-rose-700 border-rose-100'
                }`}>
                  Status: {filters.orderStatus}
                </span>
              )}
            </>
          )}
          <span className="ml-auto text-slate-500 font-medium bg-slate-50 border border-slate-200 px-2.5 py-0.5 rounded-md">
            Filtered Records: <strong className="text-slate-900 font-semibold">{filteredRecords.length}</strong> / 150
          </span>
        </div>
      </div>

      {/* ======================================================== */}
      // EXCEL THEME VIEW
      {/* ======================================================== */}
      {viewMode === 'excel' && (
        <div id="excel-preview-container" className="bg-[#F1F5F9] rounded-xl border border-slate-200 p-5 font-sans text-xs overflow-x-auto shadow-sm">
          {/* Excel Menu Mock */}
          <div className="flex items-center gap-2 pb-2.5 mb-3.5 border-b border-slate-300 text-slate-600 text-[11px] font-medium min-w-[900px] select-none">
            <span className="text-emerald-700 font-bold border-b-2 border-emerald-600 px-2.5 py-1">File</span>
            <span className="hover:text-slate-900 px-2 py-1 cursor-pointer transition-all">Home</span>
            <span className="hover:text-slate-900 px-2 py-1 cursor-pointer transition-all">Insert</span>
            <span className="hover:text-slate-900 px-2 py-1 cursor-pointer transition-all">Page Layout</span>
            <span className="hover:text-slate-900 px-2 py-1 cursor-pointer font-bold text-emerald-700 transition-all">Formulas</span>
            <span className="hover:text-slate-900 px-2 py-1 cursor-pointer transition-all">Data</span>
            <span className="hover:text-slate-900 px-2 py-1 cursor-pointer transition-all">Review</span>
            <span className="hover:text-slate-900 px-2 py-1 cursor-pointer transition-all">View</span>
            <span className="bg-emerald-600 text-white rounded-md px-2.5 py-0.5 ml-auto text-[10px] select-none shadow-[0_1px_2px_rgba(0,0,0,0.05)]">Excel Sheet View</span>
          </div>

          <div className="min-w-[950px] bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden p-6">
            {/* Sheet Title Banner */}
            <div className="bg-[#1E293B] text-white py-3.5 px-5 text-center font-display font-bold text-sm tracking-wider select-none rounded-t-lg mb-6 flex items-center justify-between">
              <span>RETAIL SALES PERFORMANCE DASHBOARD</span>
              <span className="text-[10px] bg-white/10 border border-white/10 px-2.5 py-0.5 rounded-md font-mono font-medium">Sheet: Dashboard</span>
            </div>
            {/* Sheet Title Banner */}
            <div className="bg-[#1F497D] text-white py-3 px-5 text-center font-display font-bold text-sm tracking-wider select-none rounded-t-sm mb-6 flex items-center justify-between">
              <span>RETAIL SALES PERFORMANCE DASHBOARD</span>
              <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-sm font-mono font-medium">Sheet: Dashboard</span>
            </div>

            {/* KPI Cards Grid - Excel Style */}
            <div className="grid grid-cols-5 gap-4 mb-8 select-none">
              {/* Total Sales Card */}
              <div className="border border-slate-200 rounded-lg overflow-hidden shadow-[0_1px_3px_rgba(0,0,0,0.01)] bg-white">
                <div className="bg-[#0f172a] text-white text-[10px] font-bold py-1.5 px-2 text-center tracking-wider uppercase">
                  TOTAL SALES
                </div>
                <div className="bg-slate-50 text-slate-800 py-4 px-2 text-center font-bold text-lg font-display">
                  {formatCurrency(kpis.totalSales)}
                </div>
                <div className="bg-white px-2 py-1.5 border-t border-slate-100 text-[9px] text-slate-400 text-center font-mono">
                  =SUM(Cleaned_Data!I2:I151)
                </div>
              </div>

              {/* Total Profit Card */}
              <div className="border border-slate-200 rounded-lg overflow-hidden shadow-[0_1px_3px_rgba(0,0,0,0.01)] bg-white">
                <div className="bg-[#1e3a8a] text-white text-[10px] font-bold py-1.5 px-2 text-center tracking-wider uppercase">
                  TOTAL PROFIT
                </div>
                <div className="bg-blue-50/50 text-blue-900 py-4 px-2 text-center font-bold text-lg font-display">
                  {formatCurrency(kpis.totalProfit)}
                </div>
                <div className="bg-white px-2 py-1.5 border-t border-slate-100 text-[9px] text-slate-400 text-center font-mono">
                  =SUM(Cleaned_Data!K2:K151)
                </div>
              </div>

              {/* Total Orders Card */}
              <div className="border border-slate-200 rounded-lg overflow-hidden shadow-[0_1px_3px_rgba(0,0,0,0.01)] bg-white">
                <div className="bg-[#312e81] text-white text-[10px] font-bold py-1.5 px-2 text-center tracking-wider uppercase">
                  TOTAL ORDERS
                </div>
                <div className="bg-indigo-50/50 text-indigo-900 py-4 px-2 text-center font-bold text-lg font-display">
                  {kpis.totalOrders}
                </div>
                <div className="bg-white px-2 py-1.5 border-t border-slate-100 text-[9px] text-slate-400 text-center font-mono">
                  =COUNTA(Cleaned_Data!A2:A151)-1
                </div>
              </div>

              {/* Average Order Value Card */}
              <div className="border border-slate-200 rounded-lg overflow-hidden shadow-[0_1px_3px_rgba(0,0,0,0.01)] bg-white">
                <div className="bg-[#334155] text-white text-[10px] font-bold py-1.5 px-2 text-center tracking-wider uppercase">
                  AVERAGE ORDER VALUE
                </div>
                <div className="bg-slate-50 text-slate-800 py-4 px-2 text-center font-bold text-base font-display truncate">
                  {formatCurrency(kpis.averageOrderValue)}
                </div>
                <div className="bg-white px-2 py-1.5 border-t border-slate-100 text-[9px] text-slate-400 text-center font-mono">
                  =AVERAGE(Cleaned_Data!I2:I151)
                </div>
              </div>

              {/* Profit Margin Card */}
              <div className="border border-slate-200 rounded-lg overflow-hidden shadow-[0_1px_3px_rgba(0,0,0,0.01)] bg-white">
                <div className="bg-[#475569] text-white text-[10px] font-bold py-1.5 px-2 text-center tracking-wider uppercase">
                  PROFIT MARGIN
                </div>
                <div className="bg-slate-50 text-slate-800 py-4 px-2 text-center font-bold text-lg font-display">
                  {(kpis.profitMargin * 100).toFixed(1)}%
                </div>
                <div className="bg-white px-2 py-1.5 border-t border-slate-100 text-[9px] text-slate-400 text-center font-mono">
                  =K5/I5 (Profit / Sales)
                </div>
              </div>
            </div>

            {/* Dashboard Main Visual Layout Row 1 */}
            <div className="grid grid-cols-12 gap-6 mb-8">
              {/* Monthly sales Trend Line Chart (Columns B:G) */}
              <div className="col-span-7 bg-white p-4 rounded-lg border border-slate-200">
                <div className="bg-[#1E293B] text-white font-bold px-3 py-1.5 text-xs select-none rounded-t-md mb-3 font-display">
                  MONTHLY SALES & PROFIT TREND
                </div>
                
                {/* SVG Live Trend Line Chart */}
                <div className="h-[220px] w-full bg-slate-50/50 border border-slate-200 p-2 relative rounded-md">
                  {/* Axis line */}
                  <svg className="w-full h-full" viewBox="0 0 500 200" preserveAspectRatio="none">
                    {/* Grid lines */}
                    <line x1="0" y1="40" x2="500" y2="40" stroke="#E2E8F0" strokeWidth="1" strokeDasharray="3" />
                    <line x1="0" y1="90" x2="500" y2="90" stroke="#E2E8F0" strokeWidth="1" strokeDasharray="3" />
                    <line x1="0" y1="140" x2="500" y2="140" stroke="#E2E8F0" strokeWidth="1" strokeDasharray="3" />
                    <line x1="0" y1="180" x2="500" y2="180" stroke="#CBD5E1" strokeWidth="1" />

                    {/* Plot Sales Line */}
                    {monthlyData.length > 0 && (
                      <>
                        {/* Sales path */}
                        <path
                          d={monthlyData.map((d, i) => {
                            const x = 40 + i * 80;
                            const y = 170 - (d.sales / maxMonthlySales) * 120;
                            return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                          }).join(' ')}
                          fill="none"
                          stroke="#4f46e5"
                          strokeWidth="3.5"
                          strokeLinecap="round"
                        />
                        {/* Profit path */}
                        <path
                          d={monthlyData.map((d, i) => {
                            const x = 40 + i * 80;
                            const y = 170 - (d.profit / maxMonthlySales) * 120;
                            return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                          }).join(' ')}
                          fill="none"
                          stroke="#0ea5e9"
                          strokeWidth="2.5"
                          strokeLinecap="round"
                          strokeDasharray="4 2"
                        />
                        {/* Data dots */}
                        {monthlyData.map((d, i) => {
                          const x = 40 + i * 80;
                          const ySales = 170 - (d.sales / maxMonthlySales) * 120;
                          const yProfit = 170 - (d.profit / maxMonthlySales) * 120;
                          return (
                            <g key={i} className="group cursor-pointer">
                              <circle cx={x} cy={ySales} r="5" fill="#4f46e5" stroke="#FFFFFF" strokeWidth="1.5" />
                              <circle cx={x} cy={yProfit} r="4.5" fill="#0ea5e9" stroke="#FFFFFF" strokeWidth="1.5" />
                              <text x={x} y={ySales - 10} textAnchor="middle" fill="#1e1b4b" className="text-[9px] font-bold font-mono bg-white px-1 rounded-sm border border-slate-100">
                                ₹{Math.round(d.sales/1000)}k
                              </text>
                            </g>
                          );
                        })}
                      </>
                    )}
                  </svg>
                  
                  {/* Legend overlay */}
                  <div className="absolute top-2 right-2 bg-white/95 px-2.5 py-1 rounded-md border border-slate-200 flex gap-4 text-[9px] font-semibold text-slate-600 shadow-sm">
                    <span className="flex items-center gap-1.5"><span className="w-2.5 h-1 bg-[#4f46e5] rounded-full inline-block"></span> Sales</span>
                    <span className="flex items-center gap-1.5"><span className="w-2.5 h-1 bg-[#0ea5e9] border-t-2 border-dashed border-white inline-block"></span> Profit</span>
                  </div>

                  {/* Monthly Labels */}
                  <div className="flex justify-between px-10 pt-1.5 text-[9px] font-semibold text-slate-500 select-none">
                    {monthlyData.map((d, i) => <span key={i}>{d.label}</span>)}
                  </div>
                </div>
              </div>

              {/* Top Products Table (Columns H:O) */}
              <div className="col-span-5 bg-white p-4 rounded-lg border border-slate-200">
                <div className="bg-[#1E293B] text-white font-bold px-3 py-1.5 text-xs select-none rounded-t-md mb-3 font-display">
                  TOP 5 PRODUCT SALES LEADERBOARD
                </div>
                <div className="border border-slate-200 rounded-md overflow-hidden">
                  <table className="w-full text-left border-collapse text-[10px]">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 font-semibold text-slate-500">
                        <th className="py-2.5 px-2.5">Product Name</th>
                        <th className="py-2.5 px-2.5 text-center">Category</th>
                        <th className="py-2.5 px-2.5 text-right">Qty</th>
                        <th className="py-2.5 px-2.5 text-right">Revenue</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-600">
                      {topProductsData.map((p, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/50 transition-all">
                          <td className="py-2.5 px-2.5 font-medium text-slate-800 flex items-center gap-2">
                            <span className="w-4 h-4 bg-slate-100 rounded-full inline-flex items-center justify-center font-bold text-[8px] text-slate-500">{idx + 1}</span>
                            {p.label}
                          </td>
                          <td className="py-2.5 px-2.5 text-center">
                            <span className="bg-slate-100 text-slate-600 text-[8px] font-semibold px-1.5 py-0.5 rounded-sm uppercase">{p.category}</span>
                          </td>
                          <td className="py-2.5 px-2.5 text-right font-mono font-medium text-slate-500">{p.qty}</td>
                          <td className="py-2.5 px-2.5 text-right font-semibold text-indigo-700 font-mono">{formatCurrency(p.sales)}</td>
                        </tr>
                      ))}
                      {topProductsData.length === 0 && (
                        <tr>
                          <td colSpan={4} className="py-6 text-center text-slate-400">No product sales meet the active filters</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Dashboard Layout Row 2 */}
            <div className="grid grid-cols-12 gap-6">
              {/* Category Performance Breakdown (Columns B:G) */}
              <div className="col-span-6 bg-white p-4 rounded-lg border border-slate-200">
                <div className="bg-[#1E293B] text-white font-bold px-3 py-1.5 text-xs select-none rounded-t-md mb-3 font-display">
                  CATEGORY SALES & PROFIT MARGINS
                </div>
                
                {/* Horizontal Progress Bar Visuals representing category breakdown */}
                <div className="space-y-4 py-1">
                  {categoryData.map((c, idx) => {
                    const percent = c.sales > 0 ? (c.sales / maxCategorySales) * 100 : 0;
                    const margin = c.sales > 0 ? (c.profit / c.sales) * 100 : 0;
                    
                    return (
                      <div key={idx} className="space-y-1.5">
                        <div className="flex justify-between text-[10px] font-medium">
                          <span className="text-slate-800 font-semibold">{c.label}</span>
                          <span className="text-slate-500 font-mono">
                            {formatCurrency(c.sales)} <span className="text-[9px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-100/60 font-bold ml-1.5">Margin: {margin.toFixed(1)}%</span>
                          </span>
                        </div>
                        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden border border-slate-200/50">
                          <div 
                            className="bg-indigo-600 h-full rounded-full transition-all duration-500" 
                            style={{ width: `${percent}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                  {categoryData.length === 0 && (
                    <p className="text-center text-slate-400 py-6">No category data matching active filters</p>
                  )}
                </div>
              </div>

              {/* Salesperson Leaderboard (Columns H:O) */}
              <div className="col-span-6 bg-white p-4 rounded-lg border border-slate-200">
                <div className="bg-[#1E293B] text-white font-bold px-3 py-1.5 text-xs select-none rounded-t-md mb-3 font-display">
                  REPRESENTATIVE SALES LEADERBOARD & CONTRIBUTIONS
                </div>
                <div className="space-y-4 pt-1">
                  {salespersonData.map((s, idx) => {
                    const contribution = kpis.totalSales > 0 ? (s.sales / kpis.totalSales) * 100 : 0;
                    return (
                      <div key={idx} className="flex items-center gap-3">
                        <div className="w-20 font-semibold text-slate-700 truncate text-[10px]">{s.label}</div>
                        <div className="flex-1 bg-slate-100 h-2.5 rounded-full border border-slate-200/50 overflow-hidden relative">
                          <div 
                            className="bg-indigo-500 h-full rounded-full" 
                            style={{ width: `${Math.min(100, Math.max(0, contribution))}%` }}
                          />
                        </div>
                        <div className="w-28 text-right font-semibold text-slate-800 font-mono text-[10px]">
                          {formatCurrency(s.sales)} <span className="text-[9px] font-normal text-slate-400 font-sans ml-1">({contribution.toFixed(1)}%)</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Excel Formula-driven Status Bar Overlay */}
            <div className="mt-8 pt-4 border-t border-slate-200 flex items-center justify-between text-[10px] text-slate-400 font-mono select-none">
              <span className="flex items-center gap-1.5"><Info className="w-3.5 h-3.5 text-indigo-500" /> Active Table: [Cleaned_Data_Tbl]</span>
              <span>All active cells contain dynamic SUMIFS/COUNTIFS formula linkages</span>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      // POWER BI THEME VIEW
      {/* ======================================================== */}
      {viewMode === 'powerbi' && (
        <div id="powerbi-preview-container" className="bg-[#1F1F1F] rounded-xl border border-gray-800 p-5 font-sans text-xs shadow-xs text-gray-300">
          {/* Header Banner - Power BI Modern Style */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 mb-5 border-b border-gray-800">
            <div>
              <h2 className="text-white text-base font-display font-semibold flex items-center gap-2">
                <span className="w-3 h-6 bg-[#F2C811] rounded-xs inline-block"></span>
                Power BI Enterprise Dashboard Preview
              </h2>
              <p className="text-[11px] text-gray-400">Rendered in high-fidelity Power BI executive template styling</p>
            </div>
            <div className="flex items-center gap-3 self-end md:self-auto text-[10px] font-mono text-gray-400 bg-black/30 px-3 py-1.5 rounded-lg border border-gray-800">
              <Clock className="w-3.5 h-3.5 text-amber-500" />
              Dataset: Live SQL-equivalent Model
            </div>
          </div>

          {/* Cards Row */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
            {/* KPI Card 1: Sales */}
            <div className="bg-[#292929] border border-gray-800 rounded-lg p-3.5 text-center shadow-md relative overflow-hidden">
              <div className="text-[10px] font-bold text-gray-400 tracking-wider uppercase mb-1">
                Total Sales
              </div>
              <div className="text-lg font-bold text-white font-display">
                {formatCurrency(kpis.totalSales)}
              </div>
              <div className="w-full bg-[#F2C811]/10 h-0.5 absolute bottom-0 left-0" />
            </div>

            {/* KPI Card 2: Profit */}
            <div className="bg-[#292929] border border-gray-800 rounded-lg p-3.5 text-center shadow-md relative overflow-hidden">
              <div className="text-[10px] font-bold text-gray-400 tracking-wider uppercase mb-1">
                Total Profit
              </div>
              <div className="text-lg font-bold text-[#4CAF50] font-display">
                {formatCurrency(kpis.totalProfit)}
              </div>
              <div className="w-full bg-[#4CAF50]/20 h-0.5 absolute bottom-0 left-0" />
            </div>

            {/* KPI Card 3: Orders */}
            <div className="bg-[#292929] border border-gray-800 rounded-lg p-3.5 text-center shadow-md relative overflow-hidden">
              <div className="text-[10px] font-bold text-gray-400 tracking-wider uppercase mb-1">
                Total Orders
              </div>
              <div className="text-lg font-bold text-white font-display">
                {kpis.totalOrders}
              </div>
              <div className="w-full bg-blue-500/20 h-0.5 absolute bottom-0 left-0" />
            </div>

            {/* KPI Card 4: Average Order Value */}
            <div className="bg-[#292929] border border-gray-800 rounded-lg p-3.5 text-center shadow-md relative overflow-hidden">
              <div className="text-[10px] font-bold text-gray-400 tracking-wider uppercase mb-1">
                Average Order Value
              </div>
              <div className="text-lg font-bold text-white font-display truncate">
                {formatCurrency(kpis.averageOrderValue)}
              </div>
              <div className="w-full bg-cyan-500/20 h-0.5 absolute bottom-0 left-0" />
            </div>

            {/* KPI Card 5: Profit Margin */}
            <div className="bg-[#292929] border border-gray-800 rounded-lg p-3.5 text-center shadow-md col-span-2 md:col-span-1 relative overflow-hidden">
              <div className="text-[10px] font-bold text-gray-400 tracking-wider uppercase mb-1">
                Profit Margin
              </div>
              <div className="text-lg font-bold text-amber-500 font-display">
                {(kpis.profitMargin * 100).toFixed(1)}%
              </div>
              <div className="w-full bg-amber-500/20 h-0.5 absolute bottom-0 left-0" />
            </div>
          </div>

          {/* Grid Layout of visual elements */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
            {/* Left side: Trend Area chart & regional sales */}
            <div className="md:col-span-8 space-y-5">
              {/* Line chart card */}
              <div className="bg-[#292929] border border-gray-800 rounded-lg p-4 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-xs font-bold text-white font-display tracking-wide uppercase">Monthly Sales & Profit Trend</h4>
                  <span className="text-[9px] text-gray-400 bg-black/25 border border-gray-800 px-2 py-0.5 rounded-sm">Chart type: Area</span>
                </div>

                <div className="h-[200px] w-full relative">
                  <svg className="w-full h-full" viewBox="0 0 500 180" preserveAspectRatio="none">
                    {/* Horizontal gridlines */}
                    <line x1="0" y1="30" x2="500" y2="30" stroke="#3D3D3D" strokeWidth="1" strokeDasharray="3" />
                    <line x1="0" y1="80" x2="500" y2="80" stroke="#3D3D3D" strokeWidth="1" strokeDasharray="3" />
                    <line x1="0" y1="130" x2="500" y2="130" stroke="#3D3D3D" strokeWidth="1" strokeDasharray="3" />
                    <line x1="0" y1="160" x2="500" y2="160" stroke="#555555" strokeWidth="1" />

                    {/* Area under Sales */}
                    {monthlyData.length > 0 && (
                      <path
                        d={`M 40 160 ${monthlyData.map((d, i) => {
                          const x = 40 + i * 80;
                          const y = 160 - (d.sales / maxMonthlySales) * 110;
                          return `L ${x} ${y}`;
                        }).join(' ')} L 440 160 Z`}
                        fill="rgba(242, 200, 17, 0.08)"
                      />
                    )}

                    {/* Lines */}
                    {monthlyData.length > 0 && (
                      <>
                        <path
                          d={monthlyData.map((d, i) => {
                            const x = 40 + i * 80;
                            const y = 160 - (d.sales / maxMonthlySales) * 110;
                            return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                          }).join(' ')}
                          fill="none"
                          stroke="#F2C811"
                          strokeWidth="3"
                          strokeLinecap="round"
                        />
                        <path
                          d={monthlyData.map((d, i) => {
                            const x = 40 + i * 80;
                            const y = 160 - (d.profit / maxMonthlySales) * 110;
                            return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                          }).join(' ')}
                          fill="none"
                          stroke="#4CAF50"
                          strokeWidth="2.5"
                          strokeLinecap="round"
                        />
                        {/* Data labels */}
                        {monthlyData.map((d, i) => {
                          const x = 40 + i * 80;
                          const ySales = 160 - (d.sales / maxMonthlySales) * 110;
                          return (
                            <text key={i} x={x} y={ySales - 8} textAnchor="middle" fill="#E2E2E2" className="text-[9px] font-mono font-medium">
                              ₹{Math.round(d.sales/1000)}k
                            </text>
                          );
                        })}
                      </>
                    )}
                  </svg>
                  
                  {/* Monthly Labels */}
                  <div className="flex justify-between px-10 pt-1 text-[9px] font-semibold text-gray-400 select-none">
                    {monthlyData.map((d, i) => <span key={i}>{d.label}</span>)}
                  </div>
                </div>
              </div>

              {/* Regional Sales Clustered Column Chart */}
              <div className="bg-[#292929] border border-gray-800 rounded-lg p-4 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-xs font-bold text-white font-display tracking-wide uppercase">Regional Sales Shares</h4>
                  <span className="text-[9px] text-gray-400 bg-black/25 border border-gray-800 px-2 py-0.5 rounded-sm">Chart type: Column</span>
                </div>

                <div className="grid grid-cols-5 gap-3 pt-2">
                  {regionalData.map((r, idx) => {
                    const ratio = r.sales > 0 ? (r.sales / maxRegionalSales) * 100 : 0;
                    return (
                      <div key={idx} className="flex flex-col items-center gap-2">
                        <div className="w-full bg-[#1F1F1F] h-28 rounded-md flex items-end overflow-hidden border border-gray-800">
                          <div 
                            className="w-full bg-[#1565C0] rounded-t-sm transition-all duration-700 hover:bg-blue-400 cursor-pointer" 
                            style={{ height: `${ratio}%` }}
                          />
                        </div>
                        <div className="text-center">
                          <p className="text-[10px] font-semibold text-white truncate w-14 sm:w-auto">{r.label}</p>
                          <p className="text-[9px] text-gray-400 font-mono mt-0.5">{formatCurrency(r.sales)}</p>
                        </div>
                      </div>
                    );
                  })}
                  {regionalData.length === 0 && (
                    <div className="col-span-5 text-center text-gray-400 py-10">No regional data matching active filters</div>
                  )}
                </div>
              </div>
            </div>

            {/* Right side: Categories & Order Status Funnel */}
            <div className="md:col-span-4 space-y-5">
              {/* Donut chart for Categories (Vertical bars mock) */}
              <div className="bg-[#292929] border border-gray-800 rounded-lg p-4 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-bold text-white font-display tracking-wide uppercase">Sales by Category</h4>
                  <span className="text-[9px] text-gray-400 bg-black/25 border border-gray-800 px-2 py-0.5 rounded-sm">Treemap</span>
                </div>
                
                <div className="space-y-3.5 py-1">
                  {categoryData.map((c, idx) => {
                    const ratio = kpis.totalSales > 0 ? (c.sales / kpis.totalSales) * 100 : 0;
                    // Custom colors for Power BI donut theme
                    const barColor = idx === 0 ? 'bg-[#FF6F61]' : (idx === 1 ? 'bg-[#6B5B95]' : (idx === 2 ? 'bg-[#88B04B]' : (idx === 3 ? 'bg-[#92A8D1]' : 'bg-[#F7CAC9]')));
                    return (
                      <div key={idx} className="space-y-1">
                        <div className="flex justify-between text-[10px]">
                          <span className="text-white font-medium flex items-center gap-1.5">
                            <span className={`w-2 h-2 rounded-full ${barColor}`} />
                            {c.label}
                          </span>
                          <span className="text-gray-400 font-mono">{ratio.toFixed(1)}%</span>
                        </div>
                        <div className="w-full bg-[#1F1F1F] h-1.5 rounded-full overflow-hidden border border-gray-800">
                          <div 
                            className={`h-full rounded-full ${barColor}`} 
                            style={{ width: `${ratio}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                  {categoryData.length === 0 && (
                    <p className="text-center text-gray-400 py-6">No data</p>
                  )}
                </div>
              </div>

              {/* Order Fulfillment Status donut visual */}
              <div className="bg-[#292929] border border-gray-800 rounded-lg p-4 shadow-sm">
                <h4 className="text-xs font-bold text-white font-display tracking-wide uppercase mb-3">Fulfillment & Status</h4>
                
                <div className="space-y-3 pt-1">
                  {/* Completed */}
                  <div className="bg-[#1F1F1F] p-2.5 rounded-md border border-gray-800 flex items-center justify-between">
                    <div>
                      <p className="text-[9px] font-bold text-gray-400 uppercase tracking-wide">Completed</p>
                      <p className="text-xs font-bold text-white mt-0.5">{kpis.completedOrders} Orders</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] font-semibold text-green-500 font-mono">
                        {kpis.totalOrders > 0 ? ((kpis.completedOrders / kpis.totalOrders) * 100).toFixed(1) : 0}%
                      </p>
                      <p className="text-[8px] text-gray-500 mt-0.5">Success Rate</p>
                    </div>
                  </div>

                  {/* Returned */}
                  <div className="bg-[#0f172a] p-3 rounded-lg border border-slate-800 flex items-center justify-between">
                    <div>
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wide">Returned</p>
                      <p className="text-xs font-bold text-white mt-0.5">{kpis.returnedOrders} Orders</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] font-semibold text-amber-400 font-mono">
                        {kpis.totalOrders > 0 ? ((kpis.returnedOrders / kpis.totalOrders) * 100).toFixed(1) : 0}%
                      </p>
                      <p className="text-[8px] text-slate-500 mt-0.5">Return Rate</p>
                    </div>
                  </div>

                  {/* Cancelled */}
                  <div className="bg-[#0f172a] p-3 rounded-lg border border-slate-800 flex items-center justify-between">
                    <div>
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wide">Cancelled</p>
                      <p className="text-xs font-bold text-white mt-0.5">{kpis.cancelledOrders} Orders</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] font-semibold text-rose-400 font-mono">
                        {kpis.totalOrders > 0 ? ((kpis.cancelledOrders / kpis.totalOrders) * 100).toFixed(1) : 0}%
                      </p>
                      <p className="text-[8px] text-slate-500 mt-0.5">Cancellation Rate</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Power BI Status Bar Mock */}
          <div className="mt-6 pt-3.5 border-t border-slate-800 flex items-center justify-between text-[9px] text-slate-500 font-mono select-none">
            <span>Power BI Canvas | Page 1 of 1</span>
            <span>Refreshed: Auto Live</span>
          </div>
        </div>
      )}
    </div>
  );
};
