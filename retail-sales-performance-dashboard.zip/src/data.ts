/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SalesRecord } from './types';

// --- SEED-BASED PSEUDORANDOM GENERATOR ---
// Keeps our client data in 100% sync with the backend generated spreadsheet!
let seed = 12345;
function random(): number {
  const x = Math.sin(seed++) * 10000;
  return x - Math.floor(x);
}

function randomRange(min: number, max: number): number {
  return Math.floor(random() * (max - min + 1)) + min;
}

function pickRandom<T>(arr: readonly T[]): T {
  return arr[Math.floor(random() * arr.length)];
}

const CATEGORIES = ['Electronics', 'Furniture', 'Clothing', 'Grocery', 'Office Supplies'] as const;
const REGIONS = ['North', 'South', 'East', 'West', 'Central'] as const;
const PAYMENT_METHODS = ['UPI', 'Cash', 'Credit Card', 'Debit Card', 'Bank Transfer'] as const;

interface ProductInfo {
  name: string;
  category: typeof CATEGORIES[number];
  unitPrice: number;
  costPrice: number;
}

const PRODUCTS: ProductInfo[] = [
  { name: 'Wireless Mouse', category: 'Electronics', unitPrice: 750, costPrice: 450 },
  { name: 'Headphones', category: 'Electronics', unitPrice: 2500, costPrice: 1650 },
  { name: 'Keyboard', category: 'Electronics', unitPrice: 1800, costPrice: 1200 },
  { name: 'USB Drive', category: 'Electronics', unitPrice: 650, costPrice: 400 },
  { name: 'Smart Watch', category: 'Electronics', unitPrice: 5500, costPrice: 3500 },
  { name: 'Bluetooth Speaker', category: 'Electronics', unitPrice: 2200, costPrice: 1400 },
  { name: 'Laptop Stand', category: 'Electronics', unitPrice: 1500, costPrice: 950 },
  
  { name: 'Office Chair', category: 'Furniture', unitPrice: 6500, costPrice: 4200 },
  { name: 'Coffee Table', category: 'Furniture', unitPrice: 4800, costPrice: 3300 },
  { name: 'Table Lamp', category: 'Furniture', unitPrice: 1200, costPrice: 750 },
  { name: 'Bookshelf', category: 'Furniture', unitPrice: 5500, costPrice: 3600 },
  { name: 'Study Desk', category: 'Furniture', unitPrice: 8000, costPrice: 5200 },
  
  { name: 'T-Shirt', category: 'Clothing', unitPrice: 600, costPrice: 350 },
  { name: 'Jeans', category: 'Clothing', unitPrice: 1800, costPrice: 1150 },
  { name: 'Formal Shirt', category: 'Clothing', unitPrice: 1400, costPrice: 900 },
  { name: 'Jacket', category: 'Clothing', unitPrice: 3500, costPrice: 2200 },
  { name: 'Sneakers', category: 'Clothing', unitPrice: 2500, costPrice: 1600 },
  
  { name: 'Grocery Pack', category: 'Grocery', unitPrice: 850, costPrice: 600 },
  { name: 'Snack Pack', category: 'Grocery', unitPrice: 500, costPrice: 370 },
  { name: 'Organic Tea', category: 'Grocery', unitPrice: 400, costPrice: 260 },
  { name: 'Dry Fruits Box', category: 'Grocery', unitPrice: 1200, costPrice: 850 },
  { name: 'Premium Olive Oil', category: 'Grocery', unitPrice: 950, costPrice: 650 },
  
  { name: 'Printer Paper', category: 'Office Supplies', unitPrice: 300, costPrice: 190 },
  { name: 'Notebook Set', category: 'Office Supplies', unitPrice: 450, costPrice: 280 },
  { name: 'Desk Organizer', category: 'Office Supplies', unitPrice: 900, costPrice: 575 },
  { name: 'Gel Pens Pack', category: 'Office Supplies', unitPrice: 250, costPrice: 160 },
  { name: 'Whiteboard', category: 'Office Supplies', unitPrice: 2000, costPrice: 1300 },
];

const CUSTOMERS = [
  'Rahul Sharma', 'Simran Kaur', 'Aman Patel', 'Priya Nair', 'Vikas Gupta',
  'Anjali Jain', 'Karan Singh', 'Pooja Yadav', 'Mohit Verma', 'Riya Kapoor',
  'Arjun Malhotra', 'Isha Sharma', 'Aditya Joshi', 'Neha Patel', 'Sahil Khan',
  'Deepika Padukone', 'Rohit Sharma', 'Virat Kohli', 'Aarav Mehta', 'Ananya Roy',
  'Shreya Ghoshal', 'Sandeep Reddy', 'Sneha Reddy', 'Aditya Roy', 'Vivek Oberoi',
  'Rohan Joshi', 'Tanmay Bhat', 'Tanvi Shah', 'Preeti Patel', 'Sameer Deshmukh',
  'Kiran More', 'Sunil Gavaskar', 'Sachin Tendulkar', 'Gaurav Kapoor', 'Nidhi Agrawal'
];

const SALESPEOPLE_POOL = [
  { name: 'Amit Verma', defaultRegion: 'Central' },
  { name: 'Neha Singh', defaultRegion: 'North' },
  { name: 'Rahul Mehta', defaultRegion: 'West' },
  { name: 'Priya Patel', defaultRegion: 'East' },
  { name: 'Rajesh Sharma', defaultRegion: 'South' },
];

export function getSalesRecords(): SalesRecord[] {
  const records: SalesRecord[] = [
    { Order_ID: 'ORD1001', Order_Date: '2026-01-05', Customer_Name: 'Rahul Sharma', Product: 'Wireless Mouse', Category: 'Electronics', Quantity: 2, Unit_Price: 750, Discount: 50, Sales_Amount: 1450, Cost_Amount: 900, Profit: 550, Region: 'Central', Salesperson: 'Amit Verma', Payment_Method: 'UPI', Order_Status: 'Completed' },
    { Order_ID: 'ORD1002', Order_Date: '2026-01-08', Customer_Name: 'Simran Kaur', Product: 'Office Chair', Category: 'Furniture', Quantity: 1, Unit_Price: 6500, Discount: 500, Sales_Amount: 6000, Cost_Amount: 4200, Profit: 1800, Region: 'North', Salesperson: 'Neha Singh', Payment_Method: 'Credit Card', Order_Status: 'Completed' },
    { Order_ID: 'ORD1003', Order_Date: '2026-01-12', Customer_Name: 'Aman Patel', Product: 'T-Shirt', Category: 'Clothing', Quantity: 3, Unit_Price: 600, Discount: 100, Sales_Amount: 1700, Cost_Amount: 1050, Profit: 650, Region: 'West', Salesperson: 'Rahul Mehta', Payment_Method: 'Cash', Order_Status: 'Completed' },
    { Order_ID: 'ORD1004', Order_Date: '2026-01-15', Customer_Name: 'Priya Nair', Product: 'Printer Paper', Category: 'Office Supplies', Quantity: 5, Unit_Price: 300, Discount: 50, Sales_Amount: 1450, Cost_Amount: 950, Profit: 500, Region: 'South', Salesperson: 'Neha Singh', Payment_Method: 'UPI', Order_Status: 'Completed' },
    { Order_ID: 'ORD1005', Order_Date: '2026-01-20', Customer_Name: 'Vikas Gupta', Product: 'Headphones', Category: 'Electronics', Quantity: 1, Unit_Price: 2500, Discount: 200, Sales_Amount: 2300, Cost_Amount: 1650, Profit: 650, Region: 'East', Salesperson: 'Amit Verma', Payment_Method: 'Debit Card', Order_Status: 'Completed' },
    { Order_ID: 'ORD1006', Order_Date: '2026-02-02', Customer_Name: 'Anjali Jain', Product: 'Coffee Table', Category: 'Furniture', Quantity: 1, Unit_Price: 4800, Discount: 300, Sales_Amount: 4500, Cost_Amount: 3300, Profit: 1200, Region: 'Central', Salesperson: 'Rahul Mehta', Payment_Method: 'Bank Transfer', Order_Status: 'Completed' },
    { Order_ID: 'ORD1007', Order_Date: '2026-02-05', Customer_Name: 'Karan Singh', Product: 'Jeans', Category: 'Clothing', Quantity: 2, Unit_Price: 1800, Discount: 200, Sales_Amount: 3400, Cost_Amount: 2300, Profit: 1100, Region: 'North', Salesperson: 'Neha Singh', Payment_Method: 'Credit Card', Order_Status: 'Completed' },
    { Order_ID: 'ORD1008', Order_Date: '2026-02-09', Customer_Name: 'Pooja Yadav', Product: 'Grocery Pack', Category: 'Grocery', Quantity: 4, Unit_Price: 850, Discount: 100, Sales_Amount: 3300, Cost_Amount: 2550, Profit: 750, Region: 'East', Salesperson: 'Amit Verma', Payment_Method: 'UPI', Order_Status: 'Completed' },
    { Order_ID: 'ORD1009', Order_Date: '2026-02-14', Customer_Name: 'Mohit Verma', Product: 'Keyboard', Category: 'Electronics', Quantity: 1, Unit_Price: 1800, Discount: 100, Sales_Amount: 1700, Cost_Amount: 1200, Profit: 500, Region: 'West', Salesperson: 'Rahul Mehta', Payment_Method: 'Cash', Order_Status: 'Returned' },
    { Order_ID: 'ORD1010', Order_Date: '2026-02-18', Customer_Name: 'Riya Kapoor', Product: 'Notebook Set', Category: 'Office Supplies', Quantity: 3, Unit_Price: 450, Discount: 50, Sales_Amount: 1300, Cost_Amount: 800, Profit: 500, Region: 'South', Salesperson: 'Neha Singh', Payment_Method: 'UPI', Order_Status: 'Completed' },
    { Order_ID: 'ORD1011', Order_Date: '2026-03-03', Customer_Name: 'Arjun Malhotra', Product: 'Formal Shirt', Category: 'Clothing', Quantity: 2, Unit_Price: 1400, Discount: 150, Sales_Amount: 2650, Cost_Amount: 1800, Profit: 850, Region: 'Central', Salesperson: 'Amit Verma', Payment_Method: 'Debit Card', Order_Status: 'Completed' },
    { Order_ID: 'ORD1012', Order_Date: '2026-03-07', Customer_Name: 'Isha Sharma', Product: 'Table Lamp', Category: 'Furniture', Quantity: 2, Unit_Price: 1200, Discount: 100, Sales_Amount: 2300, Cost_Amount: 1500, Profit: 800, Region: 'North', Salesperson: 'Rahul Mehta', Payment_Method: 'Credit Card', Order_Status: 'Completed' },
    { Order_ID: 'ORD1013', Order_Date: '2026-03-11', Customer_Name: 'Aditya Joshi', Product: 'USB Drive', Category: 'Electronics', Quantity: 4, Unit_Price: 650, Discount: 100, Sales_Amount: 2500, Cost_Amount: 1600, Profit: 900, Region: 'West', Salesperson: 'Neha Singh', Payment_Method: 'UPI', Order_Status: 'Completed' },
    { Order_ID: 'ORD1014', Order_Date: '2026-03-16', Customer_Name: 'Neha Patel', Product: 'Snack Pack', Category: 'Grocery', Quantity: 5, Unit_Price: 500, Discount: 100, Sales_Amount: 2400, Cost_Amount: 1850, Profit: 550, Region: 'East', Salesperson: 'Amit Verma', Payment_Method: 'Cash', Order_Status: 'Completed' },
    { Order_ID: 'ORD1015', Order_Date: '2026-03-22', Customer_Name: 'Sahil Khan', Product: 'Desk Organizer', Category: 'Office Supplies', Quantity: 2, Unit_Price: 900, Discount: 50, Sales_Amount: 1750, Cost_Amount: 1150, Profit: 600, Region: 'South', Salesperson: 'Rahul Mehta', Payment_Method: 'Bank Transfer', Order_Status: 'Cancelled' },
  ];

  // Reset seed for deterministic generation matching exactly backend
  seed = 12345;
  const startId = 1016;
  const totalRecords = 150;

  for (let i = startId; i <= 1000 + totalRecords; i++) {
    const orderId = `ORD${i}`;
    
    // Distribute date over Jan 1 to June 30, 2026
    const monthVal = randomRange(1, 6);
    const dayVal = randomRange(1, 28);
    const formattedMonth = monthVal < 10 ? `0${monthVal}` : `${monthVal}`;
    const formattedDay = dayVal < 10 ? `0${dayVal}` : `${dayVal}`;
    const orderDate = `2026-${formattedMonth}-${formattedDay}`;

    const customer = pickRandom(CUSTOMERS);
    const product = pickRandom(PRODUCTS);
    
    const qty = randomRange(1, 5);
    const unitPrice = product.unitPrice;
    
    let discount = 0;
    const rawTotal = qty * unitPrice;
    if (rawTotal >= 5000) {
      discount = pickRandom([200, 300, 400, 500]);
    } else if (rawTotal >= 2000) {
      discount = pickRandom([100, 150, 200]);
    } else if (rawTotal >= 1000) {
      discount = pickRandom([50, 100]);
    } else if (rawTotal >= 500) {
      discount = pickRandom([0, 50]);
    }

    const salesAmount = rawTotal - discount;
    const costAmount = qty * product.costPrice;
    const profit = salesAmount - costAmount;

    const region = pickRandom(REGIONS);
    
    let salespersonObj = pickRandom(SALESPEOPLE_POOL);
    const matchRegion = SALESPEOPLE_POOL.find(sp => sp.defaultRegion === region);
    if (random() > 0.2 && matchRegion) {
      salespersonObj = matchRegion;
    }
    const salesperson = salespersonObj.name;

    const paymentMethod = pickRandom(PAYMENT_METHODS);

    const statusRoll = random();
    let orderStatus: 'Completed' | 'Returned' | 'Cancelled' = 'Completed';
    if (statusRoll < 0.06) {
      orderStatus = 'Cancelled';
    } else if (statusRoll < 0.14) {
      orderStatus = 'Returned';
    }

    records.push({
      Order_ID: orderId,
      Order_Date: orderDate,
      Customer_Name: customer,
      Product: product.name,
      Category: product.category,
      Quantity: qty,
      Unit_Price: unitPrice,
      Discount: discount,
      Sales_Amount: salesAmount,
      Cost_Amount: costAmount,
      Profit: profit,
      Region: region,
      Salesperson: salesperson,
      Payment_Method: paymentMethod,
      Order_Status: orderStatus
    });
  }

  return records;
}
