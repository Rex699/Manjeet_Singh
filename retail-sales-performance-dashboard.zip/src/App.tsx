/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import { useState, useMemo } from 'react';
import { getSalesRecords } from './data';
import { DashboardFilters } from './types';
import { DashboardPreview } from './components/DashboardPreview';
import { ResumeAndPrep } from './components/ResumeAndPrep';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Download, 
  FileSpreadsheet, 
  Presentation, 
  Award, 
  Database,
  Search,
  Briefcase,
  Layers,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  Info,
  DollarSign
} from 'lucide-react';

export default function App() {
  const records = useMemo(() => getSalesRecords(), []);

  // Filter state shared with Dashboard
  const [filters, setFilters] = useState<DashboardFilters>({
    month: 'All',
    region: 'All',
    category: 'All',
    salesperson: 'All',
    orderStatus: 'All'
  });

  // Navigation tab state
  const [activeTab, setActiveTab] = useState<'dashboard' | 'explorer' | 'prep' | 'downloads'>('dashboard');
  
  // Visual Mode (Excel vs Power BI) inside the Dashboard view
  const [viewMode, setViewMode] = useState<'excel' | 'powerbi'>('excel');

  // Search query for Raw Data Explorer
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Pagination for Explorer
  const [currentPage, setCurrentPage] = useState<number>(1);
  const itemsPerPage = 12;

  // Filter records for explorer view based on search query
  const searchedRecords = useMemo(() => {
    if (!searchQuery) return records;
    const q = searchQuery.toLowerCase();
    return records.filter(r => 
      r.Order_ID.toLowerCase().includes(q) ||
      r.Customer_Name.toLowerCase().includes(q) ||
      r.Product.toLowerCase().includes(q) ||
      r.Category.toLowerCase().includes(q) ||
      r.Salesperson.toLowerCase().includes(q) ||
      r.Region.toLowerCase().includes(q) ||
      r.Payment_Method.toLowerCase().includes(q)
    );
  }, [records, searchQuery]);

  // Paginated records for explorer
  const paginatedRecords = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return searchedRecords.slice(startIndex, startIndex + itemsPerPage);
  }, [searchedRecords, currentPage]);

  const totalPages = Math.ceil(searchedRecords.length / itemsPerPage);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(val);
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-800 font-sans selection:bg-indigo-500 selection:text-white">
      {/* High-End Enterprise Top Header */}
      <header className="bg-white border-b border-slate-200/80 py-6 px-4 sm:px-6 md:px-8 shadow-[0_1px_2px_rgba(0,0,0,0.01)] select-none">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2">
              <span className="bg-slate-100 text-slate-700 text-[10px] font-semibold tracking-wider px-2.5 py-0.5 rounded-full uppercase">
                Portfolio Showcase
              </span>
              <span className="bg-indigo-50 text-indigo-700 border border-indigo-100/60 text-[10px] font-semibold tracking-wider px-2.5 py-0.5 rounded-full uppercase">
                Microsoft Excel & Power BI
              </span>
            </div>
            <h1 className="font-display font-bold text-slate-900 text-2xl sm:text-3xl tracking-tight leading-tight">
              Retail Sales Performance Dashboard
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 max-w-2xl font-medium leading-relaxed">
              Career portfolio project designed for <strong className="text-indigo-600 font-semibold">Data Analyst</strong>, <strong className="text-indigo-600 font-semibold">MIS Executive</strong>, <strong className="text-indigo-600 font-semibold">Finance Operations</strong>, and <strong className="text-indigo-600 font-semibold">Business Analyst</strong> job roles.
            </p>
          </div>

          {/* Quick Stats Banner */}
          <div className="flex gap-4 p-4 bg-white rounded-xl border border-slate-200/85 shadow-[0_1px_3px_rgba(0,0,0,0.01)] self-start md:self-auto">
            <div className="text-center px-1">
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Total Sales</p>
              <p className="font-display font-bold text-slate-950 text-base mt-0.5">₹7.63L</p>
            </div>
            <div className="w-px bg-slate-250/70 self-stretch" />
            <div className="text-center px-1">
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Net Profit</p>
              <p className="font-display font-bold text-slate-950 text-base mt-0.5">₹2.52L</p>
            </div>
            <div className="w-px bg-slate-250/70 self-stretch" />
            <div className="text-center px-1">
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Records</p>
              <p className="font-display font-bold text-slate-950 text-base mt-0.5">150</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 py-8">
        
        {/* Navigation Tabs Bar */}
        <div className="flex border-b border-slate-200 mb-6 overflow-x-auto scrollbar-none select-none">
          <button
            onClick={() => { setActiveTab('dashboard'); }}
            className={`py-3.5 px-5 text-xs font-semibold tracking-wide border-b-2 transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'dashboard'
                ? 'border-indigo-600 text-indigo-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            <Presentation className="w-4 h-4" />
            Dashboard Simulator
          </button>
          
          <button
            onClick={() => { setActiveTab('explorer'); setCurrentPage(1); }}
            className={`py-3.5 px-5 text-xs font-semibold tracking-wide border-b-2 transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'explorer'
                ? 'border-indigo-600 text-indigo-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            <Database className="w-4 h-4" />
            Interactive Data Explorer (150 Rows)
          </button>

          <button
            onClick={() => { setActiveTab('prep'); }}
            className={`py-3.5 px-5 text-xs font-semibold tracking-wide border-b-2 transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'prep'
                ? 'border-indigo-600 text-indigo-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            <Award className="w-4 h-4" />
            Career Coach & Resume Prep
          </button>

          <button
            onClick={() => { setActiveTab('downloads'); }}
            className={`py-3.5 px-5 text-xs font-semibold tracking-wide border-b-2 transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              activeTab === 'downloads'
                ? 'border-indigo-600 text-indigo-600 font-bold'
                : 'border-transparent text-slate-500 hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            <Download className="w-4 h-4" />
            Workbook Downloads
          </button>
        </div>

        {/* Tab Contents */}
        <div className="space-y-6">
          <AnimatePresence mode="wait">
            {/* 1. DASHBOARD SIMULATOR TAB */}
            {activeTab === 'dashboard' && (
              <motion.div
                key="dashboard-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.18 }}
                className="space-y-6"
              >
                {/* Visual Style Selection Banner */}
                <div className="bg-white p-5 rounded-xl border border-slate-200/80 shadow-[0_1px_3px_rgba(0,0,0,0.01)] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="font-display font-semibold text-slate-800 text-sm">Dashboard Theme Selector</h3>
                    <p className="text-xs text-slate-400 mt-0.5">Toggle between Microsoft Excel and Power BI visual templates.</p>
                  </div>

                  {/* Mode Toggles */}
                  <div className="flex gap-2 p-1 bg-slate-50 border border-slate-200 rounded-lg select-none">
                    <button
                      onClick={() => setViewMode('excel')}
                      className={`py-1.5 px-4 text-xs font-semibold rounded-md flex items-center gap-1.5 transition-all cursor-pointer ${
                        viewMode === 'excel'
                          ? 'bg-emerald-600 text-white shadow-[0_1px_2px_rgba(0,0,0,0.05)]'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                      }`}
                    >
                      <FileSpreadsheet className="w-3.5 h-3.5" />
                      Excel Worksheet
                    </button>
                    <button
                      onClick={() => setViewMode('powerbi')}
                      className={`py-1.5 px-4 text-xs font-semibold rounded-md flex items-center gap-1.5 transition-all cursor-pointer ${
                        viewMode === 'powerbi'
                          ? 'bg-amber-500 text-slate-950 shadow-[0_1px_2px_rgba(0,0,0,0.05)]'
                          : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                      }`}
                    >
                      <Presentation className="w-3.5 h-3.5" />
                      Power BI Desktop
                    </button>
                  </div>
                </div>

                {/* Dashboard Preview Render */}
                <DashboardPreview 
                  records={records} 
                  filters={filters} 
                  setFilters={setFilters} 
                  viewMode={viewMode} 
                />
              </motion.div>
            )}

            {/* 2. INTERACTIVE DATA EXPLORER TAB */}
            {activeTab === 'explorer' && (
              <motion.div
                key="explorer-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.18 }}
                className="space-y-6"
              >
                {/* Search Header Panel */}
                <div className="bg-white p-6 rounded-xl border border-slate-200/80 shadow-[0_1px_3px_rgba(0,0,0,0.01)]">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <h3 className="font-display font-semibold text-slate-800 text-base flex items-center gap-2">
                        <Database className="w-4 h-4 text-indigo-600" />
                        Explore 150 Raw Sales Records
                      </h3>
                      <p className="text-xs text-slate-400 mt-0.5">Verify cost amounts, profit formatting, discounts, and order statuses.</p>
                    </div>

                    {/* Search Input */}
                    <div className="relative max-w-sm w-full">
                      <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <input
                        type="text"
                        placeholder="Search customer, product, region, rep..."
                        value={searchQuery}
                        onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
                        className="w-full text-xs py-2 px-3.5 pl-10 rounded-lg border border-slate-200 bg-slate-50/50 text-slate-800 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none font-medium transition-all"
                      />
                    </div>
                  </div>
                </div>

                {/* Records Table Card */}
                <div className="bg-white rounded-xl border border-slate-200 shadow-[0_1px_3px_rgba(0,0,0,0.01)] overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs select-none">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold">
                          <th className="py-3.5 px-4 text-center">Order ID</th>
                          <th className="py-3.5 px-4">Date</th>
                          <th className="py-3.5 px-4">Customer</th>
                          <th className="py-3.5 px-4">Product</th>
                          <th className="py-3.5 px-4 text-center">Category</th>
                          <th className="py-3.5 px-4 text-center">Qty</th>
                          <th className="py-3.5 px-4 text-right">Unit Price</th>
                          <th className="py-3.5 px-4 text-right">Discount</th>
                          <th className="py-3.5 px-4 text-right">Sales Amount</th>
                          <th className="py-3.5 px-4 text-right">Profit</th>
                          <th className="py-3.5 px-4 text-center">Region</th>
                          <th className="py-3.5 px-4 text-center">Salesperson</th>
                          <th className="py-3.5 px-4 text-center">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-slate-600">
                        {paginatedRecords.map((r, idx) => {
                          const isProfitLoss = r.Profit < 0;
                          const isHighProfit = r.Profit >= 1500;
                          return (
                            <tr key={idx} className="hover:bg-slate-50/50 transition-all">
                              <td className="py-3 px-4 text-center font-mono font-semibold text-slate-900">{r.Order_ID}</td>
                              <td className="py-3 px-4 font-mono text-slate-400 whitespace-nowrap">{r.Order_Date}</td>
                              <td className="py-3 px-4 font-medium text-slate-800">{r.Customer_Name}</td>
                              <td className="py-3 px-4 text-slate-800 font-medium">{r.Product}</td>
                              <td className="py-3 px-4 text-center">
                                <span className="bg-slate-100 text-slate-600 text-[9px] font-semibold tracking-wider uppercase px-2 py-0.5 rounded-sm">
                                  {r.Category}
                                </span>
                              </td>
                              <td className="py-3 px-4 text-center font-mono font-medium text-slate-700">{r.Quantity}</td>
                              <td className="py-3 px-4 text-right font-mono text-slate-400">₹{r.Unit_Price}</td>
                              <td className="py-3 px-4 text-right font-mono text-rose-500 font-medium">-₹{r.Discount}</td>
                              <td className="py-3 px-4 text-right font-mono font-semibold text-slate-900">₹{r.Sales_Amount}</td>
                              <td className="py-3 px-4 text-right font-mono">
                                <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] border ${
                                  isProfitLoss 
                                    ? 'bg-rose-50 text-rose-700 border-rose-100' 
                                    : (isHighProfit ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : 'bg-indigo-50 text-indigo-700 border-indigo-100/50')
                                }`}>
                                  {r.Profit < 0 ? '-' : ''}₹{Math.abs(r.Profit)}
                                </span>
                              </td>
                              <td className="py-3 px-4 text-center">
                                <span className="text-slate-600 font-semibold">{r.Region}</span>
                              </td>
                              <td className="py-3 px-4 text-center text-slate-600 font-medium">{r.Salesperson}</td>
                              <td className="py-3 px-4 text-center">
                                <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded-sm border ${
                                  r.Order_Status === 'Completed' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' :
                                  r.Order_Status === 'Returned' ? 'bg-amber-50 text-amber-700 border-amber-100' : 'bg-rose-50 text-rose-700 border-rose-100'
                                }`}>
                                  {r.Order_Status}
                                </span>
                              </td>
                            </tr>
                          );
                        })}
                        {paginatedRecords.length === 0 && (
                          <tr>
                            <td colSpan={13} className="py-10 text-center text-gray-400">
                              No records found matching your search term.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Pagination Footer */}
                  {totalPages > 1 && (
                    <div className="bg-slate-50 border-t border-slate-200 py-3.5 px-4 flex items-center justify-between select-none">
                      <span className="text-xs text-slate-500">
                        Showing <strong className="text-slate-800 font-semibold">{(currentPage - 1) * itemsPerPage + 1}</strong> to <strong className="text-slate-800 font-semibold">{Math.min(currentPage * itemsPerPage, searchedRecords.length)}</strong> of <strong className="text-slate-800 font-semibold">{searchedRecords.length}</strong> records
                      </span>
                      <div className="flex gap-1.5">
                        <button
                          onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                          disabled={currentPage === 1}
                          className="p-1.5 border border-slate-200 rounded-lg bg-white text-slate-600 disabled:opacity-40 hover:bg-slate-50 transition-all cursor-pointer"
                        >
                          <ChevronLeft className="w-4 h-4" />
                        </button>
                        <span className="px-3.5 py-1.5 text-xs font-semibold bg-white border border-slate-200 rounded-lg text-slate-700">
                          {currentPage} / {totalPages}
                        </span>
                        <button
                          onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                          disabled={currentPage === totalPages}
                          className="p-1.5 border border-slate-200 rounded-lg bg-white text-slate-600 disabled:opacity-40 hover:bg-slate-50 transition-all cursor-pointer"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* 3. CAREER PREP HUB TAB */}
            {activeTab === 'prep' && (
              <motion.div
                key="prep-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.18 }}
              >
                <ResumeAndPrep />
              </motion.div>
            )}

            {/* 4. WORKBOOK DOWNLOADS TAB */}
            {activeTab === 'downloads' && (
              <motion.div
                key="downloads-tab"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.18 }}
                className="grid grid-cols-1 md:grid-cols-12 gap-6"
              >
                {/* Download cards */}
                <div className="md:col-span-4 space-y-4">
                  {/* CSV Card */}
                  <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-[0_1px_3px_rgba(0,0,0,0.01)] flex flex-col items-center text-center">
                    <Database className="w-10 h-10 text-indigo-600 mb-3" />
                    <h3 className="font-display font-semibold text-slate-800 text-sm">Raw Sales CSV Dataset</h3>
                    <p className="text-xs text-slate-400 mt-1 mb-5 leading-relaxed">
                      Complete, comma-separated 150 tabular transactional records suitable for importing.
                    </p>
                    <a 
                      href="/retail_sales_data.csv"
                      download="retail_sales_data.csv"
                      className="w-full py-2 px-4 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs transition-all shadow-[0_1px_2px_rgba(0,0,0,0.05)] flex items-center justify-center gap-1.5 select-none cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      Download CSV File
                    </a>
                  </div>

                  {/* Excel Card */}
                  <div className="bg-white rounded-xl border border-slate-200 p-6 shadow-[0_1px_3px_rgba(0,0,0,0.01)] flex flex-col items-center text-center">
                    <FileSpreadsheet className="w-10 h-10 text-emerald-600 mb-3" />
                    <h3 className="font-display font-semibold text-slate-800 text-sm">Polished Excel Workbook</h3>
                    <p className="text-xs text-slate-400 mt-1 mb-5 leading-relaxed">
                      Complete formatted workbook including Raw, Cleaned, Pivot summaries, and Dashboard cards.
                    </p>
                    <a 
                      href="/retail_sales_dashboard.xlsx"
                      download="retail_sales_dashboard.xlsx"
                      className="w-full py-2 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs transition-all shadow-[0_1px_2px_rgba(0,0,0,0.05)] flex items-center justify-center gap-1.5 select-none cursor-pointer"
                    >
                      <Download className="w-4 h-4" />
                      Download Excel Workbook
                    </a>
                  </div>
                </div>

                {/* Workbook Sheets Information */}
                <div className="md:col-span-8 bg-white rounded-xl border border-slate-200 p-6 shadow-[0_1px_3px_rgba(0,0,0,0.01)] space-y-4">
                  <div className="pb-3 border-b border-slate-100">
                    <h3 className="font-display font-semibold text-slate-800 text-base flex items-center gap-2">
                      <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                      Spreadsheet Architecture Details
                    </h3>
                    <p className="text-xs text-slate-400 mt-0.5">Understand the 4 worksheets in `retail_sales_dashboard.xlsx` before your interview.</p>
                  </div>

                  {/* Sheet Detail Items */}
                  <div className="space-y-3 text-xs text-slate-600">
                    {/* Sheet 1 */}
                    <div className="bg-slate-50/50 border border-slate-150 p-3.5 rounded-lg">
                      <h4 className="font-semibold text-slate-800 flex items-center gap-1.5 font-display text-[11px] uppercase tracking-wide">
                        <span className="w-1.5 h-3 bg-indigo-500 rounded-xs inline-block"></span>
                        Worksheet 1: Raw_Data
                      </h4>
                      <p className="mt-1 text-slate-500 leading-relaxed text-[11px]">
                        Holds the original tabular dataset compiled programmatically. Dates are formatted as `yyyy-mm-dd` and money values formatted as currency, acting as the single source of truth.
                      </p>
                    </div>

                    {/* Sheet 2 */}
                    <div className="bg-slate-50/50 border border-slate-150 p-3.5 rounded-lg">
                      <h4 className="font-semibold text-slate-800 flex items-center gap-1.5 font-display text-[11px] uppercase tracking-wide">
                        <span className="w-1.5 h-3 bg-indigo-500 rounded-xs inline-block"></span>
                        Worksheet 2: Cleaned_Data
                      </h4>
                      <p className="mt-1 text-slate-500 leading-relaxed text-[11px]">
                        The clean table. Formulas are set in uppercase to automatically compute Net Sales Amount (`Quantity × Price − Discount`), Profit (`Sales − Cost`), Month (`=TEXT(B2,"yyyy-mm")`), and Profit Margin percentage. Green highlights show high profits ($\ge$ ₹1,500) and red highlights flag losses.
                      </p>
                    </div>

                    {/* Sheet 3 */}
                    <div className="bg-slate-50/50 border border-slate-150 p-3.5 rounded-lg">
                      <h4 className="font-semibold text-slate-800 flex items-center gap-1.5 font-display text-[11px] uppercase tracking-wide">
                        <span className="w-1.5 h-3 bg-indigo-500 rounded-xs inline-block"></span>
                        Worksheet 3: Pivot_Analysis
                      </h4>
                      <p className="mt-1 text-slate-500 leading-relaxed text-[11px]">
                        Provides dynamic summaries using Excel logical formulas rather than standard static pivot grids. Fully equipped with `=SUMIFS`, `=COUNTIFS`, and `=AVERAGEIFS` calculations mapping monthly trend milestones, salesperson yields, category performance, and geographic distribution.
                      </p>
                    </div>

                    {/* Sheet 4 */}
                    <div className="bg-slate-50/50 border border-slate-150 p-3.5 rounded-lg">
                      <h4 className="font-semibold text-slate-800 flex items-center gap-1.5 font-display text-[11px] uppercase tracking-wide">
                        <span className="w-1.5 h-3 bg-indigo-500 rounded-xs inline-block"></span>
                        Worksheet 4: Dashboard
                      </h4>
                      <p className="mt-1 text-slate-500 leading-relaxed text-[11px]">
                        The primary executive overview sheet. Turn off Excel gridlines for a polished, clean aesthetic. Built with double-layered merged cells representing prominent KPI cards referencing dynamic formulas, along with standard instruction frames and custom slicer guide lines.
                      </p>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 mt-12 text-center text-xs text-slate-400 select-none">
        <p className="font-medium">Retail Sales Performance Dashboard Portfolio © 2026</p>
        <p className="mt-0.5">Designed specifically to pass Data Analyst and Business Operations ATS screens.</p>
      </footer>
    </div>
  );
}
