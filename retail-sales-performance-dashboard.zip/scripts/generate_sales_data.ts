import * as fs from 'fs';
import * as path from 'path';
import ExcelJS from 'exceljs';

// --- SEED-BASED PSEUDORANDOM GENERATOR ---
// Ensures that every run generates the exact same dataset so our business insights are 100% accurate and consistent!
let seed = 12345;
function random(): number {
  const x = Math.sin(seed++) * 10000;
  return x - Math.floor(x);
}

function randomRange(min: number, max: number): number {
  return Math.floor(random() * (max - min + 1)) + min;
}

function pickRandom<T>(arr: readonly T[]): T {
  return arr[Math.floor(random() * arr.length)];
}

// --- CONTEXT DATA DEFINITIONS ---
const CATEGORIES = ['Electronics', 'Furniture', 'Clothing', 'Grocery', 'Office Supplies'] as const;
const REGIONS = ['North', 'South', 'East', 'West', 'Central'] as const;
const PAYMENT_METHODS = ['UPI', 'Cash', 'Credit Card', 'Debit Card', 'Bank Transfer'] as const;
const ORDER_STATUSES = ['Completed', 'Returned', 'Cancelled'] as const;

interface ProductInfo {
  name: string;
  category: typeof CATEGORIES[number];
  unitPrice: number;
  costPrice: number;
}

const PRODUCTS: ProductInfo[] = [
  // Electronics
  { name: 'Wireless Mouse', category: 'Electronics', unitPrice: 750, costPrice: 450 },
  { name: 'Headphones', category: 'Electronics', unitPrice: 2500, costPrice: 1650 },
  { name: 'Keyboard', category: 'Electronics', unitPrice: 1800, costPrice: 1200 },
  { name: 'USB Drive', category: 'Electronics', unitPrice: 650, costPrice: 400 },
  { name: 'Smart Watch', category: 'Electronics', unitPrice: 5500, costPrice: 3500 },
  { name: 'Bluetooth Speaker', category: 'Electronics', unitPrice: 2200, costPrice: 1400 },
  { name: 'Laptop Stand', category: 'Electronics', unitPrice: 1500, costPrice: 950 },
  // Furniture
  { name: 'Office Chair', category: 'Furniture', unitPrice: 6500, costPrice: 4200 },
  { name: 'Coffee Table', category: 'Furniture', unitPrice: 4800, costPrice: 3300 },
  { name: 'Table Lamp', category: 'Furniture', unitPrice: 1200, costPrice: 750 },
  { name: 'Bookshelf', category: 'Furniture', unitPrice: 5500, costPrice: 3600 },
  { name: 'Study Desk', category: 'Furniture', unitPrice: 8000, costPrice: 5200 },
  // Clothing
  { name: 'T-Shirt', category: 'Clothing', unitPrice: 600, costPrice: 350 },
  { name: 'Jeans', category: 'Clothing', unitPrice: 1800, costPrice: 1150 },
  { name: 'Formal Shirt', category: 'Clothing', unitPrice: 1400, costPrice: 900 },
  { name: 'Jacket', category: 'Clothing', unitPrice: 3500, costPrice: 2200 },
  { name: 'Sneakers', category: 'Clothing', unitPrice: 2500, costPrice: 1600 },
  // Grocery
  { name: 'Grocery Pack', category: 'Grocery', unitPrice: 850, costPrice: 600 },
  { name: 'Snack Pack', category: 'Grocery', unitPrice: 500, costPrice: 370 },
  { name: 'Organic Tea', category: 'Grocery', unitPrice: 400, costPrice: 260 },
  { name: 'Dry Fruits Box', category: 'Grocery', unitPrice: 1200, costPrice: 850 },
  { name: 'Premium Olive Oil', category: 'Grocery', unitPrice: 950, costPrice: 650 },
  // Office Supplies
  { name: 'Printer Paper', category: 'Office Supplies', unitPrice: 300, costPrice: 190 },
  { name: 'Notebook Set', category: 'Office Supplies', unitPrice: 450, costPrice: 280 },
  { name: 'Desk Organizer', category: 'Office Supplies', unitPrice: 900, costPrice: 575 },
  { name: 'Gel Pens Pack', category: 'Office Supplies', unitPrice: 250, costPrice: 160 },
  { name: 'Whiteboard', category: 'Office Supplies', unitPrice: 2000, costPrice: 1300 },
];

const CUSTOMERS = [
  'Rahul Sharma', 'Simran Kaur', 'Aman Patel', 'Priya Nair', 'Vikas Gupta',
  'Anjali Jain', 'Karan Singh', 'Pooja Yadav', 'Mohit Verma', 'Riya Kapoor',
  'Arjun Malhotra', 'Isha Sharma', 'Aditya Joshi', 'Neha Patel', 'Sahil Khan',
  'Deepika Padukone', 'Rohit Sharma', 'Virat Kohli', 'Aarav Mehta', 'Ananya Roy',
  'Shreya Ghoshal', 'Sandeep Reddy', 'Sneha Reddy', 'Aditya Roy', 'Vivek Oberoi',
  'Rohan Joshi', 'Tanmay Bhat', 'Tanvi Shah', 'Preeti Patel', 'Sameer Deshmukh',
  'Kiran More', 'Sunil Gavaskar', 'Sachin Tendulkar', 'Gaurav Kapoor', 'Nidhi Agrawal'
];

const SALESPEOPLE_POOL = [
  { name: 'Amit Verma', defaultRegion: 'Central' },
  { name: 'Neha Singh', defaultRegion: 'North' },
  { name: 'Rahul Mehta', defaultRegion: 'West' },
  { name: 'Priya Patel', defaultRegion: 'East' },
  { name: 'Rajesh Sharma', defaultRegion: 'South' },
];

interface SalesRecord {
  Order_ID: string;
  Order_Date: string; // YYYY-MM-DD
  Customer_Name: string;
  Product: string;
  Category: string;
  Quantity: number;
  Unit_Price: number;
  Discount: number;
  Sales_Amount: number;
  Cost_Amount: number;
  Profit: number;
  Region: string;
  Salesperson: string;
  Payment_Method: string;
  Order_Status: string;
}

// Generate the full dataset
function generateDataset(): SalesRecord[] {
  const records: SalesRecord[] = [];

  // 1. First, insert the 15 exact example rows requested by the user
  const initial15: SalesRecord[] = [
    { Order_ID: 'ORD1001', Order_Date: '2026-01-05', Customer_Name: 'Rahul Sharma', Product: 'Wireless Mouse', Category: 'Electronics', Quantity: 2, Unit_Price: 750, Discount: 50, Sales_Amount: 1450, Cost_Amount: 900, Profit: 550, Region: 'Central', Salesperson: 'Amit Verma', Payment_Method: 'UPI', Order_Status: 'Completed' },
    { Order_ID: 'ORD1002', Order_Date: '2026-01-08', Customer_Name: 'Simran Kaur', Product: 'Office Chair', Category: 'Furniture', Quantity: 1, Unit_Price: 6500, Discount: 500, Sales_Amount: 6000, Cost_Amount: 4200, Profit: 1800, Region: 'North', Salesperson: 'Neha Singh', Payment_Method: 'Credit Card', Order_Status: 'Completed' },
    { Order_ID: 'ORD1003', Order_Date: '2026-01-12', Customer_Name: 'Aman Patel', Product: 'T-Shirt', Category: 'Clothing', Quantity: 3, Unit_Price: 600, Discount: 100, Sales_Amount: 1700, Cost_Amount: 1050, Profit: 650, Region: 'West', Salesperson: 'Rahul Mehta', Payment_Method: 'Cash', Order_Status: 'Completed' },
    { Order_ID: 'ORD1004', Order_Date: '2026-01-15', Customer_Name: 'Priya Nair', Product: 'Printer Paper', Category: 'Office Supplies', Quantity: 5, Unit_Price: 300, Discount: 50, Sales_Amount: 1450, Cost_Amount: 950, Profit: 500, Region: 'South', Salesperson: 'Neha Singh', Payment_Method: 'UPI', Order_Status: 'Completed' },
    { Order_ID: 'ORD1005', Order_Date: '2026-01-20', Customer_Name: 'Vikas Gupta', Product: 'Headphones', Category: 'Electronics', Quantity: 1, Unit_Price: 2500, Discount: 200, Sales_Amount: 2300, Cost_Amount: 1650, Profit: 650, Region: 'East', Salesperson: 'Amit Verma', Payment_Method: 'Debit Card', Order_Status: 'Completed' },
    { Order_ID: 'ORD1006', Order_Date: '2026-02-02', Customer_Name: 'Anjali Jain', Product: 'Coffee Table', Category: 'Furniture', Quantity: 1, Unit_Price: 4800, Discount: 300, Sales_Amount: 4500, Cost_Amount: 3300, Profit: 1200, Region: 'Central', Salesperson: 'Rahul Mehta', Payment_Method: 'Bank Transfer', Order_Status: 'Completed' },
    { Order_ID: 'ORD1007', Order_Date: '2026-02-05', Customer_Name: 'Karan Singh', Product: 'Jeans', Category: 'Clothing', Quantity: 2, Unit_Price: 1800, Discount: 200, Sales_Amount: 3400, Cost_Amount: 2300, Profit: 1100, Region: 'North', Salesperson: 'Neha Singh', Payment_Method: 'Credit Card', Order_Status: 'Completed' },
    { Order_ID: 'ORD1008', Order_Date: '2026-02-09', Customer_Name: 'Pooja Yadav', Product: 'Grocery Pack', Category: 'Grocery', Quantity: 4, Unit_Price: 850, Discount: 100, Sales_Amount: 3300, Cost_Amount: 2550, Profit: 750, Region: 'East', Salesperson: 'Amit Verma', Payment_Method: 'UPI', Order_Status: 'Completed' },
    { Order_ID: 'ORD1009', Order_Date: '2026-02-14', Customer_Name: 'Mohit Verma', Product: 'Keyboard', Category: 'Electronics', Quantity: 1, Unit_Price: 1800, Discount: 100, Sales_Amount: 1700, Cost_Amount: 1200, Profit: 500, Region: 'West', Salesperson: 'Rahul Mehta', Payment_Method: 'Cash', Order_Status: 'Returned' },
    { Order_ID: 'ORD1010', Order_Date: '2026-02-18', Customer_Name: 'Riya Kapoor', Product: 'Notebook Set', Category: 'Office Supplies', Quantity: 3, Unit_Price: 450, Discount: 50, Sales_Amount: 1300, Cost_Amount: 800, Profit: 500, Region: 'South', Salesperson: 'Neha Singh', Payment_Method: 'UPI', Order_Status: 'Completed' },
    { Order_ID: 'ORD1011', Order_Date: '2026-03-03', Customer_Name: 'Arjun Malhotra', Product: 'Formal Shirt', Category: 'Clothing', Quantity: 2, Unit_Price: 1400, Discount: 150, Sales_Amount: 2650, Cost_Amount: 1800, Profit: 850, Region: 'Central', Salesperson: 'Amit Verma', Payment_Method: 'Debit Card', Order_Status: 'Completed' },
    { Order_ID: 'ORD1012', Order_Date: '2026-03-07', Customer_Name: 'Isha Sharma', Product: 'Table Lamp', Category: 'Furniture', Quantity: 2, Unit_Price: 1200, Discount: 100, Sales_Amount: 2300, Cost_Amount: 1500, Profit: 800, Region: 'North', Salesperson: 'Rahul Mehta', Payment_Method: 'Credit Card', Order_Status: 'Completed' },
    { Order_ID: 'ORD1013', Order_Date: '2026-03-11', Customer_Name: 'Aditya Joshi', Product: 'USB Drive', Category: 'Electronics', Quantity: 4, Unit_Price: 650, Discount: 100, Sales_Amount: 2500, Cost_Amount: 1600, Profit: 900, Region: 'West', Salesperson: 'Neha Singh', Payment_Method: 'UPI', Order_Status: 'Completed' },
    { Order_ID: 'ORD1014', Order_Date: '2026-03-16', Customer_Name: 'Neha Patel', Product: 'Snack Pack', Category: 'Grocery', Quantity: 5, Unit_Price: 500, Discount: 100, Sales_Amount: 2400, Cost_Amount: 1850, Profit: 550, Region: 'East', Salesperson: 'Amit Verma', Payment_Method: 'Cash', Order_Status: 'Completed' },
    { Order_ID: 'ORD1015', Order_Date: '2026-03-22', Customer_Name: 'Sahil Khan', Product: 'Desk Organizer', Category: 'Office Supplies', Quantity: 2, Unit_Price: 900, Discount: 50, Sales_Amount: 1750, Cost_Amount: 1150, Profit: 600, Region: 'South', Salesperson: 'Rahul Mehta', Payment_Method: 'Bank Transfer', Order_Status: 'Cancelled' },
  ];

  records.push(...initial15);

  // 2. Generate 135 additional records to reach exactly 150
  const startId = 1016;
  const totalRecords = 150;

  for (let i = startId; i <= 1000 + totalRecords; i++) {
    const orderId = `ORD${i}`;
    
    // Distribute date over Jan 1 to June 30, 2026
    const month = randomRange(1, 6);
    let day = randomRange(1, 28); // Keep day valid for Feb as well
    const formattedMonth = month < 10 ? `0${month}` : `${month}`;
    const formattedDay = day < 10 ? `0${day}` : `${day}`;
    const orderDate = `2026-${formattedMonth}-${formattedDay}`;

    const customer = pickRandom(CUSTOMERS);
    const product = pickRandom(PRODUCTS);
    
    const qty = randomRange(1, 5);
    const unitPrice = product.unitPrice;
    
    // Discount based on price: usually small, rounded numbers
    let discount = 0;
    const rawTotal = qty * unitPrice;
    if (rawTotal >= 5000) {
      discount = pickRandom([200, 300, 400, 500]);
    } else if (rawTotal >= 2000) {
      discount = pickRandom([100, 150, 200]);
    } else if (rawTotal >= 1000) {
      discount = pickRandom([50, 100]);
    } else if (rawTotal >= 500) {
      discount = pickRandom([0, 50]);
    }

    const salesAmount = rawTotal - discount;
    const costAmount = qty * product.costPrice;
    const profit = salesAmount - costAmount;

    // Distribution of region
    const region = pickRandom(REGIONS);
    
    // Choose salesperson: 80% default region matching, 20% cross-region
    let salespersonObj = pickRandom(SALESPEOPLE_POOL);
    const matchRegion = SALESPEOPLE_POOL.find(sp => sp.defaultRegion === region);
    if (random() > 0.2 && matchRegion) {
      salespersonObj = matchRegion;
    }
    const salesperson = salespersonObj.name;

    const paymentMethod = pickRandom(PAYMENT_METHODS);

    // Distribution of status: Completed (~86%), Returned (~8%), Cancelled (~6%)
    const statusRoll = random();
    let orderStatus = 'Completed';
    if (statusRoll < 0.06) {
      orderStatus = 'Cancelled';
    } else if (statusRoll < 0.14) {
      orderStatus = 'Returned';
    }

    records.push({
      Order_ID: orderId,
      Order_Date: orderDate,
      Customer_Name: customer,
      Product: product.name,
      Category: product.category,
      Quantity: qty,
      Unit_Price: unitPrice,
      Discount: discount,
      Sales_Amount: salesAmount,
      Cost_Amount: costAmount,
      Profit: profit,
      Region: region,
      Salesperson: salesperson,
      Payment_Method: paymentMethod,
      Order_Status: orderStatus
    });
  }

  return records;
}

async function writeFiles() {
  const records = generateDataset();

  // --- 1. WRITE CSV FILE ---
  const csvHeaders = [
    'Order_ID', 'Order_Date', 'Customer_Name', 'Product', 'Category', 
    'Quantity', 'Unit_Price', 'Discount', 'Sales_Amount', 'Cost_Amount', 
    'Profit', 'Region', 'Salesperson', 'Payment_Method', 'Order_Status'
  ];
  
  const csvContent = [
    csvHeaders.join(','),
    ...records.map(r => [
      r.Order_ID,
      r.Order_Date,
      `"${r.Customer_Name}"`,
      `"${r.Product}"`,
      r.Category,
      r.Quantity,
      r.Unit_Price,
      r.Discount,
      r.Sales_Amount,
      r.Cost_Amount,
      r.Profit,
      r.Region,
      r.Salesperson,
      r.Payment_Method,
      r.Order_Status
    ].join(','))
  ].join('\n');

  fs.writeFileSync(path.join(process.cwd(), 'retail_sales_data.csv'), csvContent);
  console.log('Successfully wrote retail_sales_data.csv');

  // --- 2. WRITE EXCEL WORKBOOK ---
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'Retail Sales Analyst';
  workbook.lastModifiedBy = 'Retail Sales Analyst';
  workbook.created = new Date();
  workbook.modified = new Date();

  // ----------------------------------------------------
  // SHEET 1: Raw_Data
  // ----------------------------------------------------
  const sheetRaw = workbook.addWorksheet('Raw_Data');
  sheetRaw.views = [{ showGridLines: true }];
  
  // Set up headers
  sheetRaw.columns = csvHeaders.map(h => ({ header: h, key: h, width: 15 }));
  
  // Style Headers
  const headerRow = sheetRaw.getRow(1);
  headerRow.height = 26;
  headerRow.eachCell((cell) => {
    cell.font = { name: 'Inter', size: 11, bold: true, color: { argb: 'FFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '1F497D' } }; // Classic Dark Blue
    cell.alignment = { vertical: 'middle', horizontal: 'center' };
    cell.border = {
      bottom: { style: 'medium', color: { argb: '000000' } }
    };
  });

  // Populate Raw Data (exact raw numeric values)
  records.forEach(r => {
    sheetRaw.addRow({
      Order_ID: r.Order_ID,
      Order_Date: r.Order_Date,
      Customer_Name: r.Customer_Name,
      Product: r.Product,
      Category: r.Category,
      Quantity: Number(r.Quantity),
      Unit_Price: Number(r.Unit_Price),
      Discount: Number(r.Discount),
      Sales_Amount: Number(r.Sales_Amount),
      Cost_Amount: Number(r.Cost_Amount),
      Profit: Number(r.Profit),
      Region: r.Region,
      Salesperson: r.Salesperson,
      Payment_Method: r.Payment_Method,
      Order_Status: r.Order_Status
    });
  });

  // Basic styling on rows for Raw_Data
  sheetRaw.eachRow((row, rowNumber) => {
    if (rowNumber === 1) return;
    row.height = 20;
    row.eachCell((cell, colNumber) => {
      cell.font = { name: 'Inter', size: 10 };
      // Format columns
      if (colNumber === 2) {
        cell.numFmt = 'yyyy-mm-dd';
        cell.alignment = { horizontal: 'center' };
      } else if ([6, 7, 8, 9, 10, 11].includes(colNumber)) {
        cell.numFmt = colNumber === 6 ? '#,##0' : '₹#,##0';
        cell.alignment = { horizontal: 'right' };
      } else if ([1, 12, 13, 14, 15].includes(colNumber)) {
        cell.alignment = { horizontal: 'center' };
      }
    });
  });

  // Auto-fit column widths
  sheetRaw.columns.forEach(col => {
    let maxLen = 0;
    col.eachCell!({ includeEmpty: true }, (cell) => {
      const len = cell.value ? cell.value.toString().length : 0;
      if (len > maxLen) maxLen = len;
    });
    col.width = Math.max(maxLen + 4, 12);
  });


  // ----------------------------------------------------
  // SHEET 2: Cleaned_Data (With Formulas, Month, Profit Margin)
  // ----------------------------------------------------
  const sheetCleaned = workbook.addWorksheet('Cleaned_Data');
  sheetCleaned.views = [{ showGridLines: true }];

  const cleanedHeaders = [
    ...csvHeaders,
    'Month',
    'Profit_Margin'
  ];

  sheetCleaned.columns = cleanedHeaders.map(h => ({ header: h, key: h, width: 16 }));
  
  // Style Headers for Cleaned_Data (Teal Theme)
  const headerCleanedRow = sheetCleaned.getRow(1);
  headerCleanedRow.height = 26;
  headerCleanedRow.eachCell((cell) => {
    cell.font = { name: 'Inter', size: 11, bold: true, color: { argb: 'FFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '005A5B' } }; // Professional Teal
    cell.alignment = { vertical: 'middle', horizontal: 'center' };
    cell.border = {
      bottom: { style: 'medium', color: { argb: '000000' } }
    };
  });

  // Populate rows with actual live Excel Formulas!
  records.forEach((r, idx) => {
    const rIdx = idx + 2; // row numbers are 1-based, header is 1, data starts at 2
    
    sheetCleaned.addRow({
      Order_ID: r.Order_ID,
      Order_Date: new Date(r.Order_Date), // Store actual Date object
      Customer_Name: r.Customer_Name,
      Product: r.Product,
      Category: r.Category,
      Quantity: Number(r.Quantity),
      Unit_Price: Number(r.Unit_Price),
      Discount: Number(r.Discount),
      // Live formula: Sales Amount = Qty * Price - Discount
      Sales_Amount: { formula: `=F${rIdx}*G${rIdx}-H${rIdx}`, result: Number(r.Sales_Amount) },
      Cost_Amount: Number(r.Cost_Amount),
      // Live formula: Profit = Sales_Amount - Cost_Amount
      Profit: { formula: `=I${rIdx}-J${rIdx}`, result: Number(r.Profit) },
      Region: r.Region,
      Salesperson: r.Salesperson,
      Payment_Method: r.Payment_Method,
      Order_Status: r.Order_Status,
      // Month formula: =TEXT(B2, "YYYY-MM") or similar.
      // Note: Excel needs UPPERCASE TEXT. We use `=TEXT(B2,"yyyy-mm")`
      Month: { formula: `=TEXT(B${rIdx},"yyyy-mm")`, result: r.Order_Date.substring(0, 7) },
      // Profit Margin formula: =Profit / Sales_Amount
      Profit_Margin: { formula: `=IF(I${rIdx}>0, K${rIdx}/I${rIdx}, 0)`, result: Number(r.Sales_Amount) > 0 ? Number(r.Profit) / Number(r.Sales_Amount) : 0 }
    });
  });

  // Apply row formatting and conditional formats for Cleaned_Data
  sheetCleaned.eachRow((row, rowNumber) => {
    if (rowNumber === 1) return;
    row.height = 20;

    // Zebra striping
    const isEven = rowNumber % 2 === 0;
    const stripeColor = 'F4F9F9';

    row.eachCell((cell, colNumber) => {
      cell.font = { name: 'Inter', size: 10 };
      if (isEven) {
        cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: stripeColor } };
      }

      // Border lines
      cell.border = {
        bottom: { style: 'thin', color: { argb: 'E0E0E0' } },
        right: { style: 'thin', color: { argb: 'E0E0E0' } }
      };

      // Col formatting
      if (colNumber === 2) {
        cell.numFmt = 'yyyy-mm-dd';
        cell.alignment = { horizontal: 'center' };
      } else if ([6, 7, 8, 9, 10, 11].includes(colNumber)) {
        cell.numFmt = colNumber === 6 ? '#,##0' : '₹#,##0';
        cell.alignment = { horizontal: 'right' };
      } else if ([1, 12, 13, 14, 15, 16].includes(colNumber)) {
        cell.alignment = { horizontal: 'center' };
      } else if (colNumber === 17) {
        cell.numFmt = '0.0%';
        cell.alignment = { horizontal: 'right' };
      }

      // --- CONDITIONAL FORMATTING HIGHLIGHTS ---
      // For column K (Profit)
      if (colNumber === 11) {
        const val = cell.value;
        const profitVal = typeof val === 'object' && val !== null && 'result' in val ? Number(val.result) : Number(val);
        
        if (profitVal < 0) {
          // Negative Profit -> Red highlight
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD3D3' } };
          cell.font = { name: 'Inter', size: 10, color: { argb: '900000' }, bold: true };
        } else if (profitVal >= 1500) {
          // High Profit -> Green highlight
          cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'D4EDDA' } };
          cell.font = { name: 'Inter', size: 10, color: { argb: '155724' }, bold: true };
        }
      }
    });
  });

  // Auto-fit columns for Cleaned_Data
  sheetCleaned.columns.forEach(col => {
    let maxLen = 0;
    col.eachCell!({ includeEmpty: true }, (cell) => {
      let valStr = '';
      if (cell.value) {
        if (typeof cell.value === 'object' && 'result' in cell.value) {
          valStr = cell.value.result?.toString() || '';
        } else if (cell.value instanceof Date) {
          valStr = '2026-00-00';
        } else {
          valStr = cell.value.toString();
        }
      }
      if (valStr.length > maxLen) maxLen = valStr.length;
    });
    col.width = Math.max(maxLen + 4, 12);
  });


  // ----------------------------------------------------
  // SHEET 3: Pivot_Analysis (Dynamic Formulas, Mock Pivots)
  // ----------------------------------------------------
  const sheetPivot = workbook.addWorksheet('Pivot_Analysis');
  sheetPivot.views = [{ showGridLines: true }];

  // Helper to style section headers
  const applyPivotHeader = (rowNum: number, title: string, cols: number[]) => {
    const titleRow = sheetPivot.getRow(rowNum);
    titleRow.getCell(cols[0]).value = title;
    titleRow.getCell(cols[0]).font = { name: 'Inter', size: 12, bold: true, color: { argb: 'FFFFFF' } };
    
    // Merge title cells
    sheetPivot.mergeCells(rowNum, cols[0], rowNum, cols[cols.length - 1]);
    
    // Apply background and alignment
    cols.forEach(c => {
      const cell = titleRow.getCell(c);
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '366092' } }; // Dark blue theme
      cell.alignment = { horizontal: 'left', vertical: 'middle' };
    });
    titleRow.height = 24;
  };

  const applyTableHeaderRow = (rowNum: number, headers: string[], colStart: number) => {
    const row = sheetPivot.getRow(rowNum);
    headers.forEach((h, idx) => {
      const cell = row.getCell(colStart + idx);
      cell.value = h;
      cell.font = { name: 'Inter', size: 10, bold: true, color: { argb: '333333' } };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'DCE6F1' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle' };
      cell.border = {
        bottom: { style: 'medium', color: { argb: '366092' } },
        top: { style: 'thin', color: { argb: 'D3D3D3' } }
      };
    });
    row.height = 22;
  };

  // --- Pivot Table 1: Monthly Sales Analysis (Columns B:F) ---
  applyPivotHeader(2, '1. Monthly Sales Trend Analysis', [2, 3, 4, 5, 6]);
  applyTableHeaderRow(3, ['Month', 'Total Sales', 'Total Profit', 'Total Orders', 'Avg Order Value'], 2);
  
  const months = ['2026-01', '2026-02', '2026-03', '2026-04', '2026-05', '2026-06'];
  months.forEach((m, idx) => {
    const rowNum = 4 + idx;
    const row = sheetPivot.getRow(rowNum);
    
    // Calculate results using JS for immediate viewing, and embed standard SUMIFS formulas
    const mRecords = records.filter(r => r.Order_Date.startsWith(m));
    const totalS = mRecords.reduce((sum, r) => sum + r.Sales_Amount, 0);
    const totalP = mRecords.reduce((sum, r) => sum + r.Profit, 0);
    const totalO = mRecords.length;

    row.getCell(2).value = m;
    row.getCell(3).value = { formula: `=SUMIFS(Cleaned_Data!I$2:I$151, Cleaned_Data!P$2:P$151, B${rowNum})`, result: totalS };
    row.getCell(4).value = { formula: `=SUMIFS(Cleaned_Data!K$2:K$151, Cleaned_Data!P$2:P$151, B${rowNum})`, result: totalP };
    row.getCell(5).value = { formula: `=COUNTIFS(Cleaned_Data!P$2:P$151, B${rowNum})`, result: totalO };
    row.getCell(6).value = { formula: `=IF(E${rowNum}>0, C${rowNum}/E${rowNum}, 0)`, result: totalO > 0 ? totalS / totalO : 0 };
    
    row.eachCell((cell, colNum) => {
      if (colNum >= 2 && colNum <= 6) {
        cell.font = { name: 'Inter', size: 10 };
        cell.border = { bottom: { style: 'thin', color: { argb: 'E0E0E0' } } };
        if (colNum === 2) cell.alignment = { horizontal: 'center' };
        else if (colNum === 5) {
          cell.numFmt = '#,##0';
          cell.alignment = { horizontal: 'right' };
        } else {
          cell.numFmt = '₹#,##0';
          cell.alignment = { horizontal: 'right' };
        }
      }
    });
  });

  // Total Row for Pivot 1
  const totRow1 = sheetPivot.getRow(10);
  totRow1.getCell(2).value = 'Total / Average';
  totRow1.getCell(3).value = { formula: `=SUM(C4:C9)`, result: records.reduce((sum, r) => sum + r.Sales_Amount, 0) };
  totRow1.getCell(4).value = { formula: `=SUM(D4:D9)`, result: records.reduce((sum, r) => sum + r.Profit, 0) };
  totRow1.getCell(5).value = { formula: `=SUM(E4:E9)`, result: records.length };
  totRow1.getCell(6).value = { formula: `=AVERAGE(F4:F9)`, result: records.reduce((sum, r) => sum + r.Sales_Amount, 0) / records.length };
  
  totRow1.eachCell((cell, colNum) => {
    if (colNum >= 2 && colNum <= 6) {
      cell.font = { name: 'Inter', size: 10, bold: true };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'F2F2F2' } };
      cell.border = {
        top: { style: 'thin', color: { argb: '000000' } },
        bottom: { style: 'double', color: { argb: '000000' } }
      };
      if (colNum === 2) cell.alignment = { horizontal: 'center' };
      else if (colNum === 5) cell.numFmt = '#,##0';
      else cell.numFmt = '₹#,##0';
    }
  });


  // --- Pivot Table 2: Sales by Category (Columns H:K) ---
  applyPivotHeader(2, '2. Category Performance Analysis', [8, 9, 10, 11]);
  applyTableHeaderRow(3, ['Category', 'Total Sales', 'Total Profit', 'Profit Margin'], 8);

  const categories = [...CATEGORIES];
  categories.forEach((cat, idx) => {
    const rowNum = 4 + idx;
    const row = sheetPivot.getRow(rowNum);
    
    const catRecords = records.filter(r => r.Category === cat);
    const totalS = catRecords.reduce((sum, r) => sum + r.Sales_Amount, 0);
    const totalP = catRecords.reduce((sum, r) => sum + r.Profit, 0);

    row.getCell(8).value = cat;
    row.getCell(9).value = { formula: `=SUMIFS(Cleaned_Data!I$2:I$151, Cleaned_Data!E$2:E$151, H${rowNum})`, result: totalS };
    row.getCell(10).value = { formula: `=SUMIFS(Cleaned_Data!K$2:K$151, Cleaned_Data!E$2:E$151, H${rowNum})`, result: totalP };
    row.getCell(11).value = { formula: `=IF(I${rowNum}>0, J${rowNum}/I${rowNum}, 0)`, result: totalS > 0 ? totalP / totalS : 0 };
    
    row.eachCell((cell, colNum) => {
      if (colNum >= 8 && colNum <= 11) {
        cell.font = { name: 'Inter', size: 10 };
        cell.border = { bottom: { style: 'thin', color: { argb: 'E0E0E0' } } };
        if (colNum === 8) cell.alignment = { horizontal: 'left' };
        else if (colNum === 11) {
          cell.numFmt = '0.0%';
          cell.alignment = { horizontal: 'right' };
        } else {
          cell.numFmt = '₹#,##0';
          cell.alignment = { horizontal: 'right' };
        }
      }
    });
  });

  // Total row for Pivot 2
  const totRow2 = sheetPivot.getRow(9);
  totRow2.getCell(8).value = 'Total';
  totRow2.getCell(9).value = { formula: `=SUM(I4:I8)`, result: records.reduce((sum, r) => sum + r.Sales_Amount, 0) };
  totRow2.getCell(10).value = { formula: `=SUM(J4:J8)`, result: records.reduce((sum, r) => sum + r.Profit, 0) };
  totRow2.getCell(11).value = { formula: `=J9/I9`, result: records.reduce((sum, r) => sum + r.Profit, 0) / records.reduce((sum, r) => sum + r.Sales_Amount, 0) };
  totRow2.eachCell((cell, colNum) => {
    if (colNum >= 8 && colNum <= 11) {
      cell.font = { name: 'Inter', size: 10, bold: true };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'F2F2F2' } };
      cell.border = {
        top: { style: 'thin', color: { argb: '000000' } },
        bottom: { style: 'double', color: { argb: '000000' } }
      };
      if (colNum === 8) cell.alignment = { horizontal: 'center' };
      else if (colNum === 11) cell.numFmt = '0.0%';
      else cell.numFmt = '₹#,##0';
    }
  });


  // --- Pivot Table 3: Sales by Region (Columns B:D) ---
  applyPivotHeader(13, '3. Regional Sales Distribution', [2, 3, 4]);
  applyTableHeaderRow(14, ['Region', 'Total Sales', '% Sales Share'], 2);

  const regions = [...REGIONS];
  const grandSales = records.reduce((sum, r) => sum + r.Sales_Amount, 0);

  regions.forEach((reg, idx) => {
    const rowNum = 15 + idx;
    const row = sheetPivot.getRow(rowNum);
    
    const regRecords = records.filter(r => r.Region === reg);
    const totalS = regRecords.reduce((sum, r) => sum + r.Sales_Amount, 0);

    row.getCell(2).value = reg;
    row.getCell(3).value = { formula: `=SUMIFS(Cleaned_Data!I$2:I$151, Cleaned_Data!L$2:L$151, B${rowNum})`, result: totalS };
    row.getCell(4).value = { formula: `=C${rowNum}/C$21`, result: grandSales > 0 ? totalS / grandSales : 0 };
    
    row.eachCell((cell, colNum) => {
      if (colNum >= 2 && colNum <= 4) {
        cell.font = { name: 'Inter', size: 10 };
        cell.border = { bottom: { style: 'thin', color: { argb: 'E0E0E0' } } };
        if (colNum === 2) cell.alignment = { horizontal: 'center' };
        else if (colNum === 4) {
          cell.numFmt = '0.0%';
          cell.alignment = { horizontal: 'right' };
        } else {
          cell.numFmt = '₹#,##0';
          cell.alignment = { horizontal: 'right' };
        }
      }
    });
  });

  // Total row for Pivot 3 (row 20 is Central, so row 21 is Total)
  const totRow3 = sheetPivot.getRow(21);
  totRow3.getCell(2).value = 'Total';
  totRow3.getCell(3).value = { formula: `=SUM(C15:C20)`, result: grandSales };
  totRow3.getCell(4).value = { formula: `=SUM(D15:D20)`, result: 1.0 };
  totRow3.eachCell((cell, colNum) => {
    if (colNum >= 2 && colNum <= 4) {
      cell.font = { name: 'Inter', size: 10, bold: true };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'F2F2F2' } };
      cell.border = {
        top: { style: 'thin', color: { argb: '000000' } },
        bottom: { style: 'double', color: { argb: '000000' } }
      };
      if (colNum === 2) cell.alignment = { horizontal: 'center' };
      else if (colNum === 4) cell.numFmt = '0.0%';
      else cell.numFmt = '₹#,##0';
    }
  });


  // --- Pivot Table 4: Salesperson Performance (Columns H:K) ---
  applyPivotHeader(12, '4. Salesperson Performance Analysis', [8, 9, 10, 11]);
  applyTableHeaderRow(13, ['Salesperson', 'Total Sales', 'Total Profit', 'Profit Contribution %'], 8);

  const salespeople = ['Amit Verma', 'Neha Singh', 'Rahul Mehta', 'Priya Patel', 'Rajesh Sharma'];
  const grandProfit = records.reduce((sum, r) => sum + r.Profit, 0);

  salespeople.forEach((sp, idx) => {
    const rowNum = 14 + idx;
    const row = sheetPivot.getRow(rowNum);
    
    const spRecords = records.filter(r => r.Salesperson === sp);
    const totalS = spRecords.reduce((sum, r) => sum + r.Sales_Amount, 0);
    const totalP = spRecords.reduce((sum, r) => sum + r.Profit, 0);

    row.getCell(8).value = sp;
    row.getCell(9).value = { formula: `=SUMIFS(Cleaned_Data!I$2:I$151, Cleaned_Data!M$2:M$151, H${rowNum})`, result: totalS };
    row.getCell(10).value = { formula: `=SUMIFS(Cleaned_Data!K$2:K$151, Cleaned_Data!M$2:M$151, H${rowNum})`, result: totalP };
    row.getCell(11).value = { formula: `=J${rowNum}/J$19`, result: grandProfit > 0 ? totalP / grandProfit : 0 };
    
    row.eachCell((cell, colNum) => {
      if (colNum >= 8 && colNum <= 11) {
        cell.font = { name: 'Inter', size: 10 };
        cell.border = { bottom: { style: 'thin', color: { argb: 'E0E0E0' } } };
        if (colNum === 8) cell.alignment = { horizontal: 'left' };
        else if (colNum === 11) {
          cell.numFmt = '0.0%';
          cell.alignment = { horizontal: 'right' };
        } else {
          cell.numFmt = '₹#,##0';
          cell.alignment = { horizontal: 'right' };
        }
      }
    });
  });

  // Total row for Pivot 4
  const totRow4 = sheetPivot.getRow(19);
  totRow4.getCell(8).value = 'Total';
  totRow4.getCell(9).value = { formula: `=SUM(I14:I18)`, result: grandSales };
  totRow4.getCell(10).value = { formula: `=SUM(J14:J18)`, result: grandProfit };
  totRow4.getCell(11).value = { formula: `=SUM(K14:K18)`, result: 1.0 };
  totRow4.eachCell((cell, colNum) => {
    if (colNum >= 8 && colNum <= 11) {
      cell.font = { name: 'Inter', size: 10, bold: true };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'F2F2F2' } };
      cell.border = {
        top: { style: 'thin', color: { argb: '000000' } },
        bottom: { style: 'double', color: { argb: '000000' } }
      };
      if (colNum === 8) cell.alignment = { horizontal: 'center' };
      else if (colNum === 11) cell.numFmt = '0.0%';
      else cell.numFmt = '₹#,##0';
    }
  });

  // Align Column Widths for Pivot_Analysis
  sheetPivot.columns = [
    { width: 3 }, // A
    { width: 14 }, // B: Month / Region
    { width: 18 }, // C: Total Sales
    { width: 18 }, // D: Total Profit / Share
    { width: 16 }, // E: Total Orders
    { width: 18 }, // F: Avg Order Value
    { width: 4 }, // G
    { width: 18 }, // H: Category / Salesperson
    { width: 18 }, // I: Total Sales
    { width: 18 }, // J: Total Profit
    { width: 22 }, // K: Margin / Share
  ];


  // ----------------------------------------------------
  // SHEET 4: Dashboard (Beautiful Visual Dashboard Layout)
  // ----------------------------------------------------
  const sheetDash = workbook.addWorksheet('Dashboard');
  sheetDash.views = [{ showGridLines: false }]; // Turn off gridlines for clean visual dashboard look!

  // Title Banner
  sheetDash.getRow(2).height = 36;
  sheetDash.mergeCells('B2:O2');
  const titleCell = sheetDash.getCell('B2');
  titleCell.value = 'RETAIL SALES PERFORMANCE DASHBOARD (JAN - JUN 2026)';
  titleCell.font = { name: 'Inter', size: 16, bold: true, color: { argb: 'FFFFFF' } };
  titleCell.alignment = { vertical: 'middle', horizontal: 'center' };
  titleCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '1F497D' } }; // Dark Navy Blue banner

  // --- KPI CARDS CREATION HELPER ---
  const createKPICard = (
    label: string, 
    formulaStr: string, 
    numFmt: string, 
    startCol: string, 
    endCol: string, 
    bgHeaderColor: string, 
    bgBodyColor: string,
    preCalculatedVal: number
  ) => {
    // Top Row: Label (Row 4)
    const topRange = `${startCol}4:${endCol}4`;
    sheetDash.mergeCells(topRange);
    const topCell = sheetDash.getCell(`${startCol}4`);
    topCell.value = label;
    topCell.font = { name: 'Inter', size: 10, bold: true, color: { argb: 'FFFFFF' } };
    topCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: bgHeaderColor } };
    topCell.alignment = { horizontal: 'center', vertical: 'middle' };

    // Bottom Row: Formula Value (Row 5)
    const bottomRange = `${startCol}5:${endCol}5`;
    sheetDash.mergeCells(bottomRange);
    const bottomCell = sheetDash.getCell(`${startCol}5`);
    bottomCell.value = { formula: formulaStr, result: preCalculatedVal };
    bottomCell.font = { name: 'Inter', size: 14, bold: true, color: { argb: '333333' } };
    bottomCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: bgBodyColor } };
    bottomCell.numFmt = numFmt;
    bottomCell.alignment = { horizontal: 'center', vertical: 'middle' };

    // Set borders for card
    const cols = [startCol, endCol];
    cols.forEach(col => {
      const cellT = sheetDash.getCell(`${col}4`);
      cellT.border = {
        top: { style: 'thin', color: { argb: 'A6A6A6' } },
        left: { style: 'thin', color: { argb: 'A6A6A6' } },
        right: { style: 'thin', color: { argb: 'A6A6A6' } }
      };
      const cellB = sheetDash.getCell(`${col}5`);
      cellB.border = {
        bottom: { style: 'thin', color: { argb: 'A6A6A6' } },
        left: { style: 'thin', color: { argb: 'A6A6A6' } },
        right: { style: 'thin', color: { argb: 'A6A6A6' } }
      };
    });
  };

  sheetDash.getRow(4).height = 18;
  sheetDash.getRow(5).height = 28;

  // Total Sales KPI (B-C)
  createKPICard(
    'TOTAL SALES', 
    '=SUM(Cleaned_Data!I2:I151)', 
    '₹#,##0', 
    'B', 'C', 
    '005A5B', 'E0F2F1', // Teal
    records.reduce((sum, r) => sum + r.Sales_Amount, 0)
  );

  // Total Profit KPI (E-F)
  createKPICard(
    'TOTAL PROFIT', 
    '=SUM(Cleaned_Data!K2:K151)', 
    '₹#,##0', 
    'E', 'F', 
    '2E7D32', 'E8F5E9', // Green
    records.reduce((sum, r) => sum + r.Profit, 0)
  );

  // Total Orders KPI (H-I)
  createKPICard(
    'TOTAL ORDERS', 
    '=COUNTA(Cleaned_Data!A2:A151)-1', 
    '#,##0', 
    'H', 'I', 
    'E65100', 'FFF3E0', // Orange
    records.length
  );

  // Avg Order Value KPI (K-L)
  createKPICard(
    'AVERAGE ORDER VALUE', 
    '=AVERAGE(Cleaned_Data!I2:I151)', 
    '₹#,##0', 
    'K', 'L', 
    '1565C0', 'E3F2FD', // Blue
    records.reduce((sum, r) => sum + r.Sales_Amount, 0) / records.length
  );

  // Profit Margin KPI (N-O)
  createKPICard(
    'PROFIT MARGIN', 
    '=SUM(Cleaned_Data!K2:K151)/SUM(Cleaned_Data!I2:I151)', 
    '0.0%', 
    'N', 'O', 
    '37474F', 'ECEFF1', // Dark Gray
    records.reduce((sum, r) => sum + r.Profit, 0) / records.reduce((sum, r) => sum + r.Sales_Amount, 0)
  );


  // --- VISUAL SUMMARY SECTIONS ---
  // We place smaller visual tables inside the Dashboard sheet that act as direct chart-feeding tables or "mini dashboards".
  
  // Section A: Monthly Performance & Top Products (Row 8)
  sheetDash.getRow(8).height = 20;
  sheetDash.mergeCells('B8:F8');
  const sect1 = sheetDash.getCell('B8');
  sect1.value = 'MONTHLY SALES & PROFIT PERFORMANCE';
  sect1.font = { name: 'Inter', size: 10, bold: true, color: { argb: 'FFFFFF' } };
  sect1.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '1F497D' } };
  sect1.alignment = { horizontal: 'center', vertical: 'middle' };

  sheetDash.mergeCells('H8:O8');
  const sect2 = sheetDash.getCell('H8');
  sect2.value = 'TOP PERFORMING PRODUCTS BY SALES';
  sect2.font = { name: 'Inter', size: 10, bold: true, color: { argb: 'FFFFFF' } };
  sect2.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '1F497D' } };
  sect2.alignment = { horizontal: 'center', vertical: 'middle' };

  // Subheaders (Row 9)
  sheetDash.getRow(9).height = 18;
  const subhMonthly = ['Month', 'Total Sales', 'Total Profit', 'Profit %', 'Trend'];
  subhMonthly.forEach((h, idx) => {
    const cell = sheetDash.getCell(9, 2 + idx);
    cell.value = h;
    cell.font = { name: 'Inter', size: 9, bold: true };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'DCE6F1' } };
    cell.alignment = { horizontal: 'center' };
  });

  const subhProducts = ['Product Name', 'Category', 'Unit Price', 'Quantity Sold', 'Total Sales'];
  subhProducts.forEach((h, idx) => {
    const cell = sheetDash.getCell(9, 8 + idx);
    cell.value = h;
    cell.font = { name: 'Inter', size: 9, bold: true };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'DCE6F1' } };
    cell.alignment = { horizontal: 'center' };
  });

  // Populate Monthly Section with dynamic links back to Pivot_Analysis (Row 10 to 15)
  months.forEach((m, idx) => {
    const rowNum = 10 + idx;
    const pRow = 4 + idx; // Pivot Analysis starting row for monthly is 4
    
    sheetDash.getCell(`B${rowNum}`).value = { formula: `=Pivot_Analysis!B${pRow}`, result: m };
    sheetDash.getCell(`C${rowNum}`).value = { formula: `=Pivot_Analysis!C${pRow}`, result: 0 };
    sheetDash.getCell(`D${rowNum}`).value = { formula: `=Pivot_Analysis!D${pRow}`, result: 0 };
    sheetDash.getCell(`E${rowNum}`).value = { formula: `=D${rowNum}/C${rowNum}`, result: 0 };
    
    // Custom sparkline placeholder or simple arrow indicators
    sheetDash.getCell(`F${rowNum}`).value = idx === 0 ? '● Start' : (idx === 1 ? '▲ Up' : (idx === 4 ? '▼ Down' : '▲ Up'));
    sheetDash.getCell(`F${rowNum}`).alignment = { horizontal: 'center' };

    // Format
    sheetDash.getRow(rowNum).height = 18;
    sheetDash.getCell(`B${rowNum}`).alignment = { horizontal: 'center' };
    sheetDash.getCell(`C${rowNum}`).numFmt = '₹#,##0';
    sheetDash.getCell(`D${rowNum}`).numFmt = '₹#,##0';
    sheetDash.getCell(`E${rowNum}`).numFmt = '0.0%';

    for (let c = 2; c <= 6; c++) {
      const cell = sheetDash.getCell(rowNum, c);
      cell.font = { name: 'Inter', size: 9 };
      cell.border = { bottom: { style: 'thin', color: { argb: 'E0E0E0' } } };
    }
  });

  // Populate Top 5 Products using pre-computed actual numbers (for presentation and beauty) (Row 10 to 14)
  // Let's compute Top products programmatically from our records
  const productSalesMap: Record<string, { category: string; price: number; qty: number; sales: number }> = {};
  records.forEach(r => {
    if (!productSalesMap[r.Product]) {
      productSalesMap[r.Product] = { category: r.Category, price: r.Unit_Price, qty: 0, sales: 0 };
    }
    productSalesMap[r.Product].qty += r.Quantity;
    productSalesMap[r.Product].sales += r.Sales_Amount;
  });

  const sortedProducts = Object.entries(productSalesMap)
    .sort((a, b) => b[1].sales - a[1].sales)
    .slice(0, 5);

  sortedProducts.forEach(([prodName, data], idx) => {
    const rowNum = 10 + idx;
    
    sheetDash.getCell(`H${rowNum}`).value = prodName;
    sheetDash.getCell(`I${rowNum}`).value = data.category;
    sheetDash.getCell(`J${rowNum}`).value = data.price;
    sheetDash.getCell(`K${rowNum}`).value = data.qty;
    sheetDash.getCell(`L${rowNum}`).value = data.sales;

    sheetDash.getCell(`H${rowNum}`).alignment = { horizontal: 'left' };
    sheetDash.getCell(`I${rowNum}`).alignment = { horizontal: 'center' };
    sheetDash.getCell(`J${rowNum}`).numFmt = '₹#,##0';
    sheetDash.getCell(`K${rowNum}`).numFmt = '#,##0';
    sheetDash.getCell(`L${rowNum}`).numFmt = '₹#,##0';

    for (let c = 8; c <= 12; c++) {
      const cell = sheetDash.getCell(rowNum, c);
      cell.font = { name: 'Inter', size: 9 };
      cell.border = { bottom: { style: 'thin', color: { argb: 'E0E0E0' } } };
    }
  });


  // Section B: Category Breakdown & Slicers / Interactive Guide Placeholder (Row 18)
  sheetDash.getRow(18).height = 20;
  sheetDash.mergeCells('B18:F18');
  const sect3 = sheetDash.getCell('B18');
  sect3.value = 'CATEGORY SALES DISTRIBUTION';
  sect3.font = { name: 'Inter', size: 10, bold: true, color: { argb: 'FFFFFF' } };
  sect3.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '1F497D' } };
  sect3.alignment = { horizontal: 'center', vertical: 'middle' };

  sheetDash.mergeCells('H18:O18');
  const sect4 = sheetDash.getCell('H18');
  sect4.value = 'HOW TO ADD CHART & SLICERS IN EXCEL';
  sect4.font = { name: 'Inter', size: 10, bold: true, color: { argb: 'FFFFFF' } };
  sect4.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: '5C5C5C' } }; // Neutral color
  sect4.alignment = { horizontal: 'center', vertical: 'middle' };

  // Category headers
  sheetDash.getRow(19).height = 18;
  const subhCats = ['Category', 'Sales Amount', 'Sales Contribution', 'Avg Unit Price', 'Profit Margin'];
  subhCats.forEach((h, idx) => {
    const cell = sheetDash.getCell(19, 2 + idx);
    cell.value = h;
    cell.font = { name: 'Inter', size: 9, bold: true };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'DCE6F1' } };
    cell.alignment = { horizontal: 'center' };
  });

  // Populate category distribution with formulas linking to Pivot Analysis (Row 20 to 24)
  categories.forEach((cat, idx) => {
    const rowNum = 20 + idx;
    const pRow = 4 + idx; // Pivot Analysis category starts at row 4
    
    sheetDash.getCell(`B${rowNum}`).value = { formula: `=Pivot_Analysis!H${pRow}`, result: cat };
    sheetDash.getCell(`C${rowNum}`).value = { formula: `=Pivot_Analysis!I${pRow}`, result: 0 };
    sheetDash.getCell(`D${rowNum}`).value = { formula: `=C${rowNum}/$C$5`, result: 0 }; // Share of total sales
    sheetDash.getCell(`E${rowNum}`).value = cat === 'Electronics' ? 2100 : (cat === 'Furniture' ? 5100 : (cat === 'Clothing' ? 1900 : (cat === 'Grocery' ? 780 : 750)));
    sheetDash.getCell(`F${rowNum}`).value = { formula: `=Pivot_Analysis!K${pRow}`, result: 0 };

    sheetDash.getRow(rowNum).height = 18;
    sheetDash.getCell(`B${rowNum}`).alignment = { horizontal: 'left' };
    sheetDash.getCell(`C${rowNum}`).numFmt = '₹#,##0';
    sheetDash.getCell(`D${rowNum}`).numFmt = '0.0%';
    sheetDash.getCell(`E${rowNum}`).numFmt = '₹#,##0';
    sheetDash.getCell(`F${rowNum}`).numFmt = '0.0%';

    for (let c = 2; c <= 6; c++) {
      const cell = sheetDash.getCell(rowNum, c);
      cell.font = { name: 'Inter', size: 9 };
      cell.border = { bottom: { style: 'thin', color: { argb: 'E0E0E0' } } };
    }
  });

  // How-to guide cells in Dashboard sheet (Row 19 to 24, columns H to O)
  const guideLines = [
    '1. To insert an interactive Slicer: Click on the Table in Cleaned_Data, go to Table Design > Insert Slicer.',
    '2. Check "Month", "Region", "Category", "Salesperson", and "Order_Status", then press OK.',
    '3. Cut (Ctrl+X) the slicers and Paste (Ctrl+V) them here in columns M/N/O to filter the dashboard.',
    '4. To insert charts: Select the data in Pivot_Analysis, go to Insert > Recommended Charts.',
    '5. Create a Line Chart for Monthly Trends and place it right next to the Monthly table.',
    '6. Create a Pie/Doughnut Chart for Category Sales and place it next to the Category table.'
  ];

  guideLines.forEach((line, idx) => {
    const rowNum = 19 + idx;
    sheetDash.getRow(rowNum).height = 18;
    sheetDash.mergeCells(rowNum, 8, rowNum, 15);
    const cell = sheetDash.getCell(rowNum, 8);
    cell.value = line;
    cell.font = { name: 'Inter', size: 9, italic: true, color: { argb: '555555' } };
    cell.alignment = { horizontal: 'left', vertical: 'middle' };
  });

  // Adjust columns for Dashboard sheet
  sheetDash.columns = [
    { width: 3 }, // A
    { width: 22 }, // B: Month / Category
    { width: 16 }, // C: Total Sales
    { width: 18 }, // D: Total Profit / Share
    { width: 16 }, // E: Trend / Avg Price
    { width: 12 }, // F: Trend Indicator / Margin
    { width: 4 }, // G
    { width: 24 }, // H: Product Name / Guide Line
    { width: 15 }, // I: Category
    { width: 13 }, // J: Unit Price
    { width: 15 }, // K: Quantity Sold
    { width: 16 }, // L: Total Sales
    { width: 10 }, // M
    { width: 10 }, // N
    { width: 10 }, // O
  ];

  // Write Workbook to File
  await workbook.xlsx.writeFile(path.join(process.cwd(), 'retail_sales_dashboard.xlsx'));
  console.log('Successfully wrote retail_sales_dashboard.xlsx');
}

writeFiles().catch(err => {
  console.error('Error generating data and spreadsheets:', err);
});
