#!/usr/bin/env python3
"""
Senior Data Analyst Portfolio Project:
Customer Support Quality and Agent Performance Analysis

This Python script performs a comprehensive analysis of customer support ticket data.
It cleans the raw data, validates business rules, generates KPIs, performs multi-dimensional
analyses, and exports visualization charts and summary tables.

Required Libraries:
    pandas, numpy, matplotlib, seaborn
To install:
    pip install pandas numpy matplotlib seaborn
"""

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Define folder structure paths
RAW_DATA_PATH = os.path.join("..", "data", "support_tickets_raw.csv")
CLEANED_DATA_OUTPUT_PATH = os.path.join("..", "data", "support_tickets_cleaned_py.csv")
CHARTS_DIR = os.path.join("..", "outputs", "charts")
OUTPUTS_DIR = os.path.join("..", "outputs")

# Ensure output directories exist
os.makedirs(CHARTS_DIR, exist_ok=True)
os.makedirs(OUTPUTS_DIR, exist_ok=True)

print("=" * 60)
print("CUSTOMER SUPPORT QUALITY & AGENT PERFORMANCE ANALYSIS")
print("=" * 60)


# ==========================================
# STEP 1: LOAD THE TICKET DATASET
# ==========================================
print("\n[STEP 1] Loading raw ticket dataset...")
try:
    df_raw = pd.read_csv(RAW_DATA_PATH)
    print(f"✓ Dataset loaded successfully! Row count: {len(df_raw)}, Column count: {len(df_raw.columns)}")
except FileNotFoundError:
    # Fallback to local path if running from within the python folder
    RAW_DATA_PATH = os.path.join("data", "support_tickets_raw.csv")
    CLEANED_DATA_OUTPUT_PATH = os.path.join("data", "support_tickets_cleaned_py.csv")
    df_raw = pd.read_csv(RAW_DATA_PATH)
    print(f"✓ Dataset loaded from alternative path. Row count: {len(df_raw)}")


# ==========================================
# STEP 2: CHECK MISSING VALUES AND DUPLICATES
# ==========================================
print("\n[STEP 2] Performing initial data profiling...")

# 2.1 Check for Duplicate Rows
duplicate_count = df_raw.duplicated(subset=['Ticket_ID']).sum()
print(f"• Found {duplicate_count} duplicate Ticket_ID rows in the raw dataset.")

# 2.2 Check for Missing Values
missing_values = df_raw.isnull().sum()
print("• Missing values count per column:")
for col, missing_num in missing_values.items():
    if missing_num > 0:
        print(f"  - {col}: {missing_num} missing values")


# ==========================================
# STEP 3: DATA CLEANING & TYPE CORRECTION
# ==========================================
print("\n[STEP 3] Cleaning and correcting data...")

# 3.1 Remove Duplicates (keep the first occurrence)
df_cleaned = df_raw.drop_duplicates(subset=['Ticket_ID'], keep='first').copy()
print(f"• Removed duplicates. Cleaned row count: {len(df_cleaned)}")

# 3.2 Correct Data Types
df_cleaned['Ticket_Date'] = pd.to_datetime(df_cleaned['Ticket_Date'])
df_cleaned['First_Response_Minutes'] = pd.to_numeric(df_cleaned['First_Response_Minutes'], errors='coerce')
df_cleaned['Resolution_Hours'] = pd.to_numeric(df_cleaned['Resolution_Hours'], errors='coerce')
df_cleaned['SLA_Target_Hours'] = pd.to_numeric(df_cleaned['SLA_Target_Hours'], errors='coerce')
df_cleaned['Customer_Satisfaction_Score'] = pd.to_numeric(df_cleaned['Customer_Satisfaction_Score'], errors='coerce')
print("• Data types corrected: Ticket_Date to Datetime, Numeric types cast correctly.")

# 3.3 Impute Missing Customer Satisfaction Scores
# We impute the missing CSAT scores with the median CSAT score of 4.0
median_csat = df_cleaned['Customer_Satisfaction_Score'].median()
df_cleaned['Customer_Satisfaction_Score'] = df_cleaned['Customer_Satisfaction_Score'].fillna(median_csat)
print(f"• Imputed missing Customer_Satisfaction_Scores using the median: {median_csat}")


# ==========================================
# STEP 4: SLA STATUS & BUSINESS RULE VALIDATION
# ==========================================
print("\n[STEP 4] Validating business and SLA rules...")

# Recalculate and validate SLA status strictly based on Resolution Hours
# Rule: SLA Status = 'Met' if Resolution_Hours <= SLA_Target_Hours, else 'Breached'
df_cleaned['Calculated_SLA_Status'] = np.where(
    df_cleaned['Resolution_Hours'] <= df_cleaned['SLA_Target_Hours'], 'Met', 'Breached'
)

# Identify SLA mismatches in the raw data
sla_mismatches = (df_cleaned['SLA_Status'] != df_cleaned['Calculated_SLA_Status']).sum()
print(f"• Identified {sla_mismatches} SLA status mismatches in raw data. Overwriting with validated status.")
df_cleaned['SLA_Status'] = df_cleaned['Calculated_SLA_Status']
df_cleaned = df_cleaned.drop(columns=['Calculated_SLA_Status'])


# ==========================================
# STEP 5: CREATE PERFORMANCE CATEGORIES
# ==========================================
print("\n[STEP 5] Creating response and resolution performance categories...")

# 5.1 First Response Time Category
# Define bins: 0-10 min (Fast), 10-30 min (Medium), 30+ min (Slow)
response_bins = [-1, 10, 30, float('inf')]
response_labels = ['Fast (<10m)', 'Medium (10-30m)', 'Slow (30m+)']
df_cleaned['Response_Time_Category'] = pd.cut(df_cleaned['First_Response_Minutes'], bins=response_bins, labels=response_labels)

# 5.2 Resolution Time Category
# Define bins: 0-4 hours (Quick), 4-12 hours (Standard), 12+ hours (Extended)
resolution_bins = [-1, 4, 12, float('inf')]
resolution_labels = ['Quick (<4h)', 'Standard (4-12h)', 'Extended (12h+)']
df_cleaned['Resolution_Time_Category'] = pd.cut(df_cleaned['Resolution_Hours'], bins=resolution_bins, labels=resolution_labels)

print("• Performance categories created for response and resolution times.")


# ==========================================
# STEP 6: CALCULATE EXECUTIVE KPIs
# ==========================================
print("\n[STEP 6] Calculating Core Operational KPIs...")

total_tickets = len(df_cleaned)
closed_tickets = df_cleaned[df_cleaned['Ticket_Status'] == 'Closed'].shape[0]
avg_response_time = df_cleaned['First_Response_Minutes'].mean()
avg_resolution_time = df_cleaned['Resolution_Hours'].mean()

# Percentage KPIs
sla_compliance_rate = (df_cleaned[df_cleaned['SLA_Status'] == 'Met'].shape[0] / total_tickets) * 100
escalation_rate = (df_cleaned[df_cleaned['Escalated'] == 'Yes'].shape[0] / total_tickets) * 100
reopen_rate = (df_cleaned[df_cleaned['Reopened'] == 'Yes'].shape[0] / total_tickets) * 100
fcr_rate = (df_cleaned[df_cleaned['First_Contact_Resolution'] == 'Yes'].shape[0] / total_tickets) * 100
avg_csat = df_cleaned['Customer_Satisfaction_Score'].mean()

print(f"  - Total Tickets Logged:       {total_tickets}")
print(f"  - Closed Tickets:             {closed_tickets} (100% historical)")
print(f"  - Average First Response:     {avg_response_time:.1f} minutes")
print(f"  - Average Resolution Time:    {avg_resolution_time:.1f} hours")
print(f"  - SLA Compliance Rate:        {sla_compliance_rate:.1f}%")
print(f"  - Escalation Rate:            {escalation_rate:.1f}%")
print(f"  - Reopen Rate:                {reopen_rate:.1f}%")
print(f"  - First-Contact Resolution:   {fcr_rate:.1f}%")
print(f"  - Average CSAT Score:         {avg_csat:.2f} / 5.0")


# ==========================================
# STEP 7: MULTI-DIMENSIONAL ANALYSES
# ==========================================
print("\n[STEP 7] Performing in-depth analyses...")

# 7.1 Monthly Ticket Volume Trend
df_cleaned['Month_Name'] = df_cleaned['Ticket_Date'].dt.strftime('%B %Y')
df_cleaned['Month_Num'] = df_cleaned['Ticket_Date'].dt.month
monthly_volume = df_cleaned.groupby(['Month_Num', 'Month_Name']).size().reset_index(name='Total_Tickets')
print("\n• Monthly Ticket Volume:")
print(monthly_volume[['Month_Name', 'Total_Tickets']].to_string(index=False))

# 7.2 Ticket Volume and Channel Performance
channel_analysis = df_cleaned.groupby('Support_Channel').agg(
    Total_Tickets=('Ticket_ID', 'count'),
    Avg_Response_Minutes=('First_Response_Minutes', 'mean'),
    Avg_Resolution_Hours=('Resolution_Hours', 'mean'),
    FCR_Rate=('First_Contact_Resolution', lambda x: (x == 'Yes').sum() / len(x) * 100)
).reset_index()
print("\n• Support Channel Performance:")
print(channel_analysis.to_string(index=False))

# 7.3 Category-Wise Quality Summary
category_summary = df_cleaned.groupby('Issue_Category').agg(
    Total_Tickets=('Ticket_ID', 'count'),
    SLA_Compliance_Rate=('SLA_Status', lambda x: (x == 'Met').sum() / len(x) * 100),
    Escalation_Rate=('Escalated', lambda x: (x == 'Yes').sum() / len(x) * 100),
    Average_CSAT=('Customer_Satisfaction_Score', 'mean'),
    Avg_Resolution_Hours=('Resolution_Hours', 'mean')
).reset_index().sort_values(by='Total_Tickets', ascending=False)
print("\n• Category Summary:")
print(category_summary.to_string(index=False))

# 7.4 Agent Performance Summary & SLA Breaches
# Custom agent scorecard with custom-weighted score
# Normalized parameters: SLA(30%), FCR(20%), CSAT(30%), Resolution(10%), Escalation(10%)
agent_summary = df_cleaned.groupby(['Agent_ID', 'Agent_Name', 'Team']).agg(
    Total_Tickets=('Ticket_ID', 'count'),
    SLA_Compliance_Rate=('SLA_Status', lambda x: (x == 'Met').sum() / len(x) * 100),
    First_Contact_Resolution_Rate=('First_Contact_Resolution', lambda x: (x == 'Yes').sum() / len(x) * 100),
    Average_CSAT=('Customer_Satisfaction_Score', 'mean'),
    Average_Resolution_Hours=('Resolution_Hours', 'mean'),
    Escalation_Rate=('Escalated', lambda x: (x == 'Yes').sum() / len(x) * 100),
    Reopen_Rate=('Reopened', lambda x: (x == 'Yes').sum() / len(x) * 100)
).reset_index()

# SLA Breaches identifying agents with breach rates higher than 30% (SLA compliance < 70%)
sla_breach_threshold = 70.0
poor_sla_agents = agent_summary[agent_summary['SLA_Compliance_Rate'] < sla_breach_threshold].sort_values(by='SLA_Compliance_Rate')
print("\n• Agents with High SLA Breaches (SLA Compliance < 70%):")
print(poor_sla_agents[['Agent_Name', 'Team', 'Total_Tickets', 'SLA_Compliance_Rate']].to_string(index=False))

# 7.5 SLA Breaches impact on Customer Satisfaction
sla_csat_relation = df_cleaned.groupby('SLA_Status')['Customer_Satisfaction_Score'].mean().reset_index()
print("\n• SLA Status vs. Average Satisfaction Score:")
print(sla_csat_relation.to_string(index=False))


# ==========================================
# STEP 8: SAVE DATA AND SUMMARIES
# ==========================================
print("\n[STEP 8] Saving processed data and summaries to CSV files...")

# Save cleaned master data
df_cleaned.to_csv(CLEANED_DATA_OUTPUT_PATH, index=False)
print(f"✓ Saved cleaned master dataset to: {CLEANED_DATA_OUTPUT_PATH}")

# Save summarized analysis reports
category_summary.to_csv(os.path.join(OUTPUTS_DIR, "category_summary.csv"), index=False)
agent_summary.sort_values(by='Total_Tickets', ascending=False).to_csv(os.path.join(OUTPUTS_DIR, "agent_performance_py.csv"), index=False)
print("✓ Saved aggregated analytical tables to outputs/ folder.")


# ==========================================
# STEP 9: DATA VISUALIZATIONS (Matplotlib)
# ==========================================
print("\n[STEP 9] Generating visual charts using Matplotlib...")

plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
fig_color_primary = '#4F46E5' # Indigo
fig_color_accent = '#EF4444'  # Red
fig_color_neutral = '#6B7280' # Gray

# Chart 1: Monthly Ticket Volume
plt.figure(figsize=(10, 5))
plt.plot(monthly_volume['Month_Name'], monthly_volume['Total_Tickets'], marker='o', linewidth=2.5, color=fig_color_primary)
plt.title('Monthly Ticket Volume Trend (2026)', fontsize=14, fontweight='bold', pad=15)
plt.xlabel('Month', fontsize=11, labelpad=10)
plt.ylabel('Tickets Count', fontsize=11, labelpad=10)
plt.grid(True, linestyle='--', alpha=0.6)
for i, txt in enumerate(monthly_volume['Total_Tickets']):
    plt.annotate(str(txt), (monthly_volume['Month_Name'].iloc[i], monthly_volume['Total_Tickets'].iloc[i]), 
                 textcoords="offset points", xytext=(0,10), ha='center', fontweight='semibold')
plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, 'monthly_ticket_volume.png'), dpi=150)
plt.close()

# Chart 2: Ticket Volume by Issue Category
plt.figure(figsize=(10, 5))
colors = [fig_color_primary if i == 0 else '#818CF8' for i in range(len(category_summary))]
plt.bar(category_summary['Issue_Category'], category_summary['Total_Tickets'], color=colors, edgecolor='none', width=0.6)
plt.title('Ticket Volume by Issue Category', fontsize=14, fontweight='bold', pad=15)
plt.xlabel('Category', fontsize=11, labelpad=10)
plt.ylabel('Tickets Count', fontsize=11, labelpad=10)
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, 'tickets_by_category.png'), dpi=150)
plt.close()

# Chart 3: SLA Status Distribution
sla_counts = df_cleaned['SLA_Status'].value_counts()
plt.figure(figsize=(6, 6))
plt.pie(sla_counts, labels=sla_counts.index, autopct='%1.1f%%', startangle=90, 
        colors=['#10B981', '#EF4444'], textprops={'fontsize': 12, 'weight': 'bold'},
        wedgeprops={'edgecolor': 'white', 'linewidth': 2})
plt.title('Overall SLA Compliance Rate', fontsize=14, fontweight='bold', pad=15)
plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, 'sla_status_distribution.png'), dpi=150)
plt.close()

# Chart 4: SLA Status impact on Customer Satisfaction
plt.figure(figsize=(6, 5))
plt.bar(sla_csat_relation['SLA_Status'], sla_csat_relation['Customer_Satisfaction_Score'], 
        color=['#EF4444', '#10B981'], width=0.4, edgecolor='none')
plt.title('SLA Compliance impact on CSAT', fontsize=14, fontweight='bold', pad=15)
plt.xlabel('SLA Status', fontsize=11, labelpad=10)
plt.ylabel('Average CSAT Score (1-5)', fontsize=11, labelpad=10)
plt.ylim(0, 5.2)
plt.grid(axis='y', linestyle='--', alpha=0.5)
for i, val in enumerate(sla_csat_relation['Customer_Satisfaction_Score']):
    plt.annotate(f"{val:.2f} ★", (sla_csat_relation['SLA_Status'].iloc[i], val + 0.1), 
                 ha='center', fontweight='bold', fontsize=11)
plt.tight_layout()
plt.savefig(os.path.join(CHARTS_DIR, 'sla_impact_on_csat.png'), dpi=150)
plt.close()

print("✓ Charts saved successfully in outputs/charts/")
print("\n" + "=" * 60)
print("ANALYSIS WORKFLOW COMPLETED SUCCESSFULLY!")
print("=" * 60)
