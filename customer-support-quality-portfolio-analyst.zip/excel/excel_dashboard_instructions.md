# Excel Dashboard Implementation Manual
## Project: Customer Support Quality and Agent Performance Analysis

This manual provides a detailed, step-by-step workflow to construct a fully functional and visual Customer Support Dashboard in Microsoft Excel using the dataset `support_tickets_cleaned.csv`.

---

## 1. Step 1: Data Preparation & Calculated Columns

1. Open a blank Excel workbook and load `support_tickets_cleaned.csv` into a sheet named `Data`.
2. Select all loaded data and press `Ctrl + T` to convert the range into a formal **Excel Table**. Name the table `TicketsTable`.
3. Add the following columns to the right of your table to facilitate reporting. Excel will automatically apply the formula to the entire column.

### Calculated Formulas:

1.  **Response Time Category (`Response_Time_Category` in Column V):**
    Classifies how quickly the team responded to the ticket.
    ```excel
    =IF([@[First_Response_Minutes]]<=10, "Fast (<10m)", IF([@[First_Response_Minutes]]<=30, "Medium (10-30m)", "Slow (30m+)"))
    ```

2.  **Resolution Time Category (`Resolution_Time_Category` in Column W):**
    Classifies how long the issue took to close.
    ```excel
    =IF([@[Resolution_Hours]]<=4, "Quick (<4h)", IF([@[Resolution_Hours]]<=12, "Standard (4-12h)", "Extended (12h+)"))
    ```

3.  **SLA Validated Status (`SLA_Validated_Status` in Column X):**
    Re-validates the SLA Status to ensure integrity of raw inputs.
    ```excel
    =IF([@[Resolution_Hours]]<=[@[SLA_Target_Hours]], "Met", "Breached")
    ```

4.  **CSAT Score Validation with IFERROR & XLOOKUP (`Valid_CSAT` in Column Y):**
    Validates scores, handling blank/corrupt entries by defaulting to average CSAT.
    ```excel
    =IFERROR(IF(OR([@[Customer_Satisfaction_Score]]<1, [@[Customer_Satisfaction_Score]]>5), 4, [@[Customer_Satisfaction_Score]]), 4)
    ```

---

## 2. Step 2: Key Operational KPI Cards (Excel Formulas)

Create a new tab named `Dashboard`. In the top row, we will calculate our high-level KPIs using standard Excel formulas referencing the `TicketsTable` table.

*   **Total Tickets Logged:**
    ```excel
    =COUNTA(TicketsTable[Ticket_ID])
    ```
*   **Total SLA Compliant Tickets:**
    ```excel
    =COUNTIFS(TicketsTable[SLA_Validated_Status], "Met")
    ```
*   **SLA Compliance Rate (%):**
    ```excel
    =COUNTIFS(TicketsTable[SLA_Validated_Status], "Met") / COUNTA(TicketsTable[Ticket_ID])
    *(Format cell as Percentage)*
    ```
*   **Average Response Time (Min):**
    ```excel
    =AVERAGE(TicketsTable[First_Response_Minutes])
    ```
*   **Average Resolution Time (Hrs):**
    ```excel
    =AVERAGE(TicketsTable[Resolution_Hours])
    ```
*   **First-Contact Resolution (FCR) Rate:**
    ```excel
    =COUNTIFS(TicketsTable[First_Contact_Resolution], "Yes") / COUNTA(TicketsTable[Ticket_ID])
    *(Format cell as Percentage)*
    ```
*   **Average CSAT Score:**
    ```excel
    =AVERAGE(TicketsTable[Valid_CSAT])
    ```
*   **Escalation Rate:**
    ```excel
    =COUNTIFS(TicketsTable[Escalated], "Yes") / COUNTA(TicketsTable[Ticket_ID])
    *(Format cell as Percentage)*
    ```

---

## 3. Step 3: Interactive Pivot Tables & Charts

Insert a new sheet named `PivotTables` to hold your background calculations. Place these tables there and insert Pivot Charts directly onto the `Dashboard` sheet.

### Pivot Table 1: Monthly Ticket Influx & SLA Status
*   **Rows:** `Ticket_Date` (Grouped by Years & Months)
*   **Columns:** `SLA_Validated_Status`
*   **Values:** `Ticket_ID` (Summarized by Count)
*   *Pivot Chart:* **Stacked Column Chart** showing the monthly volume with color segments representing Met vs Breached SLAs.

### Pivot Table 2: Ticket Volume by Issue Category
*   **Rows:** `Issue_Category`
*   **Values:** `Ticket_ID` (Summarized by Count, sorted Largest to Smallest)
*   *Pivot Chart:* **Clustered Bar Chart** representing the volume of tickets per category.

### Pivot Table 3: Avg Resolution Time by Priority
*   **Rows:** `Priority`
*   **Values:** `Resolution_Hours` (Summarized by Average)
*   *Pivot Chart:* **Clustered Column Chart** to compare resolution times.

### Pivot Table 4: Average Customer Satisfaction by Team
*   **Rows:** `Team`
*   **Values:** `Valid_CSAT` (Summarized by Average)
*   *Pivot Chart:* **Clustered Column Chart** ranking team customer service ratings.

---

## 4. Step 4: Interactive Dashboard Slicers
Select any of your Pivot Charts on the `Dashboard` page, go to **PivotChart Analyze** -> **Insert Slicer**. Select:
*   `Region`
*   `Support_Channel`
*   `Priority`
*   `Issue_Category`

Align the slicers in a vertical bar on the left. Right-click each slicer, choose **Report Connections**, and check all pivot tables to ensure slicer selections filter the entire dashboard globally!

---

## 5. Step 5: Advanced Reports (Formulas Only)

Create a dedicated summary section below your charts on the `Dashboard` sheet.

### A. Dynamic SLA Breach Tracker
Create a table with columns: `Agent_ID`, `Agent_Name`, `Team`, `Assigned_Tickets`, `SLA_Breaches`, `Breach_Rate`.

1.  Use `XLOOKUP` to pull agent details from an existing agent list or compile agents uniquely.
2.  **Assigned Tickets Formula (Cell D40):**
    ```excel
    =COUNTIFS(TicketsTable[Agent_Name], B40)
    ```
3.  **SLA Breaches Formula (Cell E40):**
    ```excel
    =COUNTIFS(TicketsTable[Agent_Name], B40, TicketsTable[SLA_Validated_Status], "Breached")
    ```
4.  **Breach Rate Formula (Cell F40):**
    ```excel
    =IFERROR(E40 / D40, 0)
    ```

**Conditional Formatting (SLA Breach Tracker):**
Select the `Breach_Rate` cells. Go to **Conditional Formatting** -> **New Rule** -> **Format only cells that contain**. Set Cell Value **greater than** `0.30` (30%). Format with a **light red fill** (`#FEE2E2`) and **dark red text** (`#991B1B`) to instantly highlight agents struggling with speed.

### B. Agent Performance Scorecard
Compile an agent table and calculate their overall performance.

1.  **SLA Compliance (Column D):**
    ```excel
    =COUNTIFS(TicketsTable[Agent_Name], B60, TicketsTable[SLA_Validated_Status], "Met") / COUNTIFS(TicketsTable[Agent_Name], B60)
    ```
2.  **FCR Rate (Column E):**
    ```excel
    =COUNTIFS(TicketsTable[Agent_Name], B60, TicketsTable[First_Contact_Resolution], "Yes") / COUNTIFS(TicketsTable[Agent_Name], B60)
    ```
3.  **Average CSAT (Column F):**
    ```excel
    =AVERAGEIFS(TicketsTable[Valid_CSAT], TicketsTable[Agent_Name], B60)
    ```
4.  **Escalation Rate (Column G):**
    ```excel
    =COUNTIFS(TicketsTable[Agent_Name], B60, TicketsTable[Escalated], "Yes") / COUNTIFS(TicketsTable[Agent_Name], B60)
    ```
5.  **Average Resolution Hours (Column H):**
    ```excel
    =AVERAGEIFS(TicketsTable[Resolution_Hours], TicketsTable[Agent_Name], B60)
    ```
6.  **Agent Performance Score (Column I - Composite Formula):**
    We apply weights: 30% SLA, 30% CSAT, 20% FCR, 10% Speed, 10% Escalation.
    *Note: Speed is normalized against a 24-hour baseline. Escalation rate is inverted.*
    ```excel
    =(((D60)*0.3) + (((F60-1)/4)*0.3) + ((E60)*0.2) + (MAX(0, 1-(H60/24))*0.1) + ((1-G60)*0.1)) * 100
    ```

**Conditional Formatting (Agent Scorecard):**
Apply **Data Bars** to the `Agent Performance Score` column (Indigo/Blue gradient) or use **Color Scales** (Green-Yellow-Red) to visually identify top-tier and low-performing support agents.
