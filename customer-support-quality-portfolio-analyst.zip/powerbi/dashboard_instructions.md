# Power BI Dashboard Implementation Manual
## Project: Customer Support Quality and Agent Performance Analysis

This manual outlines the step-by-step construction of a high-end, executive-ready Power BI Dashboard using the generated and cleaned Customer Support ticket dataset (`support_tickets_cleaned.csv`).

---

## 1. Design System & Theme
To establish a premium, corporate aesthetic, configure your Power BI report with the following theme color palette:

*   **Primary Dark (Canvas/Text):** `#0F172A` (Slate Dark)
*   **Secondary Dark (Card Backs/Fills):** `#1E293B` (Slate Navy)
*   **Primary Brand Highlight:** `#4F46E5` (Indigo Primary)
*   **SLA Compliance Green (Success):** `#10B981` (Emerald)
*   **Breach/Escalation Red (Warning):** `#EF4444` (Coral Red)
*   **Neutral Text (Light Mode option):** `#F8FAFC` (Off-White) or `#475569` (Slate Gray)

---

## 2. Step 1: Data Connection & Model Setup
1. Open **Power BI Desktop**.
2. Click **Get Data** -> **Text/CSV**.
3. Load the `data/support_tickets_cleaned.csv` file.
4. Go to **Transform Data** (Power Query Editor) and verify:
    *   `Ticket_ID` is set to Text type.
    *   `Ticket_Date` is set to Date type.
    *   `First_Response_Minutes` and `Resolution_Hours` are set to decimal/whole numbers.
    *   `Customer_Satisfaction_Score` is set to Whole Number type.
5. Under the **Modeling** tab, click **New Table** to create an independent Calendar/Date Table for robust time-intelligence:
    ```dax
    Calendar = 
    ADDCOLUMNS(
        CALENDAR(MIN(support_tickets[Ticket_Date]), MAX(support_tickets[Ticket_Date])),
        "Year", YEAR([Date]),
        "MonthNumber", MONTH([Date]),
        "MonthName", FORMAT([Date], "MMMM"),
        "MonthYear", FORMAT([Date], "MMM YYYY"),
        "Quarter", "Q" & FORMAT([Date], "Q")
    )
    ```
6. Switch to the **Model View** and establish a **1-to-many relationship** from `Calendar[Date]` (1) to `support_tickets[Ticket_Date]` (*).

---

## 3. Step 2: Custom DAX Measures
Create a dedicated table named `_Measures` and insert the following calculated metrics:

### Core Operational Measures

1.  **Total Tickets:**
    ```dax
    Total Tickets = COUNT(support_tickets[Ticket_ID])
    ```

2.  **Average Response Time (Minutes):**
    ```dax
    Avg Response Time = AVERAGE(support_tickets[First_Response_Minutes])
    ```

3.  **Average Resolution Time (Hours):**
    ```dax
    Avg Resolution Time = AVERAGE(support_tickets[Resolution_Hours])
    ```

4.  **SLA Compliance Rate (%):**
    ```dax
    SLA Compliance Rate = 
    DIVIDE(
        CALCULATE(COUNT(support_tickets[Ticket_ID]), support_tickets[SLA_Status] = "Met"),
        [Total Tickets],
        0
    )
    ```

5.  **First-Contact Resolution (FCR) Rate (%):**
    ```dax
    FCR Rate = 
    DIVIDE(
        CALCULATE(COUNT(support_tickets[Ticket_ID]), support_tickets[First_Contact_Resolution] = "Yes"),
        [Total Tickets],
        0
    )
    ```

6.  **Escalation Rate (%):**
    ```dax
    Escalation Rate = 
    DIVIDE(
        CALCULATE(COUNT(support_tickets[Ticket_ID]), support_tickets[Escalated] = "Yes"),
        [Total Tickets],
        0
    )
    ```

7.  **Reopen Rate (%):**
    ```dax
    Reopen Rate = 
    DIVIDE(
        CALCULATE(COUNT(support_tickets[Ticket_ID]), support_tickets[Reopened] = "Yes"),
        [Total Tickets],
        0
    )
    ```

8.  **Average CSAT Score (1-5):**
    ```dax
    Average CSAT = AVERAGE(support_tickets[Customer_Satisfaction_Score])
    ```

9.  **Agent Performance Score (Formula):**
    A composite index (0-100) combining quality, compliance, and speed. Sla compliance counts for 30%, CSAT 30%, FCR 20%, Speed 10%, Escalation 10%.
    ```dax
    Agent Performance Score = 
    VAR NormSLA = [SLA Compliance Rate]
    VAR NormCSAT = DIVIDE([Average CSAT] - 1, 4, 0)
    VAR NormFCR = [FCR Rate]
    VAR NormSpeed = IF(AVERAGE(support_tickets[Resolution_Hours]) < 24, 1 - (AVERAGE(support_tickets[Resolution_Hours]) / 24), 0)
    VAR NormEsc = 1 - [Escalation Rate]
    RETURN
    ((NormSLA * 0.3) + (NormCSAT * 0.3) + (NormFCR * 0.2) + (NormSpeed * 0.1) + (NormEsc * 0.1)) * 100
    ```

---

## 4. Step 3: Layout & Visualizations Setup

Construct your Canvas using a modern **Bento Grid** card structure. Set the canvas background to Light Slate (`#F8FAFC`) with card visuals using a white background, rounded corners (8px), and a subtle drop shadow.

### A. Top Executive KPI Bar
*   **Total Tickets:** Card visual using `[Total Tickets]`
*   **Avg Response:** Card visual using `[Avg Response Time]` (suffix "Min")
*   **Avg Resolution:** Card visual using `[Avg Resolution Time]` (suffix "Hrs")
*   **SLA Compliance:** Card visual using `[SLA Compliance Rate]` formatted as Percentage. Apply **Conditional Formatting** to turn green (`#10B981`) if `>= 85%`, otherwise red (`#EF4444`).
*   **FCR Rate:** Card visual using `[FCR Rate]` formatted as Percentage.
*   **Escalation Rate:** Card visual using `[Escalation Rate]` formatted as Percentage.
*   **Average CSAT:** Card visual using `[Average CSAT]` formatted with 2 decimal places.

### B. Core Operational Performance Visuals
1.  **Monthly Ticket Volume Trend:**
    *   *Visual:* **Area Chart** or **Line Chart**
    *   *X-Axis:* `Calendar[MonthYear]` (Sorted by `MonthNumber`)
    *   *Y-Axis:* `[Total Tickets]`
    *   *Design:* Use Indigo (`#4F46E5`) with 20% area transparency. Smooth lines.
2.  **Ticket Volume by Category:**
    *   *Visual:* **Clustered Bar Chart**
    *   *Y-Axis:* `support_tickets[Issue_Category]`
    *   *X-Axis:* `[Total Tickets]`
    *   *Design:* Data labels active. Order from highest to lowest.
3.  **SLA Status Distribution:**
    *   *Visual:* **Donut Chart**
    *   *Legend:* `support_tickets[SLA_Status]`
    *   *Values:* `[Total Tickets]`
    *   *Colors:* "Met" = Green (`#10B981`), "Breached" = Red (`#EF4444`).
4.  **Average Resolution Time by Priority:**
    *   *Visual:* **Column Chart**
    *   *X-Axis:* `support_tickets[Priority]` (Sort order: Critical, High, Medium, Low)
    *   *Y-Axis:* `[Avg Resolution Time]`
    *   *Design:* Highlight "Critical" column with Coral Red (`#EF4444`).

### C. Category & Team Insights
1.  **Customer Satisfaction by Team:**
    *   *Visual:* **Clustered Column Chart**
    *   *X-Axis:* `support_tickets[Team]`
    *   *Y-Axis:* `[Average CSAT]`
2.  **Escalation Rate by Issue Category:**
    *   *Visual:* **Line and Stacked Column Chart**
    *   *Columns:* `[Total Tickets]` by `Issue_Category`
    *   *Line:* `[Escalation Rate]`
3.  **Reopened Tickets by Category:**
    *   *Visual:* **Treemap**
    *   *Group:* `support_tickets[Issue_Category]`
    *   *Values:* `[Reopen Rate]`
4.  **Support-Channel Performance Matrix:**
    *   *Visual:* **Matrix Visual**
    *   *Rows:* `support_tickets[Support_Channel]`
    *   *Values:* `[Total Tickets]`, `[Avg Response Time]`, `[Avg Resolution Time]`, `[SLA Compliance Rate]`
    *   *Formatting:* Apply gradient conditional colors to the SLA Compliance Rate column.

### D. Agent Performance Scorecard
*   *Visual:* **Table Visual** (with interactive sort)
*   *Columns:* `Agent_Name`, `Team`, `Total Tickets`, `SLA Compliance Rate`, `FCR Rate`, `Average CSAT`, `Agent Performance Score`
*   *Sorting:* Sort descending by `Agent Performance Score` to reveal top performers.

---

## 5. Step 4: Interactive Filter Panel (Slicers)
Group the following slicers in a collapsible side navigation bar or a clean top panel:
*   **Date:** Range Slicer (`Calendar[Date]`)
*   **Region:** Dropdown Slicer (`support_tickets[Region]`)
*   **Team:** Dropdown Slicer (`support_tickets[Team]`)
*   **Priority:** Horizontal Tile Slicer (`support_tickets[Priority]`)
*   **Support Channel:** Horizontal Tile Slicer (`support_tickets[Support_Channel]`)
*   **Issue Category:** Dropdown Slicer (`support_tickets[Issue_Category]`)

---

## 6. Business Scenarios to Verify
Once built, use the dashboard filters to verify these insights:
1.  Select **Priority = Critical**. Check if average resolution time drops below 5 hours and SLA status complies with tight limits.
2.  Select **SLA Status = Breached**. Observe how average customer satisfaction (CSAT) drops significantly below 2.5 compared to "Met" tickets (which are above 4.0).
3.  Sort the **Agent Performance Scorecard**. Identify high performers like **Sakshi Jain** or **Rohit Verma**, and agents with high SLA breach rates like **Vikas Kumar** or **Rahul Roy** who need training.
