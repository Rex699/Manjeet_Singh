import React, { useState } from 'react';
import { Ticket } from './types';
import ticketsData from './data/tickets.json';

// Import Modular Components
import Dashboard from './components/Dashboard';
import AgentLeaderboard from './components/AgentLeaderboard';
import DataExplorer from './components/DataExplorer';
import CodeExplorer from './components/CodeExplorer';
import CareerPrep from './components/CareerPrep';

// Icons
import { 
  BarChart3, Trophy, Database, FileCode, GraduationCap, Briefcase, Download, ExternalLink, Calendar, Users
} from 'lucide-react';

const tickets = ticketsData as Ticket[];

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'leaderboard' | 'explorer' | 'code' | 'career'>('dashboard');

  return (
    <div className="h-screen w-full flex flex-col bg-slate-50 font-sans text-slate-900 overflow-hidden">
      
      {/* GLOBAL SLEEK INTERFACE HEADER */}
      <header className="flex items-center justify-between border-b border-slate-200 bg-white px-8 py-4 shrink-0">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white font-bold select-none">A</div>
          <div>
            <h1 id="main-title" className="text-base md:text-lg font-bold tracking-tight text-slate-950 flex items-center gap-1.5">
              Customer Support Quality
              <span className="text-slate-400 font-normal ml-1 hidden sm:inline">| Data Portfolio v1.0</span>
            </h1>
            <p className="text-[11px] text-slate-500 font-normal">
              Automated operational analytics across 1,520 unique customer support tickets (H1 2026)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex flex-col items-end">
            <span className="text-xs font-semibold text-indigo-600 uppercase tracking-wider">Operations Analyst</span>
            <span className="text-sm font-medium text-slate-700">Portfolio Project Dashboard</span>
          </div>
          <div className="h-10 w-10 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center select-none font-bold text-slate-700 text-xs">
            SA
          </div>
        </div>
      </header>

      {/* MAIN TWO-PANEL INTERFACE LAYOUT */}
      <div className="flex flex-1 overflow-hidden">
        
        {/* Navigation Sidebar */}
        <aside className="w-64 border-r border-slate-200 bg-white p-6 flex flex-col gap-8 shrink-0">
          <nav className="flex flex-col gap-1.5">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">Project Sections</div>
            
            <button
              id="tab-dashboard"
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-xs font-semibold transition cursor-pointer text-left w-full ${
                activeTab === 'dashboard' 
                  ? 'bg-indigo-50 text-indigo-600 font-bold' 
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <BarChart3 size={15} />
              <span>Executive Dashboard</span>
            </button>

            <button
              id="tab-leaderboard"
              onClick={() => setActiveTab('leaderboard')}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-xs font-semibold transition cursor-pointer text-left w-full ${
                activeTab === 'leaderboard' 
                  ? 'bg-indigo-50 text-indigo-600 font-bold' 
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <Trophy size={15} />
              <span>Agent Leaderboard</span>
            </button>

            <button
              id="tab-explorer"
              onClick={() => setActiveTab('explorer')}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-xs font-semibold transition cursor-pointer text-left w-full ${
                activeTab === 'explorer' 
                  ? 'bg-indigo-50 text-indigo-600 font-bold' 
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <Database size={15} />
              <span>Data Grid Explorer</span>
            </button>

            <button
              id="tab-code"
              onClick={() => setActiveTab('code')}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-xs font-semibold transition cursor-pointer text-left w-full ${
                activeTab === 'code' 
                  ? 'bg-indigo-50 text-indigo-600 font-bold' 
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <FileCode size={15} />
              <span>Python & SQL Code</span>
            </button>

            <button
              id="tab-career"
              onClick={() => setActiveTab('career')}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-xs font-semibold transition cursor-pointer text-left w-full ${
                activeTab === 'career' 
                  ? 'bg-indigo-50 text-indigo-600 font-bold' 
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <GraduationCap size={15} />
              <span>Recruiter Prep Zone</span>
            </button>
          </nav>

          {/* Tools Used section in sidebar */}
          <div className="mt-auto rounded-xl bg-slate-950 p-4 text-white border border-slate-800">
            <div className="text-xs font-bold uppercase tracking-widest text-slate-400 mb-2">Tools Used</div>
            <div className="grid grid-cols-2 gap-2 text-slate-300">
              <span className="rounded bg-white/10 px-2 py-1 text-[10px] text-center font-semibold">Python</span>
              <span className="rounded bg-white/10 px-2 py-1 text-[10px] text-center font-semibold">Pandas</span>
              <span className="rounded bg-white/10 px-2 py-1 text-[10px] text-center font-semibold">SQL</span>
              <span className="rounded bg-white/10 px-2 py-1 text-[10px] text-center font-semibold">Power BI</span>
            </div>
          </div>
        </aside>

        {/* Scrollable Content Container */}
        <main className="flex-1 overflow-y-auto bg-slate-50 p-8 flex flex-col gap-6">
          
          {/* Active section view content */}
          <div className="flex-1">
            {activeTab === 'dashboard' && <Dashboard tickets={tickets} />}
            {activeTab === 'leaderboard' && <AgentLeaderboard tickets={tickets} />}
            {activeTab === 'explorer' && <DataExplorer tickets={tickets} />}
            {activeTab === 'code' && <CodeExplorer />}
            {activeTab === 'career' && <CareerPrep />}
          </div>

          {/* INTEGRATED PORTFOLIO FOOTER */}
          <footer className="bg-white border border-slate-200 rounded-xl py-4 px-6 mt-auto text-xs text-slate-500 flex flex-col sm:flex-row justify-between items-center gap-3 shrink-0 shadow-xs">
            <div>
              <span>Data Analyst Operations Case-Study Portfolio &copy; 2026.</span>
              <span className="text-[10px] text-slate-400 block mt-0.5">
                Formulated according to actual service level parameters and support operations constraints.
              </span>
            </div>
            <div className="flex gap-4">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Validated in PostgreSQL 14, Python 3.10 & Excel 365</span>
            </div>
          </footer>

        </main>
      </div>

    </div>
  );
}
