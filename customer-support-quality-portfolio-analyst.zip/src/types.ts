/**
 * Shared Type Definitions for Customer Support Analytics Portfolio
 */

export interface Ticket {
  Ticket_ID: string;
  Customer_ID: string;
  Ticket_Date: string; // YYYY-MM-DD
  Customer_Name: string;
  Support_Channel: 'Email' | 'Chat' | 'Phone' | 'Social Media';
  Issue_Category: 'Payment' | 'Refund' | 'Delivery' | 'Account' | 'Product' | 'Technical' | 'Cancellation';
  Issue_Subcategory: string;
  Priority: 'Low' | 'Medium' | 'High' | 'Critical';
  Agent_ID: string;
  Agent_Name: string;
  Team: string;
  First_Response_Minutes: number;
  Resolution_Hours: number;
  SLA_Target_Hours: number;
  SLA_Status: 'Met' | 'Breached';
  Escalated: 'Yes' | 'No';
  First_Contact_Resolution: 'Yes' | 'No';
  Reopened: 'Yes' | 'No';
  Customer_Satisfaction_Score: number; // 1-5
  Ticket_Status: 'Closed';
  Region: 'North' | 'South' | 'East' | 'West' | 'Central';
}

export interface FilterState {
  regions: string[];
  channels: string[];
  categories: string[];
  priorities: string[];
  teams: string[];
  agents: string[];
  startDate: string;
  endDate: string;
}

export interface MetricCard {
  title: string;
  value: string | number;
  sub: string;
  icon: string;
  trend?: {
    value: string;
    isPositive: boolean;
  };
}

export interface ScoreWeights {
  sla: number;
  csat: number;
  fcr: number;
  speed: number;
  escalation: number;
}
