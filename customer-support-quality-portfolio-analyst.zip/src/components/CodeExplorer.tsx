import React, { useState } from 'react';
import { FileCode, Database, Check, Copy, BookOpen } from 'lucide-react';

export default function CodeExplorer() {
  const [activeTab, setActiveTab] = useState<'python' | 'sql'>('python');
  const [copied, setCopied] = useState(false);

  const pythonCode = `#!/usr/bin/env python3
# Data Analyst Portfolio Project: Python Cleaning & Analysis Workflow

import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 1. Load raw CSV data
df_raw = pd.read_csv("../data/support_tickets_raw.csv")

# 2. Handle duplicates (based on Ticket_ID)
duplicate_count = df_raw.duplicated(subset=['Ticket_ID']).sum()
df_cleaned = df_raw.drop_duplicates(subset=['Ticket_ID'], keep='first').copy()

# 3. Handle data types
df_cleaned['Ticket_Date'] = pd.to_datetime(df_cleaned['Ticket_Date'])
df_cleaned['First_Response_Minutes'] = pd.to_numeric(df_cleaned['First_Response_Minutes'], errors='coerce')
df_cleaned['Resolution_Hours'] = pd.to_numeric(df_cleaned['Resolution_Hours'], errors='coerce')
df_cleaned['Customer_Satisfaction_Score'] = pd.to_numeric(df_cleaned['Customer_Satisfaction_Score'], errors='coerce')

# 4. Impute missing CSAT scores with median (4.0)
median_csat = df_cleaned['Customer_Satisfaction_Score'].median()
df_cleaned['Customer_Satisfaction_Score'] = df_cleaned['Customer_Satisfaction_Score'].fillna(median_csat)

# 5. Strict SLA Status Validation
df_cleaned['SLA_Status'] = np.where(
    df_cleaned['Resolution_Hours'] <= df_cleaned['SLA_Target_Hours'], 'Met', 'Breached'
)

# 6. Performance Categorization
response_bins = [-1, 10, 30, float('inf')]
response_labels = ['Fast (<10m)', 'Medium (10-30m)', 'Slow (30m+)']
df_cleaned['Response_Time_Category'] = pd.cut(df_cleaned['First_Response_Minutes'], bins=response_bins, labels=response_labels)

# 7. Aggregate operational reports & Save
category_summary = df_cleaned.groupby('Issue_Category').agg(
    Total_Tickets=('Ticket_ID', 'count'),
    SLA_Compliance_Rate=('SLA_Status', lambda x: (x == 'Met').sum() / len(x) * 100),
    Escalation_Rate=('Escalated', lambda x: (x == 'Yes').sum() / len(x) * 100),
    Average_CSAT=('Customer_Satisfaction_Score', 'mean'),
    Avg_Resolution_Hours=('Resolution_Hours', 'mean')
).reset_index().to_csv("../outputs/category_summary.csv", index=False)

df_cleaned.to_csv("../data/support_tickets_cleaned.csv", index=False)
`;

  const sqlCode = `-- Data Analyst SQL Query Portfolio
-- Schema setup and key analytical queries on Customer Support tickets.

-- 1. Create operations table schema
CREATE TABLE support_tickets (
    Ticket_ID VARCHAR(10) PRIMARY KEY,
    Customer_ID VARCHAR(10) NOT NULL,
    Ticket_Date DATE NOT NULL,
    Support_Channel VARCHAR(50) NOT NULL,
    Issue_Category VARCHAR(50) NOT NULL,
    Priority VARCHAR(20) NOT NULL,
    Agent_Name VARCHAR(100) NOT NULL,
    Team VARCHAR(100) NOT NULL,
    First_Response_Minutes INT,
    Resolution_Hours DECIMAL(5,2),
    SLA_Target_Hours INT NOT NULL,
    SLA_Status VARCHAR(20) NOT NULL,
    Customer_Satisfaction_Score INT
);

-- 2. Measure SLA compliance rates by agent
SELECT 
    Agent_Name,
    Team,
    COUNT(Ticket_ID) AS Total_Assigned,
    SUM(CASE WHEN SLA_Status = 'Met' THEN 1 ELSE 0 END) AS SLA_Met_Count,
    ROUND(SUM(CASE WHEN SLA_Status = 'Met' THEN 1 ELSE 0 END) * 100.0 / COUNT(Ticket_ID), 1) AS SLA_Compliance_Rate
FROM support_tickets
GROUP BY Agent_Name, Team
ORDER BY SLA_Compliance_Rate DESC;

-- 3. Calculate first-contact resolution (FCR) by agent
SELECT 
    Agent_Name,
    COUNT(Ticket_ID) AS Assigned_Tickets,
    ROUND(SUM(CASE WHEN First_Contact_Resolution = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(Ticket_ID), 1) AS FCR_Rate_Pct
FROM support_tickets
GROUP BY Agent_Name
ORDER BY FCR_Rate_Pct DESC;

-- 4. Trend of SLA Performance and Volume by Month
SELECT 
    TO_CHAR(Ticket_Date, 'YYYY-MM') AS Year_Month,
    COUNT(Ticket_ID) AS Total_Tickets,
    ROUND(SUM(CASE WHEN SLA_Status = 'Met' THEN 1 ELSE 0 END) * 100.0 / COUNT(Ticket_ID), 1) AS SLA_Compliance_Pct
FROM support_tickets
GROUP BY TO_CHAR(Ticket_Date, 'YYYY-MM')
ORDER BY Year_Month;
`;

  const handleCopy = () => {
    const code = activeTab === 'python' ? pythonCode : sqlCode;
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white rounded-xl shadow-xs border border-gray-100 overflow-hidden flex flex-col h-[600px]">
      
      {/* Tab bar header */}
      <div className="bg-slate-900 px-5 py-4 flex items-center justify-between">
        <div className="flex gap-4">
          <button
            onClick={() => setActiveTab('python')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-semibold rounded-md transition cursor-pointer ${
              activeTab === 'python' 
                ? 'bg-slate-800 text-yellow-400 border border-slate-700' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileCode size={14} />
            <span>support_quality_analysis.py</span>
          </button>
          
          <button
            onClick={() => setActiveTab('sql')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-semibold rounded-md transition cursor-pointer ${
              activeTab === 'sql' 
                ? 'bg-slate-800 text-blue-400 border border-slate-700' 
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Database size={14} />
            <span>support_quality_analysis.sql</span>
          </button>
        </div>

        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-slate-400 hover:text-white text-xs px-2.5 py-1.5 bg-slate-800/60 rounded-md border border-slate-700 transition cursor-pointer font-medium"
        >
          {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
          <span>{copied ? 'Copied!' : 'Copy Code'}</span>
        </button>
      </div>

      {/* Code window view */}
      <div className="flex-1 bg-slate-950 p-5 overflow-auto font-mono text-xs leading-relaxed text-slate-300">
        <pre className="whitespace-pre-wrap select-all">
          {activeTab === 'python' ? pythonCode : sqlCode}
        </pre>
      </div>

      {/* Code Footer info */}
      <div className="bg-slate-900 border-t border-slate-800 px-5 py-3 flex justify-between text-[11px] text-slate-400">
        <span className="flex items-center gap-1">
          <BookOpen size={12} className="text-indigo-400" />
          <span>Both script assets reside in `/python` and `/sql` repositories.</span>
        </span>
        <span>Environment Target: Python 3.10+ / PostgreSQL 14+</span>
      </div>
    </div>
  );
}
