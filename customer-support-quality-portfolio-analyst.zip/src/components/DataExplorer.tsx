import React, { useState, useMemo } from 'react';
import { Ticket } from '../types';
import { Search, Download, ChevronLeft, ChevronRight, Eye, Calendar, ArrowUpDown } from 'lucide-react';

interface DataExplorerProps {
  tickets: Ticket[];
}

export default function DataExplorer({ tickets }: DataExplorerProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('All');
  const [channelFilter, setChannelFilter] = useState('All');
  
  // Sorting State
  const [sortField, setSortField] = useState<keyof Ticket>('Ticket_ID');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 12;

  // Selected ticket for side drawer details
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);

  // Sorting handler
  const handleSort = (field: keyof Ticket) => {
    if (sortField === field) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
    setCurrentPage(1);
  };

  // Filtered and sorted tickets
  const processedTickets = useMemo(() => {
    let result = [...tickets];

    // Search filter
    if (searchTerm.trim() !== '') {
      const term = searchTerm.toLowerCase();
      result = result.filter(t => 
        t.Ticket_ID.toLowerCase().includes(term) ||
        t.Customer_Name.toLowerCase().includes(term) ||
        t.Agent_Name.toLowerCase().includes(term)
      );
    }

    // Priority filter
    if (priorityFilter !== 'All') {
      result = result.filter(t => t.Priority === priorityFilter);
    }

    // Channel filter
    if (channelFilter !== 'All') {
      result = result.filter(t => t.Support_Channel === channelFilter);
    }

    // Sort
    result.sort((a, b) => {
      let valA = a[sortField];
      let valB = b[sortField];

      // Safe check for numbers
      if (typeof valA === 'number' && typeof valB === 'number') {
        return sortDirection === 'asc' ? valA - valB : valB - valA;
      }
      
      // Default string comparison
      valA = String(valA).toLowerCase();
      valB = String(valB).toLowerCase();
      if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
      if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });

    return result;
  }, [tickets, searchTerm, priorityFilter, channelFilter, sortField, sortDirection]);

  // Paginated Tickets
  const paginatedTickets = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return processedTickets.slice(startIndex, startIndex + itemsPerPage);
  }, [processedTickets, currentPage]);

  const totalPages = Math.ceil(processedTickets.length / itemsPerPage) || 1;

  // Download active tickets as CSV
  const downloadCSV = () => {
    const headers = [
      'Ticket_ID', 'Customer_ID', 'Ticket_Date', 'Customer_Name', 'Support_Channel',
      'Issue_Category', 'Issue_Subcategory', 'Priority', 'Agent_ID', 'Agent_Name',
      'Team', 'First_Response_Minutes', 'Resolution_Hours', 'SLA_Target_Hours',
      'SLA_Status', 'Escalated', 'First_Contact_Resolution', 'Reopened',
      'Customer_Satisfaction_Score', 'Ticket_Status', 'Region'
    ];

    const csvContent = [
      headers.join(','),
      ...processedTickets.map(t => 
        headers.map(field => {
          const val = t[field as keyof Ticket];
          const escaped = String(val).replace(/"/g, '""');
          if (typeof val === 'string' && (val.includes(',') || val.includes('\n') || val.includes('"'))) {
            return `"${escaped}"`;
          }
          return val;
        }).join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `support_tickets_exported.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex flex-col lg:flex-row gap-6 bg-white rounded-xl shadow-xs border border-gray-100 p-5">
      
      {/* LEFT LIST CONTAINER */}
      <div className="flex-1 flex flex-col gap-4">
        
        {/* Search, Filter & Download header */}
        <div className="flex flex-col md:flex-row gap-3 items-center justify-between border-b border-gray-100 pb-4">
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search ID, Customer, Agent..."
              value={searchTerm}
              onChange={e => { setSearchTerm(e.target.value); setCurrentPage(1); }}
              className="pl-9 pr-4 py-2 text-xs w-full border border-gray-200 rounded-lg bg-gray-50/50 focus:outline-hidden focus:border-indigo-500 text-gray-700"
            />
          </div>

          <div className="flex w-full md:w-auto items-center gap-3 justify-end">
            {/* Priority quick filter */}
            <select
              value={priorityFilter}
              onChange={e => { setPriorityFilter(e.target.value); setCurrentPage(1); }}
              className="text-xs border border-gray-200 rounded-lg px-2.5 py-2 bg-white text-gray-600 focus:outline-hidden"
            >
              <option value="All">All Priorities</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>

            {/* Channel Filter */}
            <select
              value={channelFilter}
              onChange={e => { setChannelFilter(e.target.value); setCurrentPage(1); }}
              className="text-xs border border-gray-200 rounded-lg px-2.5 py-2 bg-white text-gray-600 focus:outline-hidden"
            >
              <option value="All">All Channels</option>
              <option value="Chat">Chat</option>
              <option value="Email">Email</option>
              <option value="Phone">Phone</option>
              <option value="Social Media">Social Media</option>
            </select>

            {/* Export CSV */}
            <button
              onClick={downloadCSV}
              className="flex items-center gap-1.5 text-xs text-white bg-indigo-600 hover:bg-indigo-700 px-3 py-2 rounded-lg font-semibold cursor-pointer transition shrink-0 shadow-xs"
            >
              <Download size={14} />
              <span>Export CSV ({processedTickets.length})</span>
            </button>
          </div>
        </div>

        {/* Data Grid Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-gray-100 text-xs font-bold text-gray-400 uppercase tracking-wider bg-gray-50/50">
                <th className="py-2.5 px-3 cursor-pointer select-none text-slate-800" onClick={() => handleSort('Ticket_ID')}>
                  <div className="flex items-center gap-1">
                    <span>Ticket ID</span>
                    <ArrowUpDown size={12} className="text-gray-400" />
                  </div>
                </th>
                <th className="py-2.5 px-3 cursor-pointer select-none text-slate-800" onClick={() => handleSort('Customer_Name')}>
                  <div className="flex items-center gap-1">
                    <span>Customer</span>
                    <ArrowUpDown size={12} className="text-gray-400" />
                  </div>
                </th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3 cursor-pointer select-none text-slate-800" onClick={() => handleSort('Priority')}>
                  <div className="flex items-center gap-1">
                    <span>Priority</span>
                    <ArrowUpDown size={12} className="text-gray-400" />
                  </div>
                </th>
                <th className="py-2.5 px-3">Agent</th>
                <th className="py-2.5 px-3 cursor-pointer select-none text-slate-800 text-center" onClick={() => handleSort('Resolution_Hours')}>
                  <div className="flex items-center gap-1 justify-center">
                    <span>Resolution</span>
                    <ArrowUpDown size={12} className="text-gray-400" />
                  </div>
                </th>
                <th className="py-2.5 px-3 text-center">SLA</th>
                <th className="py-2.5 px-3 text-center">CSAT</th>
                <th className="py-2.5 px-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              {paginatedTickets.length === 0 ? (
                <tr>
                  <td colSpan={9} className="text-center py-10 text-xs text-gray-400 italic">
                    No matching customer support records found.
                  </td>
                </tr>
              ) : (
                paginatedTickets.map(t => {
                  return (
                    <tr 
                      key={t.Ticket_ID} 
                      className={`border-b border-gray-50 text-xs hover:bg-slate-50/60 transition cursor-pointer ${
                        selectedTicket?.Ticket_ID === t.Ticket_ID ? 'bg-indigo-50/40' : ''
                      }`}
                      onClick={() => setSelectedTicket(t)}
                    >
                      <td className="py-3 px-3 font-bold text-indigo-900">{t.Ticket_ID}</td>
                      <td className="py-3 px-3 font-semibold text-slate-700 truncate max-w-40">{t.Customer_Name}</td>
                      <td className="py-3 px-3 text-gray-500">{t.Issue_Category}</td>
                      <td className="py-3 px-3">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          t.Priority === 'Critical' ? 'bg-red-50 text-red-600 border border-red-100' :
                          t.Priority === 'High' ? 'bg-orange-50 text-orange-600' :
                          t.Priority === 'Medium' ? 'bg-blue-50 text-blue-600' : 'bg-gray-50 text-gray-600'
                        }`}>
                          {t.Priority}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-gray-600 font-medium truncate max-w-40">{t.Agent_Name}</td>
                      <td className="py-3 px-3 text-center font-mono text-gray-500">{t.Resolution_Hours} hrs</td>
                      <td className="py-3 px-3 text-center">
                        <span className={`inline-block w-2.5 h-2.5 rounded-full ${
                          t.SLA_Status === 'Met' ? 'bg-emerald-500' : 'bg-red-500'
                        }`} title={t.SLA_Status} />
                      </td>
                      <td className="py-3 px-3 text-center">
                        <span className="font-bold text-amber-500">{t.Customer_Satisfaction_Score} ★</span>
                      </td>
                      <td className="py-3 px-3 text-center">
                        <button 
                          onClick={(e) => { e.stopPropagation(); setSelectedTicket(t); }}
                          className="p-1 text-gray-400 hover:text-indigo-600 transition"
                        >
                          <Eye size={14} />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination controls */}
        <div className="flex items-center justify-between border-t border-gray-100 pt-4 mt-auto">
          <span className="text-xs text-gray-500">
            Showing <strong className="text-gray-700">{(currentPage-1)*itemsPerPage + 1}</strong> to <strong className="text-gray-700">{Math.min(currentPage*itemsPerPage, processedTickets.length)}</strong> of <strong className="text-gray-700">{processedTickets.length}</strong> records
          </span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="p-1.5 border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-40 disabled:hover:bg-transparent transition cursor-pointer"
            >
              <ChevronLeft size={14} />
            </button>
            <span className="text-xs font-semibold px-2 text-slate-700">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className="p-1.5 border border-gray-200 rounded-lg hover:bg-gray-50 disabled:opacity-40 disabled:hover:bg-transparent transition cursor-pointer"
            >
              <ChevronRight size={14} />
            </button>
          </div>
        </div>

      </div>

      {/* RIGHT SIDE DETAILS DRAWER */}
      <div className="w-full lg:w-80 border border-gray-100 bg-slate-50/50 rounded-xl p-5 shrink-0 flex flex-col gap-4">
        {selectedTicket ? (
          <>
            <div className="border-b border-gray-100 pb-3 flex justify-between items-center">
              <div>
                <span className="text-[10px] text-indigo-600 font-extrabold uppercase tracking-wider block">Active Ticket Inspection</span>
                <h4 className="text-sm font-bold text-slate-800">{selectedTicket.Ticket_ID}</h4>
              </div>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                selectedTicket.SLA_Status === 'Met' ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
              }`}>
                SLA {selectedTicket.SLA_Status}
              </span>
            </div>

            <div className="flex flex-col gap-3.5 text-xs text-gray-600">
              
              <div>
                <span className="text-[10px] text-gray-400 block font-semibold uppercase">Customer Information</span>
                <span className="text-slate-800 font-bold block mt-0.5">{selectedTicket.Customer_Name}</span>
                <span className="text-[10px] text-gray-400">ID: {selectedTicket.Customer_ID} | Region: {selectedTicket.Region}</span>
              </div>

              <div>
                <span className="text-[10px] text-gray-400 block font-semibold uppercase">Issue Category</span>
                <span className="text-slate-800 font-semibold block mt-0.5">{selectedTicket.Issue_Category}</span>
                <span className="text-[10px] text-gray-400">Sub: {selectedTicket.Issue_Subcategory}</span>
              </div>

              <div className="grid grid-cols-2 gap-2 border-t border-b border-gray-100/80 py-2.5">
                <div>
                  <span className="text-[10px] text-gray-400 block">Response Time</span>
                  <span className="font-bold text-slate-700">{selectedTicket.First_Response_Minutes} mins</span>
                </div>
                <div>
                  <span className="text-[10px] text-gray-400 block">Resolution Time</span>
                  <span className="font-bold text-slate-700">{selectedTicket.Resolution_Hours} hours</span>
                </div>
              </div>

              <div>
                <span className="text-[10px] text-gray-400 block font-semibold uppercase">SLA Target Baseline</span>
                <span className="text-slate-700 font-semibold block">{selectedTicket.SLA_Target_Hours} hours (Max target)</span>
              </div>

              <div>
                <span className="text-[10px] text-gray-400 block font-semibold uppercase">Support Representative</span>
                <span className="text-slate-800 font-bold block mt-0.5">{selectedTicket.Agent_Name}</span>
                <span className="text-[10px] text-gray-400">{selectedTicket.Team} (ID: {selectedTicket.Agent_ID})</span>
              </div>

              <div className="grid grid-cols-3 gap-1 border-t border-gray-100/80 pt-2.5">
                <div className="text-center p-1 bg-white rounded border border-gray-50">
                  <span className="text-[8px] text-gray-400 uppercase block">FCR</span>
                  <span className="font-bold text-[11px] text-slate-800">{selectedTicket.First_Contact_Resolution}</span>
                </div>
                <div className="text-center p-1 bg-white rounded border border-gray-50">
                  <span className="text-[8px] text-gray-400 uppercase block">Escalated</span>
                  <span className="font-bold text-[11px] text-slate-800">{selectedTicket.Escalated}</span>
                </div>
                <div className="text-center p-1 bg-white rounded border border-gray-50">
                  <span className="text-[8px] text-gray-400 uppercase block">Reopened</span>
                  <span className="font-bold text-[11px] text-slate-800">{selectedTicket.Reopened}</span>
                </div>
              </div>

              <div className="mt-2 text-center p-3 bg-indigo-50/50 rounded-lg">
                <span className="text-[9px] text-indigo-500 font-bold block uppercase tracking-wide">Customer Satisfaction CSAT</span>
                <div className="text-xl font-extrabold text-indigo-800 mt-1">
                  {selectedTicket.Customer_Satisfaction_Score} <span className="text-xs font-semibold text-indigo-400">/ 5.0 Stars</span>
                </div>
                <span className="text-[9px] text-slate-400 italic">
                  {selectedTicket.Customer_Satisfaction_Score >= 4 ? 'Positive Review Verified' : 'Dissatisfied Customer Intervention Recommended'}
                </span>
              </div>

            </div>
          </>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center text-gray-400 p-6">
            <Eye size={28} className="text-gray-300 mb-2" />
            <h5 className="text-xs font-bold text-gray-600">No Ticket Selected</h5>
            <p className="text-[10px] leading-normal text-gray-400 mt-1">
              Select or hover a record from the grid on the left to inspect detailed operational fields.
            </p>
          </div>
        )}
      </div>

    </div>
  );
}
