import React, { useState } from 'react';
import { Award, Briefcase, MessageSquareCode, CheckCircle, BookOpen, ChevronDown, ChevronUp, Copy, Check } from 'lucide-react';

export default function CareerPrep() {
  const [activeTab, setActiveTab] = useState<'resume' | 'interview' | 'qa'>('resume');
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const resumeBullets = [
    "Customer Support Operations & Quality Analysis Project: Engineered an end-to-end data analytics system processing a dataset of 1,500+ customer support ticket logs over a 6-month cycle using Python, SQL, Excel, and Power BI.",
    "Data Wrangling & Integrity Auditing: Developed automated Python (Pandas) scripts to remove duplicate submissions, impute missing satisfaction scores using statistical medians, and enforce business rules to validate SLA statuses.",
    "Operations KPI Engineering: Designed a composite, multi-weighted Agent Performance Score combining quality (CSAT), compliance (SLA), and immediate resolution rate (FCR) to grade support representatives fairly.",
    "Interactive Business reporting Dashboards: Built visual bento-grid dashboards in Excel and Power BI utilizing Pivot Tables, advanced calculated formulas (XLOOKUP, COUNTIFS, AVERAGEIFS), and dynamic slicers."
  ];

  const qaCards = [
    {
      q: "How was data accuracy and consistency validated in this project?",
      a: "I applied multi-step validation checks. First, in Python, I checked for structural duplicates using 'duplicated()' on the Ticket_ID. Second, I inspected null entries in CSAT and imputed missing values using the median score of 4.0. Third, I audited business logic integrity by recalculating 'SLA_Status' based on 'Resolution_Hours <= SLA_Target_Hours' and overwriting misclassified records in the raw file."
    },
    {
      q: "What was the most important business finding from the customer tickets?",
      a: "The immediate impact of SLA breaches on satisfaction scores. Tickets closed within the SLA target averaged 4.25 out of 5 stars, while breached tickets plummeted to 1.86. Similarly, reopened tickets average only 1.95 CSAT. This quantitative insight shows that customer service speed and resolution completeness are the primary drivers of client retention."
    },
    {
      q: "What major challenges did you encounter during this operational analysis?",
      a: "A major challenge was grading agents fairly. When ranking simply by 'resolution speed', agents on the Order Support team looked slower than those on Account Support. However, Order Support handles shipping delays and damage claims, which inherently take longer than login resets. To resolve this, I engineered a Normalized Speed rating in my score formula that grades speed against a team-specific 24-hour baseline rather than raw speed, neutralizing category difficulty bias."
    },
    {
      q: "Which team demonstrated the lowest performance, and how would you fix it?",
      a: "The Order Support team had the lowest SLA compliance rate (under 72%) and high breach rates, primarily driven by two slow agents (Vikas Kumar and Rahul Roy) whose average resolution times exceeded 16 hours. My operational recommendations include implementing a shadowing program with top performers, establishing automated templates for recurring shipping status queries, and holding weekly tier-2 escalation audits."
    },
    {
      q: "How would you migrate this project to a live production environment?",
      a: "I would load the CSV data into a cloud relational database like PostgreSQL or Snowflake. I'd write scheduled dbt (data build tool) scripts to run the cleaning logic and recalculate KPIs nightly. Then, I would configure standard Power BI Scheduled Refresh gateways to pull from the cloud warehouse automatically, ensuring real-time daily operational reports."
    }
  ];

  const [expandedQA, setExpandedQA] = useState<number[]>([]);

  const toggleQA = (idx: number) => {
    setExpandedQA(prev => 
      prev.includes(idx) ? prev.filter(i => i !== idx) : [...prev, idx]
    );
  };

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="bg-white rounded-xl shadow-xs border border-gray-100 p-6 flex flex-col gap-6 min-h-[550px]">
      
      {/* Tab Switcher */}
      <div className="flex border-b border-gray-100 gap-6">
        <button
          onClick={() => setActiveTab('resume')}
          className={`pb-3 text-sm font-bold flex items-center gap-1.5 cursor-pointer transition ${
            activeTab === 'resume' 
              ? 'border-b-2 border-indigo-600 text-indigo-600' 
              : 'text-gray-400 hover:text-gray-600'
          }`}
        >
          <Briefcase size={16} />
          <span>ATS Resume Bullets</span>
        </button>

        <button
          onClick={() => setActiveTab('interview')}
          className={`pb-3 text-sm font-bold flex items-center gap-1.5 cursor-pointer transition ${
            activeTab === 'interview' 
              ? 'border-b-2 border-indigo-600 text-indigo-600' 
              : 'text-gray-400 hover:text-gray-600'
          }`}
        >
          <MessageSquareCode size={16} />
          <span>60-Second Pitch</span>
        </button>

        <button
          onClick={() => setActiveTab('qa')}
          className={`pb-3 text-sm font-bold flex items-center gap-1.5 cursor-pointer transition ${
            activeTab === 'qa' 
              ? 'border-b-2 border-indigo-600 text-indigo-600' 
              : 'text-gray-400 hover:text-gray-600'
          }`}
        >
          <BookOpen size={16} />
          <span>Interview QA Flashcards</span>
        </button>
      </div>

      {/* TAB 1: RESUME BULLET POINTS */}
      {activeTab === 'resume' && (
        <div className="flex flex-col gap-4">
          <div className="bg-indigo-50/40 p-4 rounded-lg flex items-start gap-2.5">
            <Award className="text-indigo-600 shrink-0 mt-0.5" size={16} />
            <span className="text-xs text-indigo-950 leading-relaxed font-medium">
              These descriptions are **ATS-compliant** and optimized for Data Analyst, Quality Analyst, operations, and support reporting roles. Click the copy button next to each bullet point to copy it directly into your CV.
            </span>
          </div>

          <div className="flex flex-col gap-3.5">
            {resumeBullets.map((bullet, idx) => (
              <div 
                key={idx} 
                className="group border border-gray-100 hover:border-indigo-100 p-4 rounded-xl flex items-start justify-between gap-4 transition hover:bg-slate-50/30"
              >
                <div className="flex gap-3">
                  <CheckCircle size={14} className="text-emerald-500 shrink-0 mt-1" />
                  <p className="text-xs text-gray-700 leading-relaxed font-medium">{bullet}</p>
                </div>
                <button
                  onClick={() => handleCopy(bullet, idx)}
                  className="p-1.5 border border-gray-100 group-hover:border-indigo-100 rounded-md hover:bg-white text-gray-400 hover:text-indigo-600 transition cursor-pointer"
                >
                  {copiedIndex === idx ? <Check size={14} className="text-emerald-500" /> : <Copy size={14} />}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: ELEVATOR PITCH */}
      {activeTab === 'interview' && (
        <div className="flex flex-col gap-4 max-w-3xl mx-auto text-center py-6">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-indigo-50 rounded-full text-indigo-600 mx-auto mb-2">
            <MessageSquareCode size={24} />
          </div>
          
          <h4 className="text-base font-extrabold text-slate-800">
            Tell Me About Yourself / Describe a recent data project you did?
          </h4>
          
          <p className="text-xs text-gray-500 leading-normal max-w-xl mx-auto">
            Read or practice this exact 60-second pitch in your next interview. It is designed to demonstrate full ownership of data manipulation, SQL structures, visual analytics, and strategic operational reasoning.
          </p>

          <div className="mt-4 p-5 bg-slate-950 rounded-xl text-slate-300 font-sans text-xs text-left leading-relaxed max-w-2xl mx-auto relative border border-slate-800 shadow-lg italic">
            <div className="absolute top-2 right-2 text-[10px] text-indigo-400 font-bold uppercase tracking-wider bg-slate-900 px-2 py-0.5 rounded border border-slate-800">60-sec script</div>
            "I recently engineered an end-to-end Operations and Quality Analytics project evaluated over a six-month customer support cycle. I synthesized a realistic dataset of over 1,500 ticket logs across five functional teams and multiple communication channels. 
            <br /><br />
            Using Python, I automated the data cleaning pipeline—removing duplicate logs, imputing missing CSAT scores, and strictly auditing SLA compliance metrics. Then, I developed structured SQL queries to analyze monthly trends, channel speeds, and team quality rankings. 
            <br /><br />
            A major highlight was designing a composite **Agent Performance Score** that balances SLA compliance and CSAT alongside resolution speed, protecting agents against category difficulty bias. Finally, I built complete interactive Power BI and Excel dashboards with dynamic slicers to help leaders visualize bottlenecks instantly. This project demonstrates my ability to transform raw, messy system logs into rich, actionable operational insights."
          </div>
        </div>
      )}

      {/* TAB 3: QA FLASHCARDS */}
      {activeTab === 'qa' && (
        <div className="flex flex-col gap-4">
          <span className="text-xs text-gray-400 block font-bold uppercase tracking-wider mb-2">Frequently Asked Technical & Business Questions</span>
          <div className="flex flex-col gap-3">
            {qaCards.map((item, idx) => {
              const isExpanded = expandedQA.includes(idx);
              return (
                <div 
                  key={idx} 
                  className="border border-gray-100 rounded-xl overflow-hidden transition hover:border-indigo-100"
                >
                  <button
                    onClick={() => toggleQA(idx)}
                    className="w-full text-left px-5 py-4 bg-slate-50/50 hover:bg-slate-50 flex items-center justify-between gap-4 transition cursor-pointer"
                  >
                    <span className="text-xs font-bold text-slate-800">{item.q}</span>
                    {isExpanded ? <ChevronUp size={16} className="text-gray-400" /> : <ChevronDown size={16} className="text-gray-400" />}
                  </button>
                  {isExpanded && (
                    <div className="px-5 py-4 border-t border-gray-50 bg-white text-xs leading-relaxed text-gray-600 font-medium font-sans">
                      {item.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

    </div>
  );
}
