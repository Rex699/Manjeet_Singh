import React, { useState, useMemo } from 'react';
import { Ticket, ScoreWeights } from '../types';
import { Award, Info, Sliders, RefreshCw, Trophy, ShieldAlert, ArrowUpRight } from 'lucide-react';

interface AgentLeaderboardProps {
  tickets: Ticket[];
}

interface AgentStats {
  id: string;
  name: string;
  team: string;
  totalTickets: number;
  slaMet: number;
  fcrYes: number;
  csatSum: number;
  csatCount: number;
  resolutionHoursSum: number;
  escalatedYes: number;
}

export default function AgentLeaderboard({ tickets }: AgentLeaderboardProps) {
  // Default score weights
  const [weights, setWeights] = useState<ScoreWeights>({
    sla: 30,
    csat: 30,
    fcr: 20,
    speed: 10,
    escalation: 10
  });

  const weightSum = weights.sla + weights.csat + weights.fcr + weights.speed + weights.escalation;

  const handleSliderChange = (key: keyof ScoreWeights, value: number) => {
    setWeights(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleResetWeights = () => {
    setWeights({
      sla: 30,
      csat: 30,
      fcr: 20,
      speed: 10,
      escalation: 10
    });
  };

  // 1. Group tickets by Agent
  const agentStats = useMemo(() => {
    const map: Record<string, AgentStats> = {};
    
    tickets.forEach(t => {
      const id = t.Agent_ID;
      if (!map[id]) {
        map[id] = {
          id,
          name: t.Agent_Name,
          team: t.Team,
          totalTickets: 0,
          slaMet: 0,
          fcrYes: 0,
          csatSum: 0,
          csatCount: 0,
          resolutionHoursSum: 0,
          escalatedYes: 0
        };
      }
      
      const stat = map[id];
      stat.totalTickets++;
      if (t.SLA_Status === 'Met') stat.slaMet++;
      if (t.First_Contact_Resolution === 'Yes') stat.fcrYes++;
      if (t.Customer_Satisfaction_Score) {
        stat.csatSum += t.Customer_Satisfaction_Score;
        stat.csatCount++;
      }
      stat.resolutionHoursSum += t.Resolution_Hours;
      if (t.Escalated === 'Yes') stat.escalatedYes++;
    });

    return Object.values(map);
  }, [tickets]);

  // 2. Compute live performance scores based on slider weights
  const scoredAgents = useMemo(() => {
    // Normalize weights to sum to 1.0 during calculations
    const sum = weightSum || 1;
    const normSlaW = weights.sla / sum;
    const normCsatW = weights.csat / sum;
    const normFcrW = weights.fcr / sum;
    const normSpeedW = weights.speed / sum;
    const normEscW = weights.escalation / sum;

    return agentStats.map(a => {
      const slaRate = (a.slaMet / a.totalTickets) * 100;
      const fcrRate = (a.fcrYes / a.totalTickets) * 100;
      const avgCsat = a.csatCount > 0 ? a.csatSum / a.csatCount : 4.0;
      const avgResolution = a.resolutionHoursSum / a.totalTickets;
      const escalationRate = (a.escalatedYes / a.totalTickets) * 100;

      // Normalization calculations for individual metric factors (scaled 0.0 to 1.0):
      const nSLA = slaRate / 100;
      const nCSAT = (avgCsat - 1) / 4; // Map 1-5 CSAT to 0.0-1.0 scale
      const nFCR = fcrRate / 100;
      // Normalizing speed: 1.0 if instant resolution, sliding scale down to 0.0 if >= 24 hours
      const nSpeed = Math.max(0, 1 - (avgResolution / 24));
      // Normalizing escalations: 1.0 if 0% escalation, 0.0 if 100% escalation
      const nEsc = 1 - (escalationRate / 100);

      // Compute composite percentage score
      const compositeScore = (
        (nSLA * normSlaW) + 
        (nCSAT * normCsatW) + 
        (nFCR * normFcrW) + 
        (nSpeed * normSpeedW) + 
        (nEsc * normEscW)
      ) * 100;

      return {
        id: a.id,
        name: a.name,
        team: a.team,
        totalTickets: a.totalTickets,
        slaRate,
        fcrRate,
        avgCsat,
        avgResolution,
        escalationRate,
        performanceScore: parseFloat(compositeScore.toFixed(1))
      };
    }).sort((x, y) => y.performanceScore - x.performanceScore);
  }, [agentStats, weights, weightSum]);

  // Identify SLA Breachers
  const highSlaBreachers = useMemo(() => {
    return scoredAgents
      .filter(a => a.slaRate < 75)
      .sort((a, b) => a.slaRate - b.slaRate);
  }, [scoredAgents]);

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 w-full">
      
      {/* WEIGHT SLIDER CONTROLS PLAYGROUND */}
      <div className="w-full bg-white rounded-xl shadow-xs border border-gray-100 p-5 flex flex-col gap-4">
        <div className="flex items-center gap-2 border-b border-gray-100 pb-3">
          <Sliders className="text-indigo-600" size={18} />
          <h3 className="text-sm font-bold text-indigo-950">Dynamic Score Weights</h3>
        </div>

        <p className="text-[11px] leading-relaxed text-gray-500">
          Tune the weights below to see the support operations leaderboard re-rank instantly! Ensure sliders sum to **100%** for true reporting balance.
        </p>

        {/* Weights indicator sum */}
        <div className={`p-2.5 rounded-lg text-center font-bold text-xs flex justify-between items-center ${
          weightSum === 100 ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
        }`}>
          <span>Weights Cumulative Sum:</span>
          <span>{weightSum}% {weightSum === 100 ? '✓ Balanced' : '⚠️ Unbalanced'}</span>
        </div>

        {/* Sliders list */}
        <div className="flex flex-col gap-3 mt-2">
          
          {/* SLA Weight */}
          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-xs font-semibold text-gray-700">
              <span>SLA Compliance Weight</span>
              <span className="text-indigo-600">{weights.sla}%</span>
            </div>
            <input 
              type="range" min="0" max="50" step="5"
              value={weights.sla}
              onChange={e => handleSliderChange('sla', Number(e.target.value))}
              className="accent-indigo-600 cursor-pointer h-1 bg-slate-100 rounded-lg appearance-none"
            />
          </div>

          {/* CSAT Weight */}
          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-xs font-semibold text-gray-700">
              <span>Customer Satisfaction (CSAT)</span>
              <span className="text-indigo-600">{weights.csat}%</span>
            </div>
            <input 
              type="range" min="0" max="50" step="5"
              value={weights.csat}
              onChange={e => handleSliderChange('csat', Number(e.target.value))}
              className="accent-indigo-600 cursor-pointer h-1 bg-slate-100 rounded-lg appearance-none"
            />
          </div>

          {/* FCR Weight */}
          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-xs font-semibold text-gray-700">
              <span>First-Contact Resolution (FCR)</span>
              <span className="text-indigo-600">{weights.fcr}%</span>
            </div>
            <input 
              type="range" min="0" max="40" step="5"
              value={weights.fcr}
              onChange={e => handleSliderChange('fcr', Number(e.target.value))}
              className="accent-indigo-600 cursor-pointer h-1 bg-slate-100 rounded-lg appearance-none"
            />
          </div>

          {/* Speed Weight */}
          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-xs font-semibold text-gray-700">
              <span>Resolution Speed</span>
              <span className="text-indigo-600">{weights.speed}%</span>
            </div>
            <input 
              type="range" min="0" max="30" step="5"
              value={weights.speed}
              onChange={e => handleSliderChange('speed', Number(e.target.value))}
              className="accent-indigo-600 cursor-pointer h-1 bg-slate-100 rounded-lg appearance-none"
            />
          </div>

          {/* Escalation Control */}
          <div className="flex flex-col gap-1">
            <div className="flex justify-between text-xs font-semibold text-gray-700">
              <span>Escalation Control</span>
              <span className="text-indigo-600">{weights.escalation}%</span>
            </div>
            <input 
              type="range" min="0" max="30" step="5"
              value={weights.escalation}
              onChange={e => handleSliderChange('escalation', Number(e.target.value))}
              className="accent-indigo-600 cursor-pointer h-1 bg-slate-100 rounded-lg appearance-none"
            />
          </div>

        </div>

        <button
          onClick={handleResetWeights}
          className="mt-4 flex items-center justify-center gap-1.5 py-2 text-xs border border-gray-200 hover:border-indigo-500 hover:text-indigo-600 text-gray-500 font-bold rounded-lg cursor-pointer transition bg-slate-50 hover:bg-indigo-50/20"
        >
          <RefreshCw size={12} />
          <span>Reset Default (30/30/20/10/10)</span>
        </button>

        {/* SLA Breach Warning */}
        <div className="mt-auto border-t border-gray-100 pt-4 flex flex-col gap-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-red-600">
            <ShieldAlert size={14} />
            <span>SLA Breach Alerts</span>
          </div>
          <p className="text-[10px] text-gray-400">
            Agents with &lt; 75% SLA compliance requiring immediate workflow shadowing:
          </p>
          <div className="flex flex-col gap-1.5 mt-1">
            {highSlaBreachers.map(b => (
              <div key={b.id} className="flex justify-between items-center text-[11px] p-2 bg-red-50/50 rounded-md border border-red-100/50">
                <span className="font-bold text-red-950">{b.name}</span>
                <span className="text-red-600 font-extrabold">{b.slaRate.toFixed(1)}% Compliance</span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* DYNAMIC LEADERBOARD SCORECARD TABLE */}
      <div className="xl:col-span-2 bg-white rounded-xl shadow-xs border border-gray-100 p-5 flex flex-col gap-4">
        
        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
          <div className="flex items-center gap-2">
            <Trophy className="text-amber-500" size={18} />
            <h3 className="text-sm font-bold text-indigo-950">Agent Operations Leaderboard</h3>
          </div>
          <span className="text-[10px] text-gray-400 font-semibold uppercase">Re-ranked dynamically</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-gray-100 text-xs font-bold text-gray-400 uppercase tracking-wider bg-gray-50/50">
                <th className="py-2.5 px-3 text-center">Rank</th>
                <th className="py-2.5 px-3">Agent Details</th>
                <th className="py-2.5 px-3 text-center">Tickets</th>
                <th className="py-2.5 px-3 text-center">SLA</th>
                <th className="py-2.5 px-3 text-center">CSAT</th>
                <th className="py-2.5 px-3 text-center">FCR</th>
                <th className="py-2.5 px-3 text-center">Speed</th>
                <th className="py-2.5 px-3 text-center bg-indigo-50/30 text-indigo-700 font-extrabold">Live Score</th>
              </tr>
            </thead>
            <tbody>
              {scoredAgents.map((a, i) => {
                let badgeClass = 'text-gray-500 bg-gray-100';
                if (i === 0) badgeClass = 'text-amber-700 bg-amber-50 font-extrabold border border-amber-200';
                else if (i === 1) badgeClass = 'text-slate-700 bg-slate-50 font-bold border border-slate-200';
                else if (i === 2) badgeClass = 'text-orange-700 bg-orange-50 font-bold border border-orange-100';

                return (
                  <tr key={a.id} className="border-b border-gray-50 text-xs hover:bg-slate-50/60 transition">
                    <td className="py-3 px-3 text-center">
                      <span className={`inline-flex items-center justify-center w-5 h-5 rounded-full text-[10px] ${badgeClass}`}>
                        {i + 1}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-bold text-indigo-950">{a.name}</div>
                      <div className="text-[10px] text-gray-400">{a.team}</div>
                    </td>
                    <td className="py-3 px-3 text-center text-gray-600 font-semibold">{a.totalTickets}</td>
                    <td className="py-3 px-3 text-center font-mono">
                      <span className={a.slaRate < 75 ? 'text-red-500 font-semibold' : 'text-slate-600'}>
                        {a.slaRate.toFixed(0)}%
                      </span>
                    </td>
                    <td className="py-3 px-3 text-center font-bold text-amber-500">{a.avgCsat.toFixed(2)} ★</td>
                    <td className="py-3 px-3 text-center text-gray-500 font-mono">{a.fcrRate.toFixed(0)}%</td>
                    <td className="py-3 px-3 text-center text-gray-500 font-mono">{a.avgResolution.toFixed(1)}h</td>
                    <td className="py-3 px-3 text-center bg-indigo-50/20 text-indigo-700 font-extrabold text-sm">
                      {a.performanceScore.toFixed(1)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Score methodology card overlay */}
        <div className="mt-auto border-t border-gray-100 pt-4 p-3 bg-indigo-50/20 rounded-lg flex items-start gap-2.5">
          <Info size={16} className="text-indigo-600 shrink-0 mt-0.5" />
          <div className="text-[10px] text-indigo-950 leading-relaxed">
            <strong className="block font-bold mb-0.5">Composite Score Normalization Logic:</strong>
            SLA and FCR rates are scaled directly 0-100%. CSAT is normalized to scale 0-1.0 via <code className="bg-indigo-50 px-1 py-0.5 rounded text-indigo-700 font-mono font-semibold">(CSAT - 1) / 4</code>. Speed is normalized against a 24-hour target baseline via <code className="bg-indigo-50 px-1 py-0.5 rounded text-indigo-700 font-mono font-semibold">1 - (Hours / 24)</code>. Escalation control is inverted <code className="bg-indigo-50 px-1 py-0.5 rounded text-indigo-700 font-mono font-semibold">1 - Escalation_Rate</code> to reward full end-to-end resolution. This safeguards and rewards high-quality work.
          </div>
        </div>

      </div>

    </div>
  );
}
