import React, { useState, useMemo } from 'react';
import { Ticket, FilterState } from '../types';
import { 
  Users, Clock, Zap, CheckCircle2, AlertTriangle, RefreshCw, BarChart3, TrendingUp, Filter, Calendar, MapPin, Layers, Phone
} from 'lucide-react';

interface DashboardProps {
  tickets: Ticket[];
}

export default function Dashboard({ tickets }: DashboardProps) {
  // Available filter options (unique sorted values)
  const filterOptions = useMemo(() => {
    const opts = {
      regions: new Set<string>(),
      channels: new Set<string>(),
      categories: new Set<string>(),
      priorities: new Set<string>(),
      teams: new Set<string>()
    };
    tickets.forEach(t => {
      opts.regions.add(t.Region);
      opts.channels.add(t.Support_Channel);
      opts.categories.add(t.Issue_Category);
      opts.priorities.add(t.Priority);
      opts.teams.add(t.Team);
    });
    return {
      regions: Array.from(opts.regions).sort(),
      channels: Array.from(opts.channels).sort(),
      categories: Array.from(opts.categories).sort(),
      priorities: Array.from(opts.priorities), // keep logical or alpha
      teams: Array.from(opts.teams).sort()
    };
  }, [tickets]);

  // Slicer Filter State
  const [filters, setFilters] = useState<FilterState>({
    regions: [],
    channels: [],
    categories: [],
    priorities: [],
    teams: [],
    agents: [],
    startDate: '2026-01-01',
    endDate: '2026-06-30'
  });

  const handleMultiSelect = (key: keyof FilterState, value: string) => {
    setFilters(prev => {
      const current = prev[key] as string[];
      const next = current.includes(value)
        ? current.filter(x => x !== value)
        : [...current, value];
      return { ...prev, [key]: next };
    });
  };

  const resetFilters = () => {
    setFilters({
      regions: [],
      channels: [],
      categories: [],
      priorities: [],
      teams: [],
      agents: [],
      startDate: '2026-01-01',
      endDate: '2026-06-30'
    });
  };

  // Filtered Tickets
  const filteredTickets = useMemo(() => {
    return tickets.filter(t => {
      if (filters.regions.length > 0 && !filters.regions.includes(t.Region)) return false;
      if (filters.channels.length > 0 && !filters.channels.includes(t.Support_Channel)) return false;
      if (filters.categories.length > 0 && !filters.categories.includes(t.Issue_Category)) return false;
      if (filters.priorities.length > 0 && !filters.priorities.includes(t.Priority)) return false;
      if (filters.teams.length > 0 && !filters.teams.includes(t.Team)) return false;
      
      const tDate = new Date(t.Ticket_Date);
      const sDate = new Date(filters.startDate);
      const eDate = new Date(filters.endDate);
      if (tDate < sDate || tDate > eDate) return false;

      return true;
    });
  }, [tickets, filters]);

  // KPI Calculations
  const kpis = useMemo(() => {
    const total = filteredTickets.length;
    if (total === 0) {
      return {
        total: 0,
        avgResponse: 0,
        avgResolution: 0,
        slaRate: 0,
        fcrRate: 0,
        escalationRate: 0,
        avgCsat: 0
      };
    }

    let responseSum = 0;
    let resolutionSum = 0;
    let slaMet = 0;
    let fcrCount = 0;
    let escalatedCount = 0;
    let csatSum = 0;

    filteredTickets.forEach(t => {
      responseSum += t.First_Response_Minutes;
      resolutionSum += t.Resolution_Hours;
      if (t.SLA_Status === 'Met') slaMet++;
      if (t.First_Contact_Resolution === 'Yes') fcrCount++;
      if (t.Escalated === 'Yes') escalatedCount++;
      csatSum += t.Customer_Satisfaction_Score;
    });

    return {
      total,
      avgResponse: responseSum / total,
      avgResolution: resolutionSum / total,
      slaRate: (slaMet / total) * 100,
      fcrRate: (fcrCount / total) * 100,
      escalationRate: (escalatedCount / total) * 100,
      avgCsat: csatSum / total
    };
  }, [filteredTickets]);

  // Visualization Chart Data Aggregations

  // 1. Monthly Volumes (Line Chart)
  const monthlyData = useMemo(() => {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"];
    const counts = [0, 0, 0, 0, 0, 0];
    const slaMetCount = [0, 0, 0, 0, 0, 0];

    filteredTickets.forEach(t => {
      const monthIdx = new Date(t.Ticket_Date).getUTCMonth();
      if (monthIdx >= 0 && monthIdx < 6) {
        counts[monthIdx]++;
        if (t.SLA_Status === 'Met') {
          slaMetCount[monthIdx]++;
        }
      }
    });

    return months.map((m, i) => ({
      name: m,
      count: counts[i],
      slaRate: counts[i] > 0 ? (slaMetCount[i] / counts[i]) * 100 : 0
    }));
  }, [filteredTickets]);

  // 2. Issue Category Volume (Horizontal Bar Chart)
  const categoryData = useMemo(() => {
    const counts: Record<string, number> = {};
    filteredTickets.forEach(t => {
      counts[t.Issue_Category] = (counts[t.Issue_Category] || 0) + 1;
    });
    return Object.entries(counts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);
  }, [filteredTickets]);

  // 3. Priority Columns (Speed & Counts)
  const priorityData = useMemo(() => {
    const priorityOrder = ['Critical', 'High', 'Medium', 'Low'];
    const summary = priorityOrder.map(p => ({
      name: p,
      count: 0,
      totalHours: 0
    }));

    filteredTickets.forEach(t => {
      const idx = priorityOrder.indexOf(t.Priority);
      if (idx !== -1) {
        summary[idx].count++;
        summary[idx].totalHours += t.Resolution_Hours;
      }
    });

    return summary.map(item => ({
      name: item.name,
      count: item.count,
      avgHours: item.count > 0 ? parseFloat((item.totalHours / item.count).toFixed(1)) : 0
    }));
  }, [filteredTickets]);

  // 4. CSAT by Team
  const teamData = useMemo(() => {
    const data: Record<string, { count: number; totalCsat: number }> = {};
    filteredTickets.forEach(t => {
      if (!data[t.Team]) {
        data[t.Team] = { count: 0, totalCsat: 0 };
      }
      data[t.Team].count++;
      data[t.Team].totalCsat += t.Customer_Satisfaction_Score;
    });

    return Object.entries(data).map(([name, stat]) => ({
      name,
      avgCsat: parseFloat((stat.totalCsat / stat.count).toFixed(2))
    })).sort((a, b) => b.avgCsat - a.avgCsat);
  }, [filteredTickets]);

  return (
    <div className="flex flex-col xl:flex-row gap-6 w-full">
      
      {/* SIDEBAR FILTER PANEL (SLICERS) */}
      <div className="w-full xl:w-72 bg-white rounded-xl shadow-xs border border-gray-100 p-5 shrink-0 flex flex-col gap-5">
        <div className="flex items-center justify-between border-b border-gray-100 pb-3">
          <div className="flex items-center gap-2 text-indigo-900 font-semibold">
            <Filter size={18} className="text-indigo-600" />
            <span>Interactive Slicers</span>
          </div>
          <button 
            onClick={resetFilters}
            className="text-xs text-gray-500 hover:text-indigo-600 font-medium transition cursor-pointer"
          >
            Clear Filters
          </button>
        </div>

        {/* Date Filter */}
        <div className="flex flex-col gap-2">
          <label className="text-xs font-semibold text-gray-700 flex items-center gap-1.5">
            <Calendar size={14} className="text-gray-400" />
            <span>Ticket Date Range</span>
          </label>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <span className="text-[10px] text-gray-400 block">From</span>
              <input 
                type="date" 
                value={filters.startDate}
                min="2026-01-01"
                max="2026-06-30"
                onChange={e => setFilters(prev => ({ ...prev, startDate: e.target.value }))}
                className="w-full text-xs border border-gray-200 rounded-md p-1 bg-gray-50 focus:outline-hidden focus:border-indigo-500 text-gray-700"
              />
            </div>
            <div>
              <span className="text-[10px] text-gray-400 block">To</span>
              <input 
                type="date" 
                value={filters.endDate}
                min="2026-01-01"
                max="2026-06-30"
                onChange={e => setFilters(prev => ({ ...prev, endDate: e.target.value }))}
                className="w-full text-xs border border-gray-200 rounded-md p-1 bg-gray-50 focus:outline-hidden focus:border-indigo-500 text-gray-700"
              />
            </div>
          </div>
        </div>

        {/* Region Filter */}
        <div className="flex flex-col gap-1.5">
          <span className="text-xs font-semibold text-gray-700 flex items-center gap-1.5">
            <MapPin size={14} className="text-gray-400" />
            <span>Geographic Region</span>
          </span>
          <div className="flex flex-wrap gap-1">
            {filterOptions.regions.map(r => {
              const isSelected = filters.regions.includes(r);
              return (
                <button
                  key={r}
                  onClick={() => handleMultiSelect('regions', r)}
                  className={`px-2.5 py-1 text-[11px] font-medium rounded-full cursor-pointer border transition ${
                    isSelected 
                      ? 'bg-indigo-50 border-indigo-200 text-indigo-700 font-semibold' 
                      : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  {r}
                </button>
              );
            })}
          </div>
        </div>

        {/* Priority Filter */}
        <div className="flex flex-col gap-1.5">
          <span className="text-xs font-semibold text-gray-700 flex items-center gap-1.5">
            <Layers size={14} className="text-gray-400" />
            <span>Ticket Priority</span>
          </span>
          <div className="grid grid-cols-2 gap-1.5">
            {filterOptions.priorities.map(p => {
              const isSelected = filters.priorities.includes(p);
              return (
                <button
                  key={p}
                  onClick={() => handleMultiSelect('priorities', p)}
                  className={`px-2 py-1.5 text-left text-[11px] font-medium rounded-md border cursor-pointer transition ${
                    isSelected 
                      ? 'bg-indigo-600 border-indigo-600 text-white font-semibold' 
                      : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <span className={`inline-block w-2 h-2 rounded-full mr-1.5 ${
                    p === 'Critical' ? 'bg-red-500' :
                    p === 'High' ? 'bg-orange-400' :
                    p === 'Medium' ? 'bg-blue-400' : 'bg-gray-400'
                  }`} />
                  {p}
                </button>
              );
            })}
          </div>
        </div>

        {/* Support Channel Filter */}
        <div className="flex flex-col gap-1.5">
          <span className="text-xs font-semibold text-gray-700 flex items-center gap-1.5">
            <Phone size={14} className="text-gray-400" />
            <span>Support Channel</span>
          </span>
          <div className="grid grid-cols-2 gap-1.5">
            {filterOptions.channels.map(c => {
              const isSelected = filters.channels.includes(c);
              return (
                <button
                  key={c}
                  onClick={() => handleMultiSelect('channels', c)}
                  className={`px-2 py-1.5 text-center text-[11px] font-medium rounded-md border cursor-pointer transition ${
                    isSelected 
                      ? 'bg-indigo-50 border-indigo-200 text-indigo-700 font-semibold' 
                      : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  {c}
                </button>
              );
            })}
          </div>
        </div>

        {/* Issue Category Filter */}
        <div className="flex flex-col gap-1.5">
          <span className="text-xs font-semibold text-gray-700 flex items-center gap-1.5">
            <BarChart3 size={14} className="text-gray-400" />
            <span>Issue Category</span>
          </span>
          <div className="max-h-36 overflow-y-auto pr-1 border border-gray-100 rounded-md p-1 bg-gray-50 flex flex-col gap-1">
            {filterOptions.categories.map(cat => {
              const isSelected = filters.categories.includes(cat);
              return (
                <label 
                  key={cat} 
                  className="flex items-center gap-2 px-1.5 py-1 text-xs hover:bg-white rounded-sm cursor-pointer select-none text-gray-600"
                >
                  <input 
                    type="checkbox" 
                    checked={isSelected}
                    onChange={() => handleMultiSelect('categories', cat)}
                    className="accent-indigo-600 rounded-sm"
                  />
                  <span className={isSelected ? 'text-indigo-600 font-medium' : ''}>{cat}</span>
                </label>
              );
            })}
          </div>
        </div>

        {/* Support Team Filter */}
        <div className="flex flex-col gap-1.5">
          <span className="text-xs font-semibold text-gray-700 flex items-center gap-1.5">
            <Users size={14} className="text-gray-400" />
            <span>Assigned Team</span>
          </span>
          <div className="max-h-36 overflow-y-auto pr-1 border border-gray-100 rounded-md p-1 bg-gray-50 flex flex-col gap-1">
            {filterOptions.teams.map(t => {
              const isSelected = filters.teams.includes(t);
              return (
                <label 
                  key={t} 
                  className="flex items-center gap-2 px-1.5 py-1 text-xs hover:bg-white rounded-sm cursor-pointer select-none text-gray-600"
                >
                  <input 
                    type="checkbox" 
                    checked={isSelected}
                    onChange={() => handleMultiSelect('teams', t)}
                    className="accent-indigo-600 rounded-sm"
                  />
                  <span className={isSelected ? 'text-indigo-600 font-medium' : ''}>{t}</span>
                </label>
              );
            })}
          </div>
        </div>

        <div className="mt-auto pt-3 border-t border-gray-100 text-[10px] text-gray-400 text-center leading-relaxed">
          Active Filter Yields:<br />
          <strong className="text-indigo-600 text-xs font-semibold">{filteredTickets.length}</strong> out of {tickets.length} total records
        </div>
      </div>

      {/* DASHBOARD GRAPHICS (BENTO GRID) */}
      <div className="flex-1 flex flex-col gap-6">
        
        {/* TOP ROW KPI CARDS */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
          
          {/* Card 1 */}
          <div className="bg-white rounded-xl shadow-xs border border-gray-100 p-4 flex flex-col">
            <div className="text-gray-400 text-[11px] font-semibold uppercase tracking-wider mb-1">Total Tickets</div>
            <div className="text-2xl font-bold text-slate-800 font-sans tracking-tight">{kpis.total.toLocaleString()}</div>
            <div className="mt-auto text-[10px] text-slate-400 flex items-center gap-1 pt-1 border-t border-gray-50">
              <TrendingUp size={10} className="text-indigo-500" />
              <span>Closed interactions</span>
            </div>
          </div>

          {/* Card 2 */}
          <div className="bg-white rounded-xl shadow-xs border border-gray-100 p-4 flex flex-col">
            <div className="text-gray-400 text-[11px] font-semibold uppercase tracking-wider mb-1">Avg Response</div>
            <div className="text-2xl font-bold text-slate-800 tracking-tight">
              {kpis.avgResponse.toFixed(1)}<span className="text-xs font-normal text-gray-400 ml-0.5">m</span>
            </div>
            <div className="mt-auto text-[10px] text-slate-400 pt-1 border-t border-gray-50">
              Target: &lt; 15 mins
            </div>
          </div>

          {/* Card 3 */}
          <div className="bg-white rounded-xl shadow-xs border border-gray-100 p-4 flex flex-col">
            <div className="text-gray-400 text-[11px] font-semibold uppercase tracking-wider mb-1">Avg Resolution</div>
            <div className="text-2xl font-bold text-slate-800 tracking-tight">
              {kpis.avgResolution.toFixed(1)}<span className="text-xs font-normal text-gray-400 ml-0.5">h</span>
            </div>
            <div className="mt-auto text-[10px] text-slate-400 pt-1 border-t border-gray-50">
              Target: &lt; 12 hours
            </div>
          </div>

          {/* Card 4 */}
          <div className="bg-white rounded-xl shadow-xs border border-gray-100 p-4 flex flex-col">
            <div className="text-gray-400 text-[11px] font-semibold uppercase tracking-wider mb-1">SLA Compliance</div>
            <div className={`text-2xl font-bold tracking-tight ${kpis.slaRate >= 80 ? 'text-emerald-600' : 'text-rose-500'}`}>
              {kpis.slaRate.toFixed(1)}%
            </div>
            <div className="mt-auto text-[10px] text-slate-400 pt-1 border-t border-gray-50">
              Org Target: &gt; 80%
            </div>
          </div>

          {/* Card 5 */}
          <div className="bg-white rounded-xl shadow-xs border border-gray-100 p-4 flex flex-col">
            <div className="text-gray-400 text-[11px] font-semibold uppercase tracking-wider mb-1">FCR Rate</div>
            <div className="text-2xl font-bold text-slate-800 tracking-tight">
              {kpis.fcrRate.toFixed(1)}%
            </div>
            <div className="mt-auto text-[10px] text-slate-400 pt-1 border-t border-gray-50">
              Resolved first contact
            </div>
          </div>

          {/* Card 6 */}
          <div className="bg-white rounded-xl shadow-xs border border-gray-100 p-4 flex flex-col">
            <div className="text-gray-400 text-[11px] font-semibold uppercase tracking-wider mb-1">Escalation Rate</div>
            <div className={`text-2xl font-bold tracking-tight ${kpis.escalationRate < 15 ? 'text-slate-800' : 'text-rose-500'}`}>
              {kpis.escalationRate.toFixed(1)}%
            </div>
            <div className="mt-auto text-[10px] text-slate-400 pt-1 border-t border-gray-50">
              Escalated to L2
            </div>
          </div>

          {/* Card 7 */}
          <div className="bg-white rounded-xl shadow-xs border border-gray-100 p-4 flex flex-col">
            <div className="text-gray-400 text-[11px] font-semibold uppercase tracking-wider mb-1">Average CSAT</div>
            <div className="text-2xl font-bold text-indigo-700 tracking-tight">
              {kpis.avgCsat.toFixed(2)}<span className="text-xs font-semibold text-indigo-400 ml-0.5">★</span>
            </div>
            <div className="mt-auto text-[10px] text-slate-400 pt-1 border-t border-gray-50">
              Satisfaction score (1-5)
            </div>
          </div>

        </div>

        {/* MAIN VISUALIZATIONS BENTO BOARD */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* Plot 1: Monthly Ticket Volume & SLA Rate (Area & Line Hybrid) */}
          <div className="bg-white rounded-xl shadow-xs border border-gray-100 p-5 lg:col-span-2">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-bold text-indigo-950">Monthly Ticket Volume & SLA Compliance Rate</span>
              <span className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">H1 2026 Trend</span>
            </div>
            <div className="h-64 relative flex items-end">
              <svg className="w-full h-full" viewBox="0 0 500 220" preserveAspectRatio="none">
                {/* Grid Lines */}
                <line x1="40" y1="20" x2="480" y2="20" stroke="#F1F5F9" strokeWidth="1" />
                <line x1="40" y1="70" x2="480" y2="70" stroke="#F1F5F9" strokeWidth="1" />
                <line x1="40" y1="120" x2="480" y2="120" stroke="#F1F5F9" strokeWidth="1" />
                <line x1="40" y1="170" x2="480" y2="170" stroke="#F1F5F9" strokeWidth="1" />

                {/* Draw Area Chart for Ticket Volume */}
                {(() => {
                  const points = monthlyData.map((d, i) => {
                    const x = 40 + i * 85;
                    // Max tickets count scale to 220 height
                    const maxVal = Math.max(...monthlyData.map(m => m.count), 100) * 1.1;
                    const y = 170 - (d.count / maxVal) * 130;
                    return { x, y };
                  });

                  if (points.length === 0) return null;
                  
                  const dPath = `M ${points[0].x} 170 ` + points.map(p => `L ${p.x} ${p.y}`).join(' ') + ` L ${points[points.length-1].x} 170 Z`;
                  const lPath = `M ` + points.map(p => `${p.x} ${p.y}`).join(' L ');

                  return (
                    <>
                      {/* Area Fill */}
                      <path d={dPath} fill="url(#indigoGrad)" opacity="0.15" />
                      {/* Area Line */}
                      <path d={lPath} fill="none" stroke="#4F46E5" strokeWidth="2.5" strokeLinecap="round" />
                      {/* Area Points */}
                      {points.map((p, idx) => (
                        <g key={idx}>
                          <circle cx={p.x} cy={p.y} r="4" fill="#FFFFFF" stroke="#4F46E5" strokeWidth="2" />
                          <text x={p.x} y={p.y - 10} fill="#1E293B" fontSize="10" fontWeight="bold" textAnchor="middle">
                            {monthlyData[idx].count}
                          </text>
                        </g>
                      ))}
                    </>
                  );
                })()}

                {/* Draw SLA Line (Secondary Y-Axis, 0-100) */}
                {(() => {
                  const points = monthlyData.map((d, i) => {
                    const x = 40 + i * 85;
                    const y = 170 - (d.slaRate / 100) * 130; // 0 to 100% maps to 130px height
                    return { x, y };
                  });

                  if (points.length === 0) return null;
                  const lPath = `M ` + points.map(p => `${p.x} ${p.y}`).join(' L ');

                  return (
                    <>
                      <path d={lPath} fill="none" stroke="#10B981" strokeWidth="2" strokeDasharray="4 3" />
                      {points.map((p, idx) => (
                        <circle key={idx} cx={p.x} cy={p.y} r="3" fill="#10B981" />
                      ))}
                    </>
                  );
                })()}

                {/* X Axis Labels */}
                {monthlyData.map((d, i) => {
                  const x = 40 + i * 85;
                  return (
                    <text key={i} x={x} y="195" fill="#64748B" fontSize="10" fontWeight="medium" textAnchor="middle">
                      {d.name}
                    </text>
                  );
                })}

                {/* Gradient Definitions */}
                <defs>
                  <linearGradient id="indigoGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#4F46E5" />
                    <stop offset="100%" stopColor="#818CF8" stopOpacity="0" />
                  </linearGradient>
                </defs>
              </svg>
              
              {/* Legend overlay */}
              <div className="absolute top-2 right-4 flex items-center gap-4 text-[10px]">
                <div className="flex items-center gap-1">
                  <span className="w-3 h-1.5 bg-indigo-600 rounded-sm" />
                  <span className="text-gray-500">Ticket Volume</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="w-3 h-0.5 border-t border-dashed border-emerald-500" />
                  <span className="text-gray-500">SLA Rate (%)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Plot 2: SLA Status Ring (Donut) */}
          <div className="bg-white rounded-xl shadow-xs border border-gray-100 p-5">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-bold text-indigo-950">SLA Status Distribution</span>
              <span className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Overall</span>
            </div>
            
            <div className="h-44 flex items-center justify-center relative mt-4">
              {(() => {
                const metCount = filteredTickets.filter(t => t.SLA_Status === 'Met').length;
                const breachedCount = filteredTickets.length - metCount;
                const total = filteredTickets.length;
                
                const metPct = total > 0 ? (metCount / total) * 100 : 0;
                const breachedPct = total > 0 ? (breachedCount / total) * 100 : 0;
                
                // SVG Donut Circle Constants
                const radius = 60;
                const circumference = 2 * Math.PI * radius;
                const strokeDashMet = (metPct / 100) * circumference;
                const strokeDashBreached = (breachedPct / 100) * circumference;
                
                return (
                  <div className="flex items-center gap-6">
                    <div className="relative flex items-center justify-center">
                      <svg width="150" height="150" className="transform -rotate-90">
                        {/* Background Gray Ring */}
                        <circle cx="75" cy="75" r={radius} fill="transparent" stroke="#E2E8F0" strokeWidth="16" />
                        
                        {/* Breached Segment */}
                        {breachedPct > 0 && (
                          <circle 
                            cx="75" cy="75" r={radius} fill="transparent" 
                            stroke="#EF4444" strokeWidth="16"
                            strokeDasharray={`${strokeDashBreached} ${circumference}`}
                            strokeDashoffset={-strokeDashMet}
                            strokeLinecap="round"
                          />
                        )}

                        {/* Met Segment */}
                        {metPct > 0 && (
                          <circle 
                            cx="75" cy="75" r={radius} fill="transparent" 
                            stroke="#10B981" strokeWidth="16"
                            strokeDasharray={`${strokeDashMet} ${circumference}`}
                          />
                        )}
                      </svg>
                      {/* CSAT or count central callout */}
                      <div className="absolute text-center">
                        <span className="text-xl font-extrabold text-slate-800">{metPct.toFixed(0)}%</span>
                        <span className="text-[9px] text-gray-400 block font-bold uppercase tracking-wider">Compliant</span>
                      </div>
                    </div>

                    <div className="flex flex-col gap-3 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 bg-emerald-500 rounded-sm shrink-0" />
                        <div>
                          <div className="font-semibold text-gray-700">Met SLA ({metCount})</div>
                          <div className="text-[10px] text-gray-400">{metPct.toFixed(1)}% of total</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="w-3 h-3 bg-red-500 rounded-sm shrink-0" />
                        <div>
                          <div className="font-semibold text-gray-700">Breached ({breachedCount})</div>
                          <div className="text-[10px] text-gray-400">{breachedPct.toFixed(1)}% of total</div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>

            <div className="border-t border-gray-50 pt-3 mt-3 text-[11px] text-gray-500 text-center italic">
              "Customer satisfaction falls by ~55% on average for breached tickets."
            </div>
          </div>

          {/* Plot 3: Ticket Volume by Issue Category (Horizontal Bar Chart) */}
          <div className="bg-white rounded-xl shadow-xs border border-gray-100 p-5">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-bold text-indigo-950">Volume by Issue Category</span>
              <span className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Ranked</span>
            </div>
            
            <div className="flex flex-col gap-3.5 h-64 overflow-y-auto pr-1">
              {categoryData.length === 0 ? (
                <div className="text-xs text-gray-400 text-center mt-12">No data fits search</div>
              ) : (
                categoryData.map((item, idx) => {
                  const maxCount = Math.max(...categoryData.map(c => c.count), 1);
                  const widthPct = (item.count / maxCount) * 100;
                  
                  return (
                    <div key={item.name} className="flex flex-col gap-1">
                      <div className="flex justify-between text-xs font-semibold text-gray-700">
                        <span className="truncate pr-2">{item.name}</span>
                        <span>{item.count} <span className="text-[10px] text-gray-400 font-normal">({((item.count/filteredTickets.length)*100).toFixed(0)}%)</span></span>
                      </div>
                      <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-indigo-600 rounded-full transition-all duration-500" 
                          style={{ width: `${widthPct}%` }}
                        />
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Plot 4: Resolution Speed by Priority (Column) */}
          <div className="bg-white rounded-xl shadow-xs border border-gray-100 p-5">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-bold text-indigo-950">Avg Resolution Hours by Priority</span>
              <span className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">SLA Target</span>
            </div>
            
            <div className="h-64 flex items-end justify-between px-2 pt-6 relative">
              {priorityData.map((p, idx) => {
                const maxVal = Math.max(...priorityData.map(item => item.avgHours), 12);
                const heightPct = maxVal > 0 ? (p.avgHours / maxVal) * 80 : 0;
                
                let barColor = 'bg-indigo-500';
                if (p.name === 'Critical') barColor = 'bg-rose-500';
                else if (p.name === 'High') barColor = 'bg-amber-400';
                else if (p.name === 'Medium') barColor = 'bg-blue-400';

                return (
                  <div key={p.name} className="flex flex-col items-center flex-1 group">
                    <div className="text-xs font-bold text-slate-800 mb-1 opacity-100 transition">
                      {p.avgHours > 0 ? `${p.avgHours}h` : '-'}
                    </div>
                    
                    <div className="w-10 bg-slate-50 rounded-t-md relative flex items-end h-40">
                      <div 
                        className={`w-full ${barColor} rounded-t-md transition-all duration-500`}
                        style={{ height: `${heightPct}%` }}
                      />
                    </div>
                    
                    <span className="text-[10px] font-bold text-gray-500 mt-2 truncate max-w-full text-center">
                      {p.name}
                    </span>
                    <span className="text-[8px] text-gray-400">
                      Count: {p.count}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Plot 5: CSAT by Team (Grouped columns/bars) */}
          <div className="bg-white rounded-xl shadow-xs border border-gray-100 p-5">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-bold text-indigo-950">Average CSAT Score by Support Team</span>
              <span className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Max 5.00</span>
            </div>
            
            <div className="flex flex-col gap-4 h-64 overflow-y-auto pr-1">
              {teamData.map(item => {
                // CSAT score out of 5
                const scorePct = (item.avgCsat / 5) * 100;
                let strokeColor = 'bg-indigo-600';
                if (item.avgCsat < 2.5) strokeColor = 'bg-rose-500';
                else if (item.avgCsat < 3.8) strokeColor = 'bg-amber-400';
                else strokeColor = 'bg-emerald-500';

                return (
                  <div key={item.name} className="flex flex-col gap-1">
                    <div className="flex justify-between text-xs font-semibold text-gray-700">
                      <span className="truncate pr-2">{item.name}</span>
                      <span className="text-indigo-700 font-bold">{item.avgCsat.toFixed(2)} ★</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                      <div 
                        className={`h-full ${strokeColor} rounded-full transition-all duration-500`} 
                        style={{ width: `${scorePct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* BOTTOM MATRIX: SUPPORT CHANNEL PERFORMANCE */}
        <div className="bg-white rounded-xl shadow-xs border border-gray-100 p-5">
          <div className="flex items-center justify-between mb-4">
            <span className="text-sm font-bold text-indigo-950">Support Channel Performance Metrics Matrix</span>
            <span className="text-xs text-indigo-600 font-semibold uppercase tracking-wider">Operational Integrity</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-gray-100 text-xs font-bold text-gray-400 uppercase tracking-wider">
                  <th className="py-3 px-4">Channel</th>
                  <th className="py-3 px-4 text-center">Ticket Volume</th>
                  <th className="py-3 px-4 text-center">Avg Response</th>
                  <th className="py-3 px-4 text-center">Avg Resolution</th>
                  <th className="py-3 px-4 text-center">SLA Compliance</th>
                  <th className="py-3 px-4 text-center">FCR Rate</th>
                </tr>
              </thead>
              <tbody>
                {['Chat', 'Phone', 'Social Media', 'Email'].map(channel => {
                  const items = filteredTickets.filter(t => t.Support_Channel === channel);
                  const total = items.length;
                  if (total === 0) return null;

                  const respSum = items.reduce((sum, item) => sum + item.First_Response_Minutes, 0) / total;
                  const resSum = items.reduce((sum, item) => sum + item.Resolution_Hours, 0) / total;
                  const metSla = (items.filter(item => item.SLA_Status === 'Met').length / total) * 100;
                  const fcr = (items.filter(item => item.First_Contact_Resolution === 'Yes').length / total) * 100;

                  return (
                    <tr key={channel} className="border-b border-gray-50 text-xs font-semibold text-gray-700 hover:bg-slate-50/50 transition">
                      <td className="py-3.5 px-4 text-indigo-950 font-bold">{channel}</td>
                      <td className="py-3.5 px-4 text-center">{total}</td>
                      <td className="py-3.5 px-4 text-center">{respSum.toFixed(1)} mins</td>
                      <td className="py-3.5 px-4 text-center">{resSum.toFixed(1)} hours</td>
                      <td className="py-3.5 px-4 text-center">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          metSla >= 80 ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                        }`}>
                          {metSla.toFixed(1)}%
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center text-slate-500">{fcr.toFixed(1)}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

      </div>

    </div>
  );
}
