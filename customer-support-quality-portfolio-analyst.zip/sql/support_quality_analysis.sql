-- =================================================================================
-- SENIOR DATA ANALYST PORTFOLIO PROJECT:
-- CUSTOMER SUPPORT QUALITY & AGENT PERFORMANCE ANALYSIS
-- 
-- This SQL script provides the schema and essential analysis queries used to 
-- evaluate support ticket volumes, agent productivity, SLA compliance, and CSAT scores.
-- 
-- Compatible with PostgreSQL, MySQL, and standard relational SQL databases.
-- =================================================================================

-- ---------------------------------------------------------------------------------
-- STEP 1: CREATE THE CUSTOMER SUPPORT TABLE
-- ---------------------------------------------------------------------------------
-- Deletes table if it exists to allow fresh installation
DROP TABLE IF EXISTS support_tickets;

CREATE TABLE support_tickets (
    Ticket_ID VARCHAR(10) PRIMARY KEY,
    Customer_ID VARCHAR(10) NOT NULL,
    Ticket_Date DATE NOT NULL,
    Customer_Name VARCHAR(100),
    Support_Channel VARCHAR(50) NOT NULL,
    Issue_Category VARCHAR(50) NOT NULL,
    Issue_Subcategory VARCHAR(100),
    Priority VARCHAR(20) NOT NULL,
    Agent_ID VARCHAR(10) NOT NULL,
    Agent_Name VARCHAR(100) NOT NULL,
    Team VARCHAR(100) NOT NULL,
    First_Response_Minutes INT,
    Resolution_Hours DECIMAL(5, 2),
    SLA_Target_Hours INT NOT NULL,
    SLA_Status VARCHAR(20) NOT NULL,
    Escalated VARCHAR(3) NOT NULL,                -- 'Yes' or 'No'
    First_Contact_Resolution VARCHAR(3) NOT NULL, -- 'Yes' or 'No'
    Reopened VARCHAR(3) NOT NULL,                 -- 'Yes' or 'No'
    Customer_Satisfaction_Score INT,              -- Value from 1 to 5
    Ticket_Status VARCHAR(20) NOT NULL,           -- 'Open', 'Pending', 'Closed'
    Region VARCHAR(50) NOT NULL
);

-- Note: To populate this table from CSV in PostgreSQL, you can run:
-- COPY support_tickets FROM '/path/to/support_tickets_cleaned.csv' DELIMITER ',' CSV HEADER;


-- ---------------------------------------------------------------------------------
-- 2. TOTAL TICKETS BY MONTH
-- ---------------------------------------------------------------------------------
-- Analyzes monthly customer ticket influx trends
SELECT 
    TO_CHAR(Ticket_Date, 'YYYY-MM') AS Year_Month,
    COUNT(Ticket_ID) AS Total_Tickets,
    ROUND(COUNT(Ticket_ID) * 100.0 / SUM(COUNT(Ticket_ID)) OVER(), 1) AS Percent_Contribution
FROM support_tickets
GROUP BY TO_CHAR(Ticket_Date, 'YYYY-MM')
ORDER BY Year_Month;


-- ---------------------------------------------------------------------------------
-- 3. TICKET VOLUME BY CATEGORY
-- ---------------------------------------------------------------------------------
-- Identifies the major complaint areas and volume drivers
SELECT 
    Issue_Category,
    COUNT(Ticket_ID) AS Total_Tickets,
    ROUND(COUNT(Ticket_ID) * 100.0 / SUM(COUNT(Ticket_ID)) OVER(), 1) AS Percent_Total
FROM support_tickets
GROUP BY Issue_Category
ORDER BY Total_Tickets DESC;


-- ---------------------------------------------------------------------------------
-- 4. AVERAGE RESPONSE TIME (MINUTES) BY CHANNEL
-- ---------------------------------------------------------------------------------
-- Assesses response speed efficiency across communication platforms
SELECT 
    Support_Channel,
    COUNT(Ticket_ID) AS Ticket_Count,
    ROUND(AVG(First_Response_Minutes), 1) AS Avg_Response_Minutes
FROM support_tickets
GROUP BY Support_Channel
ORDER BY Avg_Response_Minutes ASC;


-- ---------------------------------------------------------------------------------
-- 5. AVERAGE RESOLUTION TIME (HOURS) BY PRIORITY
-- ---------------------------------------------------------------------------------
-- Evaluates if high-priority/critical cases are resolved faster as expected
SELECT 
    Priority,
    COUNT(Ticket_ID) AS Ticket_Count,
    ROUND(AVG(Resolution_Hours), 1) AS Avg_Resolution_Hours,
    ROUND(AVG(SLA_Target_Hours), 1) AS Avg_SLA_Target_Hours
FROM support_tickets
GROUP BY Priority
ORDER BY 
    CASE Priority
        WHEN 'Critical' THEN 1
        WHEN 'High' THEN 2
        WHEN 'Medium' THEN 3
        WHEN 'Low' THEN 4
    END;


-- ---------------------------------------------------------------------------------
-- 6. SLA COMPLIANCE BY AGENT
-- ---------------------------------------------------------------------------------
-- Measures individual agent ticket compliance within their SLA targets
SELECT 
    Agent_Name,
    Team,
    COUNT(Ticket_ID) AS Total_Assigned,
    SUM(CASE WHEN SLA_Status = 'Met' THEN 1 ELSE 0 END) AS SLA_Met_Tickets,
    ROUND(SUM(CASE WHEN SLA_Status = 'Met' THEN 1 ELSE 0 END) * 100.0 / COUNT(Ticket_ID), 1) AS SLA_Compliance_Rate
FROM support_tickets
GROUP BY Agent_Name, Team
ORDER BY SLA_Compliance_Rate DESC;


-- ---------------------------------------------------------------------------------
-- 7. ESCALATION RATE BY CATEGORY
-- ---------------------------------------------------------------------------------
-- pinpoints which types of complaints are most difficult and require transfers
SELECT 
    Issue_Category,
    COUNT(Ticket_ID) AS Total_Tickets,
    SUM(CASE WHEN Escalated = 'Yes' THEN 1 ELSE 0 END) AS Escalated_Count,
    ROUND(SUM(CASE WHEN Escalated = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(Ticket_ID), 1) AS Escalation_Rate
FROM support_tickets
GROUP BY Issue_Category
ORDER BY Escalation_Rate DESC;


-- ---------------------------------------------------------------------------------
-- 8. CUSTOMER SATISFACTION (CSAT) BY TEAM
-- ---------------------------------------------------------------------------------
-- Monitors average satisfaction score at a group/team level
SELECT 
    Team,
    COUNT(Ticket_ID) AS Total_Resolved,
    ROUND(AVG(Customer_Satisfaction_Score), 2) AS Avg_CSAT_Score,
    ROUND(SUM(CASE WHEN Customer_Satisfaction_Score >= 4 THEN 1 ELSE 0 END) * 100.0 / COUNT(Ticket_ID), 1) AS Positive_CSAT_Rate_Pct
FROM support_tickets
GROUP BY Team
ORDER BY Avg_CSAT_Score DESC;


-- ---------------------------------------------------------------------------------
-- 9. FIRST-CONTACT RESOLUTION (FCR) BY AGENT
-- ---------------------------------------------------------------------------------
-- Tracks an agent's capability to resolve issues immediately on the first touchpoint
SELECT 
    Agent_Name,
    Team,
    COUNT(Ticket_ID) AS Total_Tickets,
    SUM(CASE WHEN First_Contact_Resolution = 'Yes' THEN 1 ELSE 0 END) AS FCR_Tickets,
    ROUND(SUM(CASE WHEN First_Contact_Resolution = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(Ticket_ID), 1) AS FCR_Rate_Pct
FROM support_tickets
GROUP BY Agent_Name, Team
ORDER BY FCR_Rate_Pct DESC;


-- ---------------------------------------------------------------------------------
-- 10. REOPENED TICKETS BY ISSUE CATEGORY
-- ---------------------------------------------------------------------------------
-- Identifies categories experiencing high rework or unresolved issues initially
SELECT 
    Issue_Category,
    COUNT(Ticket_ID) AS Total_Tickets,
    SUM(CASE WHEN Reopened = 'Yes' THEN 1 ELSE 0 END) AS Reopened_Count,
    ROUND(SUM(CASE WHEN Reopened = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(Ticket_ID), 1) AS Reopen_Rate_Pct
FROM support_tickets
GROUP BY Issue_Category
ORDER BY Reopen_Rate_Pct DESC;


-- ---------------------------------------------------------------------------------
-- 11. TOP-PERFORMING AGENTS (EXECUTIVE LIST)
-- ---------------------------------------------------------------------------------
-- Ranks agents based on an overall score (High CSAT, SLA Compliance & FCR)
SELECT 
    Agent_Name,
    Team,
    COUNT(Ticket_ID) AS Tickets_Resolved,
    ROUND(AVG(Customer_Satisfaction_Score), 2) AS Avg_CSAT,
    ROUND(SUM(CASE WHEN SLA_Status = 'Met' THEN 1 ELSE 0 END) * 100.0 / COUNT(Ticket_ID), 1) AS SLA_Compliance_Pct,
    ROUND(SUM(CASE WHEN First_Contact_Resolution = 'Yes' THEN 1 ELSE 0 END) * 100.0 / COUNT(Ticket_ID), 1) AS FCR_Pct
FROM support_tickets
GROUP BY Agent_Name, Team
HAVING COUNT(Ticket_ID) >= 50
ORDER BY Avg_CSAT DESC, SLA_Compliance_Pct DESC
LIMIT 5;


-- ---------------------------------------------------------------------------------
-- 12. AGENTS WITH HIGHEST SLA BREACH RATE
-- ---------------------------------------------------------------------------------
-- Unveils low compliance performers requiring performance reviews/coaching
SELECT 
    Agent_Name,
    Team,
    COUNT(Ticket_ID) AS Total_Tickets,
    SUM(CASE WHEN SLA_Status = 'Breached' THEN 1 ELSE 0 END) AS SLA_Breaches,
    ROUND(SUM(CASE WHEN SLA_Status = 'Breached' THEN 1 ELSE 0 END) * 100.0 / COUNT(Ticket_ID), 1) AS SLA_Breach_Rate_Pct
FROM support_tickets
GROUP BY Agent_Name, Team
HAVING COUNT(Ticket_ID) >= 30
ORDER BY SLA_Breach_Rate_Pct DESC
LIMIT 5;


-- ---------------------------------------------------------------------------------
-- 13. CATEGORIES WITH THE LOWEST CUSTOMER SATISFACTION (CSAT)
-- ---------------------------------------------------------------------------------
-- Points out system bottlenecks or sub-par products lowering consumer trust
SELECT 
    Issue_Category,
    COUNT(Ticket_ID) AS Total_Tickets,
    ROUND(AVG(Customer_Satisfaction_Score), 2) AS Avg_CSAT_Score,
    SUM(CASE WHEN Customer_Satisfaction_Score <= 2 THEN 1 ELSE 0 END) AS Dissatisfied_Customers_Count,
    ROUND(SUM(CASE WHEN Customer_Satisfaction_Score <= 2 THEN 1 ELSE 0 END) * 100.0 / COUNT(Ticket_ID), 1) AS Dissatisfied_Rate_Pct
FROM support_tickets
GROUP BY Issue_Category
ORDER BY Avg_CSAT_Score ASC;


-- ---------------------------------------------------------------------------------
-- 14. MONTHLY TREND OF SLA PERFORMANCE
-- ---------------------------------------------------------------------------------
-- Monitors monthly fluctuations in SLA metrics to check if operations are stable
SELECT 
    TO_CHAR(Ticket_Date, 'YYYY-MM') AS Year_Month,
    COUNT(Ticket_ID) AS Total_Tickets,
    SUM(CASE WHEN SLA_Status = 'Met' THEN 1 ELSE 0 END) AS SLA_Met_Count,
    SUM(CASE WHEN SLA_Status = 'Breached' THEN 1 ELSE 0 END) AS SLA_Breached_Count,
    ROUND(SUM(CASE WHEN SLA_Status = 'Met' THEN 1 ELSE 0 END) * 100.0 / COUNT(Ticket_ID), 1) AS SLA_Compliance_Pct
FROM support_tickets
GROUP BY TO_CHAR(Ticket_Date, 'YYYY-MM')
ORDER BY Year_Month;
