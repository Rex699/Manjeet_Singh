# Customer Support Quality & Agent Performance Analysis
### Senior Data Analyst Portfolio Project

Welcome to the **Customer Support Quality and Agent Performance Analysis** project. This repository is a comprehensive portfolio demonstrating advanced data analytics capabilities suitable for roles such as **Data Analyst**, **Quality Analyst**, **Customer Support Analyst**, **MIS Executive**, and **Operations Analyst**.

This project provides an end-to-end operational analytics workflow—from raw data synthesis and ingestion to Python-based cleaning, SQL query execution, and multi-tool reporting (Power BI & Microsoft Excel).

---

## 1. Project Folder Structure

```text
Customer-Support-Quality-Analytics/
│
├── data/
│   ├── support_tickets_raw.csv           # Raw dataset (1,525 rows with duplicate & blank anomalies)
│   └── support_tickets_cleaned.csv       # Cleaned and processed dataset (1,520 unique validated rows)
│
├── python/
│   └── support_quality_analysis.py       # Pandas data cleaning, metrics extraction, and Matplotlib plotting
│
├── sql/
│   └── support_quality_analysis.sql      # Standard SQL queries for KPI reporting, segment profiling, & rank scorecards
│
├── outputs/
│   ├── agent_performance.csv             # Computed agent metrics and performance scores
│   ├── category_summary.csv              # Metric summaries by issue category
│   └── monthly_summary.csv               # Monthly operational KPIs and trends
│
├── powerbi/
│   └── dashboard_instructions.md         # Comprehensive Power BI blueprint and complex DAX formulas
│
├── excel/
│   └── excel_dashboard_instructions.md   # Step-by-step Pivot Table and Excel formula implementation manual
│
└── README.md                             # Project presentation, insights, recommendations, and interview prep
```

---

## 2. Business Problem & Project Objective

In high-volume customer operations, support centers serve as the primary touchpoint for customer retention. However, management often struggles to balance operational speed with quality. 

This project analyzes a synthetic dataset representing **1,520 unique support tickets** generated over a 6-month period (January–June 2026) across five key teams:
*   **Payments Team**
*   **Order Support**
*   **Technical Support**
*   **Account Support**
*   **Escalation Desk**

### Analytical Goals:
1.  **Ticket Volume & Trends:** Profile ticket frequencies over time and across categories to manage agent capacity.
2.  **SLA Compliance & Speed:** Audit response times and identify bottleneck agents/categories breaching SLAs.
3.  **Customer Satisfaction (CSAT):** Uncover factors causing dissatisfied reviews (SLA breaches, reopened cases, escalations).
4.  **Operational Performance & FCR:** Evaluate individual agent and channel efficiency using First-Contact Resolution (FCR) metrics.

---

## 3. Dataset Information

The data represents customer support interactions across various channels (Email, Chat, Phone, Social Media), priorities (Low, Medium, High, Critical), regions (North, South, East, West, Central), and issue categories (Payment, Refund, Delivery, Account, Product, Technical, Cancellation).

### Core Fields and Schema:
*   `Ticket_ID`: Unique alpha-numeric ticket code (T1001 onwards).
*   `Customer_ID` / `Customer_Name`: Associated customer details.
*   `Support_Channel` / `Region`: Channel and geographic segment.
*   `Issue_Category` / `Issue_Subcategory`: Specific category profiling.
*   `Priority`: Ticket severity ('Low', 'Medium', 'High', 'Critical').
*   `Agent_ID` / `Agent_Name` / `Team`: Support staff assignments.
*   `First_Response_Minutes`: Duration from ticket creation to first agent message.
*   `Resolution_Hours`: Entire resolution lifecycle in hours.
*   `SLA_Target_Hours`: Assigned SLA window based on ticket priority.
*   `SLA_Status`: Validated compliance status ('Met' or 'Breached').
*   `Escalated` / `Reopened` / `First_Contact_Resolution`: Logic flags ('Yes'/'No').
*   `Customer_Satisfaction_Score`: Customer rating (1 to 5 stars).
*   `Ticket_Status`: Lifetime state of ticket ('Closed').

---

## 4. Tools & Methodologies Used

*   **Python (Pandas, NumPy, Matplotlib):** Used for initial data load, parsing dates, identifying duplicates/missing values, rule-validation, categorical binning, and exporting summary reports.
*   **SQL (PostgreSQL):** Applied schema creations and developed standard-compliant aggregation queries to build views, agent scorecards, and trends.
*   **Power BI:** Developed DAX calculations, interactive bento grids, custom slicer flows, and conditional formatting maps.
*   **Microsoft Excel:** Modeled dynamic trackers using `XLOOKUP`, `COUNTIFS`, `AVERAGEIFS`, Pivot Tables, Pivot Charts, and Conditional Formatting.

---

## 5. Data Cleaning Steps (Implemented in Python)

1.  **Duplicate Removal:** Evaluated duplicate `Ticket_ID` entries and removed 5 duplicated rows, keeping only the first chronological log.
2.  **Data Type Conversion:** Standardized and parsed `Ticket_Date` as a Datetime field and cast response times, resolution times, and CSAT scores to numeric types.
3.  **Missing Value Imputation:** Identified 15 rows with missing `Customer_Satisfaction_Score` values and imputed them using the overall median CSAT score of 4.0.
4.  **Business Logic Auditing:** Discovered that some SLA status values in raw inputs were misclassified. Overwrote the column with clean logic: `Resolution_Hours <= SLA_Target_Hours` is categorized as `Met`, otherwise `Breached`.
5.  **Performance Categorization:** Created performance buckets:
    *   *First Response Category:* Fast (<10m), Medium (10-30m), Slow (30m+).
    *   *Resolution Time Category:* Quick (<4h), Standard (4-12h), Extended (12h+).

---

## 6. Business Insights (Derived from Generated Data)

Based on the statistical analysis of our cleaned dataset, we extracted the following key operational findings:

1.  **Ticket Volume Concentration:** **Product** issues are the single largest driver of incoming tickets, accounting for **~24%** of total ticket volume, followed closely by **Payment** queries (~21%).
2.  **SLA Compliance & Priority:** Average resolution time is shortest for **Critical** tickets (4.1 hours) but highest for **Low**-priority tickets (18.6 hours). However, **Critical** tickets experience the highest SLA breach rate (**~35%**) because of extremely tight SLA windows (4 hours).
3.  **Customer Satisfaction & SLA Breaches:** There is a heavy correlation between speed and satisfaction. Tickets where the SLA was **Met** averaged a high **CSAT score of 4.25 / 5.0**, whereas **Breached** tickets plummeted to a poor **1.86 / 5.0**.
4.  **Team Satisfaction Leaders:** The **Payments Team** leads the organization in quality with an average CSAT score of **4.42 / 5.0**, while the **Escalation Desk** exhibits the lowest average score (**2.10 / 5.0**), as they handle highly frustrated customers and reopened cases.
5.  **Channel Efficiency:** **Phone** and **Chat** are highly effective channels, achieving over **75% First-Contact Resolution (FCR) rate**. **Email** is the slowest channel, averaging a **42-minute response time** and under **45% FCR**.
6.  **Reopened Ticket Correlation:** Tickets marked as `Reopened = Yes` show a strong correlation with extremely low customer satisfaction scores (average **1.95 CSAT** vs **4.15** for non-reopened tickets), highlighting a major operational quality gap.
7.  **Escalation Trigger Drivers:** **Cancellation** and **Refund** requests are the most prone to escalation, with escalation rates exceeding **15%**, typically triggered by delays in processing payments.
8.  **Monthly Volume Influx:** Ticket volume remained stable across the 6-month period, but a slight **5% increase** in volume in May and June coincided with a **3% drop in SLA compliance**, pointing to resource constraints.

---

## 7. Operational Recommendations

1.  **SLA Breach Coaching & Redistribution:** Focus performance improvements on slower-than-average agents (such as *Vikas Kumar* and *Rahul Roy*) who drive the highest SLA breaches. Implement shadow training with top performers (*Sakshi Jain* and *Anjali Sharma*).
2.  **Self-Service Knowledge Base Articles:** Build automated, in-app self-service articles for "Password Reset", "Refund Delayed", and "Order Status Tracking" to deflect up to **20%** of inbound **Account** and **Delivery** tickets from Email and Chat.
3.  **Critical Ticket Routing Optimization:** Revamp the ticket routing algorithm to route incoming **Critical** priority tickets directly to available experienced tier-2 support agents rather than routing them through tier-1 triage, saving up to 45 minutes of idle wait time.
4.  **FCR Quality Checklist:** Introduce a mandatory "Resolution Verification" checklist before closing tickets, specifically targeting **Refunds** and **Technical** categories, to reduce the high reopen rate from 8% down to a target of 4%.
5.  **Weekly Operational Desk Audits:** Establish a cross-functional weekly meeting between the *Escalation Desk* and the *Product Team* to address root-cause product defects causing recurring issues, preventing issues at the source.

---

## 8. Agent Performance Score Formula

To grade support agents fairly, we created a composite, balanced **Agent Performance Score (0-100)**:

$$\text{Performance Score} = (\text{SLA Compliance} \times 0.3) + (\text{Normalized CSAT} \times 0.3) + (\text{FCR Rate} \times 0.2) + (\text{Normalized Speed} \times 0.1) + (\text{Normalized Escalation} \times 0.1)$$

### Why this is a Fair Metric:
*   **Quality & Compliance Lead (60%):** Equal weights on SLA Compliance (speed accuracy) and Customer Satisfaction (quality).
*   **Normalized CSAT:** Calculated as `(CSAT - 1) / 4` to scale a 1-to-5 star score perfectly between 0.0 and 1.0.
*   **Normalized Speed:** Calculated as `1 - (Avg_Resolution / 24)`. This ensures that agents handling complex tickets (which takes longer but is resolved well within a 24-hour baseline) are not unfairly penalized compared to agents handling quick password resets.
*   **Escalation Control:** Rewards agents who resolve issues directly rather than unnecessarily escalating them (`1 - Escalation_Rate`).

---

## 9. How to Run the Code

### Python Analysis:
1. Ensure Python 3.8+ is installed.
2. Install dependencies:
   ```bash
   pip install pandas numpy matplotlib
   ```
3. Run the script:
   ```bash
   python python/support_quality_analysis.py
   ```
4. Output summaries and PNG charts will be saved to the `outputs/` and `outputs/charts/` directories.

### SQL Database Queries:
1. Open any SQL compiler (PgAdmin, DBeaver, or local Postgres CLI).
2. Create the table and load data using the queries in `sql/support_quality_analysis.sql`.
3. Execute any query block to retrieve specified KPIs instantly.

---

## 10. Resume Highlights (ATS-Friendly)

*   **Customer Support & Quality Analysis Project:** Modeled and analyzed a synthetic dataset of 1,500+ customer support tickets, developing automated Python and SQL workflows to clean duplicate entries and impute missing data.
*   **Operational KPIs & Scorecards:** Engineered an advanced, multi-weighted Agent Performance Score combining SLA compliance, customer satisfaction (CSAT), and first-contact resolution (FCR), identifying underperforming operational bottlenecks.
*   **Visual Dashboards & Analytics Reporting:** Constructed comprehensive Power BI and Excel dashboards with interactive slicers, pivot tables, and conditional formatting to track monthly support trends, reducing SLA breach visibility latency.

---

## 11. Interview Preparation Sheet

### 1. The 60-Second Project Pitch
> "I recently designed and developed an end-to-end Operations and Quality Analytics project focused on evaluating customer support quality and agent performance. I synthesized a realistic dataset of over 1,500 support records spanning five functional teams and multiple communication channels over a six-month period. Using Python, I cleaned duplicate files and handled missing values, then used SQL to build comprehensive, structured queries that track monthly volumes, channel speeds, and team rankings.
> 
> A key highlight was designing a composite **Agent Performance Score** that balances SLA, CSAT, and FCR to grade agent performance fairly without penalizing agents handling high-complexity tickets. Finally, I built actionable report manuals for Excel and Power BI to display these metrics visually in an interactive layout. This project demonstrates my ability to transform raw, messy operational log data into rich business insights and strategic recommendations."

### 2. Five Common Interview Questions & Answers
1.  **Q: How did you handle data quality issues in your analysis?**
    *   *A:* "I wrote a Python script using Pandas to scan the raw data for duplicated Ticket IDs, keeping only the first record. I also scanned for missing values and discovered 15 rows where the CSAT rating was missing; I imputed these using the median CSAT score of 4.0. Finally, I audited the SLA status column to ensure the business rule was met—that SLA was 'Met' if and only if Resolution Hours was less than or equal to SLA Target Hours—re-writing entries that violated this rule."
2.  **Q: Why did you choose a multi-weighted formula for the Agent Performance Score?**
    *   *A:* "A single metric like 'Resolution Speed' is a poor representation of quality. Slower agents might be handling complex issues, whereas fast agents might have low CSAT scores. My formula weights SLA Compliance and CSAT equally at 30% each, First-Contact Resolution at 20%, and Resolution Speed and Escalation Rate at 10% each. I normalized resolution speed against a 24-hour baseline to ensure agents handling difficult tickets are graded fairly."
3.  **Q: What was the most important business finding from this dataset?**
    *   *A:* "The heavy correlation between SLA breaches and low customer satisfaction. When SLAs were Met, the average CSAT score was 4.25 out of 5. But when SLAs were Breached, the average CSAT dropped to 1.86. Additionally, we found that reopened tickets also scored extremely low, averaging 1.95 CSAT. This shows that operational speed and resolution accuracy directly impact customer retention."
4.  **Q: How would you scale this project to handle real-time production data?**
    *   *A:* "To scale this, I would migrate the static CSV dataset to a relational database like PostgreSQL or Snowflake. I would set up an ETL or ELT pipeline (using tools like dbt or Apache Airflow) to load ticket logs nightly, run data cleaning routines, and refresh the Power BI dashboard automatically using scheduled gateway refreshes."
5.  **Q: Which team exhibited the lowest performance, and what did you recommend?**
    *   *A:* "The Escalation Desk had the lowest average CSAT score of 2.10, which is expected since they handle unresolved tier-1 issues. However, the Order Support team had the lowest SLA compliance rate (under 72%) and high breach rates driven by agents Vikas Kumar and Rahul Roy. I recommended coaching and shadowing program for these agents under high-performing peers."
