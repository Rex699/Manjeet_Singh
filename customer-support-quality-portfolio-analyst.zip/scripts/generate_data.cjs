/**
 * Data Generator for Customer Support Quality & Agent Performance Analysis
 * Generates 1,500+ realistic ticket records with logical relationships and real-world anomalies.
 */

const fs = require('fs');
const path = require('path');

// Target Directories
const dirs = [
  path.join(__dirname, '../data'),
  path.join(__dirname, '../outputs'),
  path.join(__dirname, '../src/data')
];

dirs.forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

// Seed Data & Config
const regions = ['North', 'South', 'East', 'West', 'Central'];
const channels = ['Email', 'Chat', 'Phone', 'Social Media'];

const categories = {
  'Payment': {
    subcategories: ['Payment Failed', 'Double Charge', 'Payment Method Error'],
    team: 'Payments Team',
    agents: [
      { id: 'A101', name: 'Anjali Sharma' },
      { id: 'A107', name: 'Neha Reddy' }
    ]
  },
  'Refund': {
    subcategories: ['Refund Delayed', 'Refund Not Received', 'Partial Refund'],
    team: 'Order Support',
    agents: [
      { id: 'A102', name: 'Rohit Verma' },
      { id: 'A104', name: 'Vikas Kumar' },
      { id: 'A108', name: 'Rahul Roy' }
    ]
  },
  'Delivery': {
    subcategories: ['Order Delayed', 'Wrong Item Delivered', 'Damaged Product'],
    team: 'Order Support',
    agents: [
      { id: 'A102', name: 'Rohit Verma' },
      { id: 'A104', name: 'Vikas Kumar' },
      { id: 'A108', name: 'Rahul Roy' }
    ]
  },
  'Account': {
    subcategories: ['Login Issue', 'Password Reset', 'Account Suspended'],
    team: 'Account Support',
    agents: [
      { id: 'A105', name: 'Sakshi Jain' },
      { id: 'A110', name: 'Sanjay Gupta' }
    ]
  },
  'Product': {
    subcategories: ['Product Defect', 'Out of Stock', 'Warranty Claim'],
    team: 'Order Support',
    agents: [
      { id: 'A102', name: 'Rohit Verma' },
      { id: 'A104', name: 'Vikas Kumar' },
      { id: 'A108', name: 'Rahul Roy' }
    ]
  },
  'Technical': {
    subcategories: ['App Crash', 'Website Error', 'Sync Failure'],
    team: 'Technical Support',
    agents: [
      { id: 'A103', name: 'Priya Nair' },
      { id: 'A109', name: 'Vikram Malhotra' }
    ]
  },
  'Cancellation': {
    subcategories: ['Cancellation Failed', 'Order Cancellation'],
    team: 'Escalation Desk',
    agents: [
      { id: 'A106', name: 'Arjun Singh' },
      { id: 'A111', name: 'Siddharth Roy' }
    ]
  }
};

const customerNames = [
  'Rahul Mehta', 'Simran Kaur', 'Aman Patel', 'Neha Singh', 'Karan Malhotra',
  'Pooja Yadav', 'Aditya Joshi', 'Riya Kapoor', 'Mohit Gupta', 'Isha Sharma',
  'Deepak Verma', 'Shweta Tiwari', 'Rohan Sharma', 'Ananya Sen', 'Amit Mishra',
  'Priyanka Das', 'Varun Dhawan', 'Sonia Gandhi', 'Rajesh Khanna', 'Kiran Bedi',
  'Sunita Williams', 'Arvind Kejriwal', 'Nitin Gadkari', 'Smriti Irani', 'Mamata Banerjee',
  'Suresh Raina', 'Mahendra Singh', 'Virat Kohli', 'Rohit Sharma', 'Jasprit Bumrah',
  'Hardik Pandya', 'Rishabh Pant', 'Ravindra Jadeja', 'Shikhar Dhawan', 'Cheteshwar Pujara',
  'Ajinkya Rahane', 'KL Rahul', 'Shreyas Iyer', 'Yuzvendra Chahal', 'Kuldeep Yadav',
  'Bhuvneshwar Kumar', 'Mohammed Shami', 'Ishant Sharma', 'Umesh Yadav', 'Sanju Samson'
];

// Helper to get random item
const randomItem = (arr) => arr[Math.floor(Math.random() * arr.length)];
// Helper for normal-ish distributions
const randomRange = (min, max) => Math.random() * (max - min) + min;
const randomInt = (min, max) => Math.floor(randomRange(min, max + 1));

// Base generation arrays
const tickets = [];
const ticketCount = 1520; // Generate 1520 records

// Set Date Range: 2026-01-01 to 2026-06-30
const startDate = new Date('2026-01-01T00:00:00');
const endDate = new Date('2026-06-30T23:59:59');

for (let i = 0; i < ticketCount; i++) {
  const ticketId = `T${1001 + i}`;
  const customerId = `C${String(1001 + (i % 234)).padStart(3, '0')}`; // Reuse customers
  
  // Distribute tickets chronologically
  const progress = i / ticketCount;
  const ticketTime = new Date(startDate.getTime() + progress * (endDate.getTime() - startDate.getTime()));
  // Format as YYYY-MM-DD
  const ticketDateStr = ticketTime.toISOString().split('T')[0];
  
  const customerName = randomItem(customerNames);
  const supportChannel = randomItem(channels);
  const issueCategory = randomItem(Object.keys(categories));
  const categoryConfig = categories[issueCategory];
  const issueSubcategory = randomItem(categoryConfig.subcategories);
  
  // Decide Priority with some category weights
  let priority = 'Medium';
  const r = Math.random();
  if (issueCategory === 'Technical' || issueCategory === 'Payment') {
    priority = r < 0.25 ? 'Critical' : r < 0.6 ? 'High' : r < 0.9 ? 'Medium' : 'Low';
  } else {
    priority = r < 0.05 ? 'Critical' : r < 0.25 ? 'High' : r < 0.75 ? 'Medium' : 'Low';
  }
  
  // Select Agent & Team
  let agent = randomItem(categoryConfig.agents);
  let team = categoryConfig.team;
  
  // Some escalations move to the Escalation Desk!
  let escalated = Math.random() < 0.12 ? 'Yes' : 'No';
  if (escalated === 'Yes' && Math.random() < 0.7) {
    team = 'Escalation Desk';
    agent = randomItem([{ id: 'A106', name: 'Arjun Singh' }, { id: 'A111', name: 'Siddharth Roy' }]);
  }
  
  // SLA Target Hours based on Priority
  let slaTargetHours = 12;
  if (priority === 'Critical') slaTargetHours = 4;
  else if (priority === 'High') slaTargetHours = 8;
  else if (priority === 'Medium') slaTargetHours = 12;
  else if (priority === 'Low') slaTargetHours = 24;

  // First Response Minutes (dependent on Channel and Priority)
  let firstResponseMin = 30;
  let responseMultiplier = 1.0;
  if (supportChannel === 'Chat') responseMultiplier = 0.2;
  else if (supportChannel === 'Phone') responseMultiplier = 0.15;
  else if (supportChannel === 'Social Media') responseMultiplier = 0.6;
  else if (supportChannel === 'Email') responseMultiplier = 2.0;

  if (priority === 'Critical') {
    firstResponseMin = Math.round(randomRange(2, 15) * responseMultiplier);
  } else if (priority === 'High') {
    firstResponseMin = Math.round(randomRange(5, 30) * responseMultiplier);
  } else {
    firstResponseMin = Math.round(randomRange(10, 60) * responseMultiplier);
  }
  firstResponseMin = Math.max(1, firstResponseMin); // at least 1 min

  // Resolution Hours (influenced by Escalation, Reopen, and Priority)
  let resolutionHours = 0;
  let resolutionBase = slaTargetHours;
  
  // Performance variations for agents
  // Arjun Singh and Siddharth Roy handle Escalation Desk, their resolution times are higher
  let agentMultiplier = 1.0;
  if (agent.id === 'A102' || agent.id === 'A105') agentMultiplier = 0.8; // High performers
  if (agent.id === 'A104' || agent.id === 'A108') agentMultiplier = 1.35; // Slower/SLA breachers
  
  let reopenRate = 0.08;
  if (agent.id === 'A108') reopenRate = 0.15; // Higher reopen rate
  const reopened = Math.random() < reopenRate ? 'Yes' : 'No';

  let fcrRate = 0.68;
  if (supportChannel === 'Email') fcrRate = 0.45;
  if (supportChannel === 'Chat' || supportChannel === 'Phone') fcrRate = 0.80;
  if (escalated === 'Yes' || reopened === 'Yes') fcrRate = 0.05; // Escalated or Reopened can't easily be FCR
  const firstContactResolution = Math.random() < fcrRate ? 'Yes' : 'No';

  let resolutionMultiplier = agentMultiplier;
  if (escalated === 'Yes') resolutionMultiplier *= 2.5;
  if (reopened === 'Yes') resolutionMultiplier *= 1.8;
  if (firstContactResolution === 'Yes') resolutionMultiplier *= 0.4;

  // Normal random resolution hours
  resolutionHours = parseFloat((randomRange(0.2, 1.4) * resolutionBase * resolutionMultiplier).toFixed(1));
  resolutionHours = Math.max(0.1, resolutionHours);

  // SLA Status mapping
  const slaStatus = resolutionHours <= slaTargetHours ? 'Met' : 'Breached';

  // Customer Satisfaction Score (1 to 5)
  // Highly correlated with SLA Status, Reopened, Escalated, Response Time, and Agent Performance
  let csat = 5;
  let csatScoreChance = Math.random();

  if (slaStatus === 'Breached') {
    // Mostly 1, 2 or 3
    csat = csatScoreChance < 0.4 ? 1 : csatScoreChance < 0.7 ? 2 : csatScoreChance < 0.9 ? 3 : 4;
  } else if (reopened === 'Yes') {
    csat = csatScoreChance < 0.3 ? 2 : csatScoreChance < 0.6 ? 3 : csatScoreChance < 0.9 ? 4 : 5;
  } else if (escalated === 'Yes') {
    csat = csatScoreChance < 0.2 ? 2 : csatScoreChance < 0.5 ? 3 : csatScoreChance < 0.8 ? 4 : 5;
  } else {
    // Good tickets, mostly 4 and 5
    csat = csatScoreChance < 0.05 ? 2 : csatScoreChance < 0.15 ? 3 : csatScoreChance < 0.5 ? 4 : 5;
  }

  // Ensure high-performer agents have slightly higher CSAT and poor performers lower CSAT
  if (agent.id === 'A102' || agent.id === 'A105') {
    if (csat < 5 && Math.random() < 0.3) csat += 1;
  }
  if (agent.id === 'A104' || agent.id === 'A108') {
    if (csat > 1 && Math.random() < 0.3) csat -= 1;
  }

  const ticketStatus = 'Closed'; // All historical records in the analysis are Closed
  const region = randomItem(regions);

  tickets.push({
    Ticket_ID: ticketId,
    Customer_ID: customerId,
    Ticket_Date: ticketDateStr,
    Customer_Name: customerName,
    Support_Channel: supportChannel,
    Issue_Category: issueCategory,
    Issue_Subcategory: issueSubcategory,
    Priority: priority,
    Agent_ID: agent.id,
    Agent_Name: agent.name,
    Team: team,
    First_Response_Minutes: firstResponseMin,
    Resolution_Hours: resolutionHours,
    SLA_Target_Hours: slaTargetHours,
    SLA_Status: slaStatus,
    Escalated: escalated,
    First_Contact_Resolution: firstContactResolution,
    Reopened: reopened,
    Customer_Satisfaction_Score: csat,
    Ticket_Status: ticketStatus,
    Region: region
  });
}

// Ensure the specific example data lines requested are injected (matching IDs)
// T1001, C001, 2026-01-02, Rahul Mehta, Chat, Payment, Payment Failed, High, A101, Anjali Sharma, Payments Team, 8, 3.5, 4, Met, No, Yes, No, 5, Closed, West
tickets[0] = {
  Ticket_ID: 'T1001', Customer_ID: 'C001', Ticket_Date: '2026-01-02', Customer_Name: 'Rahul Mehta',
  Support_Channel: 'Chat', Issue_Category: 'Payment', Issue_Subcategory: 'Payment Failed', Priority: 'High',
  Agent_ID: 'A101', Agent_Name: 'Anjali Sharma', Team: 'Payments Team', First_Response_Minutes: 8,
  Resolution_Hours: 3.5, SLA_Target_Hours: 4, SLA_Status: 'Met', Escalated: 'No', First_Contact_Resolution: 'Yes',
  Reopened: 'No', Customer_Satisfaction_Score: 5, Ticket_Status: 'Closed', Region: 'West'
};

// T1002, C002, 2026-01-02, Simran Kaur, Email, Refund, Refund Delayed, Medium, A102, Rohit Verma, Order Support, 45, 18, 12, Breached, Yes, No, Yes, 2, Closed, North
tickets[1] = {
  Ticket_ID: 'T1002', Customer_ID: 'C002', Ticket_Date: '2026-01-02', Customer_Name: 'Simran Kaur',
  Support_Channel: 'Email', Issue_Category: 'Refund', Issue_Subcategory: 'Refund Delayed', Priority: 'Medium',
  Agent_ID: 'A102', Agent_Name: 'Rohit Verma', Team: 'Order Support', First_Response_Minutes: 45,
  Resolution_Hours: 18, SLA_Target_Hours: 12, SLA_Status: 'Breached', Escalated: 'Yes', First_Contact_Resolution: 'No',
  Reopened: 'Yes', Customer_Satisfaction_Score: 2, Ticket_Status: 'Closed', Region: 'North'
};

// T1003, C003, 2026-01-03, Aman Patel, Phone, Technical, App Crash, Critical, A103, Priya Nair, Technical Support, 3, 5, 6, Met, No, Yes, No, 4, Closed, Central
tickets[2] = {
  Ticket_ID: 'T1003', Customer_ID: 'C003', Ticket_Date: '2026-01-03', Customer_Name: 'Aman Patel',
  Support_Channel: 'Phone', Issue_Category: 'Technical', Issue_Subcategory: 'App Crash', Priority: 'Critical',
  Agent_ID: 'A103', Agent_Name: 'Priya Nair', Team: 'Technical Support', First_Response_Minutes: 3,
  Resolution_Hours: 5, SLA_Target_Hours: 6, SLA_Status: 'Met', Escalated: 'No', First_Contact_Resolution: 'Yes',
  Reopened: 'No', Customer_Satisfaction_Score: 4, Ticket_Status: 'Closed', Region: 'Central'
};

// T1004, C004, 2026-01-03, Neha Singh, Email, Delivery, Order Delayed, High, A104, Vikas Kumar, Order Support, 60, 15, 10, Breached, Yes, No, No, 2, Closed, East
tickets[3] = {
  Ticket_ID: 'T1004', Customer_ID: 'C004', Ticket_Date: '2026-01-03', Customer_Name: 'Neha Singh',
  Support_Channel: 'Email', Issue_Category: 'Delivery', Issue_Subcategory: 'Order Delayed', Priority: 'High',
  Agent_ID: 'A104', Agent_Name: 'Vikas Kumar', Team: 'Order Support', First_Response_Minutes: 60,
  Resolution_Hours: 15, SLA_Target_Hours: 10, SLA_Status: 'Breached', Escalated: 'Yes', First_Contact_Resolution: 'No',
  Reopened: 'No', Customer_Satisfaction_Score: 2, Ticket_Status: 'Closed', Region: 'East'
};

// T1005, C005, 2026-01-04, Karan Malhotra, Chat, Account, Login Issue, Medium, A105, Sakshi Jain, Account Support, 10, 2, 8, Met, No, Yes, No, 5, Closed, South
tickets[4] = {
  Ticket_ID: 'T1005', Customer_ID: 'C005', Ticket_Date: '2026-01-04', Customer_Name: 'Karan Malhotra',
  Support_Channel: 'Chat', Issue_Category: 'Account', Issue_Subcategory: 'Login Issue', Priority: 'Medium',
  Agent_ID: 'A105', Agent_Name: 'Sakshi Jain', Team: 'Account Support', First_Response_Minutes: 10,
  Resolution_Hours: 2, SLA_Target_Hours: 8, SLA_Status: 'Met', Escalated: 'No', First_Contact_Resolution: 'Yes',
  Reopened: 'No', Customer_Satisfaction_Score: 5, Ticket_Status: 'Closed', Region: 'South'
};

// T1006, C006, 2026-01-04, Pooja Yadav, Social Media, Cancellation, Cancellation Failed, High, A106, Arjun Singh, Escalation Desk, 25, 14, 8, Breached, Yes, No, Yes, 1, Closed, Central
tickets[5] = {
  Ticket_ID: 'T1006', Customer_ID: 'C006', Ticket_Date: '2026-01-04', Customer_Name: 'Pooja Yadav',
  Support_Channel: 'Social Media', Issue_Category: 'Cancellation', Issue_Subcategory: 'Cancellation Failed', Priority: 'High',
  Agent_ID: 'A106', Agent_Name: 'Arjun Singh', Team: 'Escalation Desk', First_Response_Minutes: 25,
  Resolution_Hours: 14, SLA_Target_Hours: 8, SLA_Status: 'Breached', Escalated: 'Yes', First_Contact_Resolution: 'No',
  Reopened: 'Yes', Customer_Satisfaction_Score: 1, Ticket_Status: 'Closed', Region: 'Central'
};

// T1007, C007, 2026-01-05, Aditya Joshi, Phone, Product, Wrong Product, Medium, A104, Vikas Kumar, Order Support, 6, 7, 10, Met, No, Yes, No, 4, Closed, West
tickets[6] = {
  Ticket_ID: 'T1007', Customer_ID: 'C007', Ticket_Date: '2026-01-05', Customer_Name: 'Aditya Joshi',
  Support_Channel: 'Phone', Issue_Category: 'Product', Issue_Subcategory: 'Wrong Product', Priority: 'Medium',
  Agent_ID: 'A104', Agent_Name: 'Vikas Kumar', Team: 'Order Support', First_Response_Minutes: 6,
  Resolution_Hours: 7, SLA_Target_Hours: 10, SLA_Status: 'Met', Escalated: 'No', First_Contact_Resolution: 'Yes',
  Reopened: 'No', Customer_Satisfaction_Score: 4, Ticket_Status: 'Closed', Region: 'West'
};

// T1008, C008, 2026-01-05, Riya Kapoor, Email, Payment, Duplicate Charge, Critical, A101, Anjali Sharma, Payments Team, 20, 7, 4, Breached, Yes, No, No, 2, Closed, North
tickets[7] = {
  Ticket_ID: 'T1008', Customer_ID: 'C008', Ticket_Date: '2026-01-05', Customer_Name: 'Riya Kapoor',
  Support_Channel: 'Email', Issue_Category: 'Payment', Issue_Subcategory: 'Duplicate Charge', Priority: 'Critical',
  Agent_ID: 'A101', Agent_Name: 'Anjali Sharma', Team: 'Payments Team', First_Response_Minutes: 20,
  Resolution_Hours: 7, SLA_Target_Hours: 4, SLA_Status: 'Breached', Escalated: 'Yes', First_Contact_Resolution: 'No',
  Reopened: 'No', Customer_Satisfaction_Score: 2, Ticket_Status: 'Closed', Region: 'North'
};

// T1009, C009, 2026-01-06, Mohit Gupta, Chat, Technical, Password Reset, Low, A105, Sakshi Jain, Account Support, 5, 1, 12, Met, No, Yes, No, 5, Closed, East
tickets[8] = {
  Ticket_ID: 'T1009', Customer_ID: 'C009', Ticket_Date: '2026-01-06', Customer_Name: 'Mohit Gupta',
  Support_Channel: 'Chat', Issue_Category: 'Technical', Issue_Subcategory: 'Password Reset', Priority: 'Low',
  Agent_ID: 'A105', Agent_Name: 'Sakshi Jain', Team: 'Account Support', First_Response_Minutes: 5,
  Resolution_Hours: 1, SLA_Target_Hours: 12, SLA_Status: 'Met', Escalated: 'No', First_Contact_Resolution: 'Yes',
  Reopened: 'No', Customer_Satisfaction_Score: 5, Ticket_Status: 'Closed', Region: 'East'
};

// T1010, C010, 2026-01-06, Isha Sharma, Phone, Refund, Partial Refund, High, A102, Rohit Verma, Order Support, 12, 9, 12, Met, No, Yes, No, 4, Closed, South
tickets[9] = {
  Ticket_ID: 'T1010', Customer_ID: 'C010', Ticket_Date: '2026-01-06', Customer_Name: 'Isha Sharma',
  Support_Channel: 'Phone', Issue_Category: 'Refund', Issue_Subcategory: 'Partial Refund', Priority: 'High',
  Agent_ID: 'A102', Agent_Name: 'Rohit Verma', Team: 'Order Support', First_Response_Minutes: 12,
  Resolution_Hours: 9, SLA_Target_Hours: 12, SLA_Status: 'Met', Escalated: 'No', First_Contact_Resolution: 'Yes',
  Reopened: 'No', Customer_Satisfaction_Score: 4, Ticket_Status: 'Closed', Region: 'South'
};


// Create raw dataset with anomalies to make Python cleaning realistic
const ticketsRaw = JSON.parse(JSON.stringify(tickets));

// Inject 5 Duplicates
for (let j = 0; j < 5; j++) {
  const indexToDuplicate = j * 200 + 10;
  const duplicate = { ...ticketsRaw[indexToDuplicate] };
  // Push it right next to it or at the end
  ticketsRaw.push(duplicate);
}

// Inject some missing Customer Satisfaction Scores (e.g. 15 blank CSATs)
for (let j = 0; j < 15; j++) {
  const indexToCorrupt = j * 90 + 25;
  ticketsRaw[indexToCorrupt].Customer_Satisfaction_Score = '';
}

// Convert object array to CSV helper
function convertToCSV(arr) {
  const headers = Object.keys(arr[0]);
  const csvRows = [headers.join(',')];
  
  for (const row of arr) {
    const values = headers.map(header => {
      const val = row[header];
      const escaped = ('' + val).replace(/"/g, '\\"');
      if (typeof val === 'string' && (val.includes(',') || val.includes('\n') || val.includes('"'))) {
        return `"${escaped}"`;
      }
      return val;
    });
    csvRows.push(values.join(','));
  }
  return csvRows.join('\n');
}

// Save Raw Data CSV
fs.writeFileSync(path.join(__dirname, '../data/support_tickets_raw.csv'), convertToCSV(ticketsRaw));

// For the cleaned dataset, ensure all fields are standard. We impute missing CSAT with average (e.g., 4) or median (4).
const ticketsCleaned = JSON.parse(JSON.stringify(tickets));
// Ensure Cleaned dataset has the exact same properties as raw but standard
ticketsCleaned.forEach(t => {
  if (t.Customer_Satisfaction_Score === '') {
    t.Customer_Satisfaction_Score = 4; // imputed
  }
});
fs.writeFileSync(path.join(__dirname, '../data/support_tickets_cleaned.csv'), convertToCSV(ticketsCleaned));

// Save Cleaned dataset as a JSON module for our React application
fs.writeFileSync(path.join(__dirname, '../src/data/tickets.json'), JSON.stringify(ticketsCleaned, null, 2));

console.log('✓ Successfully generated data/support_tickets_raw.csv (1525 rows)');
console.log('✓ Successfully generated data/support_tickets_cleaned.csv (1520 rows)');
console.log('✓ Successfully generated src/data/tickets.json');

// --- Pre-calculate Summaries for Outputs Directory ---

// 1. Agent Performance Summary
const agentMap = {};
ticketsCleaned.forEach(t => {
  const id = t.Agent_ID;
  if (!agentMap[id]) {
    agentMap[id] = {
      Agent_ID: id,
      Agent_Name: t.Agent_Name,
      Team: t.Team,
      Total_Tickets: 0,
      SLA_Met: 0,
      FCR_Yes: 0,
      CSAT_Total: 0,
      CSAT_Count: 0,
      Resolution_Hours_Total: 0,
      Escalated_Yes: 0,
      Reopened_Yes: 0
    };
  }
  const stat = agentMap[id];
  stat.Total_Tickets++;
  if (t.SLA_Status === 'Met') stat.SLA_Met++;
  if (t.First_Contact_Resolution === 'Yes') stat.FCR_Yes++;
  if (t.Customer_Satisfaction_Score !== '') {
    stat.CSAT_Total += Number(t.Customer_Satisfaction_Score);
    stat.CSAT_Count++;
  }
  stat.Resolution_Hours_Total += Number(t.Resolution_Hours);
  if (t.Escalated === 'Yes') stat.Escalated_Yes++;
  if (t.Reopened === 'Yes') stat.Reopened_Yes++;
});

const agentSummary = Object.values(agentMap).map(a => {
  const slaCompliance = parseFloat(((a.SLA_Met / a.Total_Tickets) * 100).toFixed(1));
  const fcrRate = parseFloat(((a.FCR_Yes / a.Total_Tickets) * 100).toFixed(1));
  const avgCsat = parseFloat((a.CSAT_Total / (a.CSAT_Count || 1)).toFixed(2));
  const avgResolutionHours = parseFloat((a.Resolution_Hours_Total / a.Total_Tickets).toFixed(1));
  const escalationRate = parseFloat(((a.Escalated_Yes / a.Total_Tickets) * 100).toFixed(1));
  const reopenRate = parseFloat(((a.Reopened_Yes / a.Total_Tickets) * 100).toFixed(1));
  
  // Custom formula for Agent Performance Score (Weights: SLA 30%, FCR 20%, CSAT 30%, Speed 10%, Escalation 10%)
  // Normalized components:
  // - SLA: (SLA_Compliance / 100)
  // - FCR: (FCR_Rate / 100)
  // - CSAT: ((CSAT - 1) / 4)
  // - Speed: max(0, 1 - (Avg_Resolution / 24))
  // - Escalation: (1 - Escalation_Rate / 100)
  const normSla = slaCompliance / 100;
  const normFcr = fcrRate / 100;
  const normCsat = (avgCsat - 1) / 4;
  const normSpeed = Math.max(0, 1 - (avgResolutionHours / 24));
  const normEsc = 1 - (escalationRate / 100);

  const perfScore = parseFloat(((
    (normSla * 0.3) +
    (normFcr * 0.2) +
    (normCsat * 0.3) +
    (normSpeed * 0.1) +
    (normEsc * 0.1)
  ) * 100).toFixed(1));

  return {
    Agent_ID: a.Agent_ID,
    Agent_Name: a.Agent_Name,
    Team: a.Team,
    Total_Tickets: a.Total_Tickets,
    SLA_Compliance_Rate: slaCompliance,
    First_Contact_Resolution_Rate: fcrRate,
    Average_CSAT: avgCsat,
    Average_Resolution_Hours: avgResolutionHours,
    Escalation_Rate: escalationRate,
    Reopen_Rate: reopenRate,
    Performance_Score: perfScore
  };
}).sort((x, y) => y.Performance_Score - x.Performance_Score);

fs.writeFileSync(path.join(__dirname, '../outputs/agent_performance.csv'), convertToCSV(agentSummary));
console.log('✓ Successfully generated outputs/agent_performance.csv');

// 2. Category Summary
const categoryMap = {};
ticketsCleaned.forEach(t => {
  const cat = t.Issue_Category;
  if (!categoryMap[cat]) {
    categoryMap[cat] = {
      Issue_Category: cat,
      Total_Tickets: 0,
      SLA_Met: 0,
      Escalated_Count: 0,
      CSAT_Sum: 0,
      CSAT_Count: 0,
      Response_Time_Sum: 0,
      Resolution_Time_Sum: 0
    };
  }
  const stat = categoryMap[cat];
  stat.Total_Tickets++;
  if (t.SLA_Status === 'Met') stat.SLA_Met++;
  if (t.Escalated === 'Yes') stat.Escalated_Count++;
  stat.CSAT_Sum += Number(t.Customer_Satisfaction_Score);
  stat.CSAT_Count++;
  stat.Response_Time_Sum += Number(t.First_Response_Minutes);
  stat.Resolution_Time_Sum += Number(t.Resolution_Hours);
});

const categorySummary = Object.values(categoryMap).map(c => {
  return {
    Issue_Category: c.Issue_Category,
    Total_Tickets: c.Total_Tickets,
    SLA_Compliance_Rate: parseFloat(((c.SLA_Met / c.Total_Tickets) * 100).toFixed(1)),
    Escalation_Rate: parseFloat(((c.Escalated_Count / c.Total_Tickets) * 100).toFixed(1)),
    Average_CSAT: parseFloat((c.CSAT_Sum / c.CSAT_Count).toFixed(2)),
    Average_First_Response_Minutes: parseFloat((c.Response_Time_Sum / c.Total_Tickets).toFixed(1)),
    Average_Resolution_Hours: parseFloat((c.Resolution_Time_Sum / c.Total_Tickets).toFixed(1))
  };
}).sort((x, y) => y.Total_Tickets - x.Total_Tickets);

fs.writeFileSync(path.join(__dirname, '../outputs/category_summary.csv'), convertToCSV(categorySummary));
console.log('✓ Successfully generated outputs/category_summary.csv');

// 3. Monthly Summary
const monthlyMap = {};
ticketsCleaned.forEach(t => {
  // Extract month name (e.g. "January 2026")
  const dateObj = new Date(t.Ticket_Date);
  const monthNames = ["January", "February", "March", "April", "May", "June"];
  const monthName = `${monthNames[dateObj.getUTCMonth()]} 2026`;
  
  if (!monthlyMap[monthName]) {
    monthlyMap[monthName] = {
      Month: monthName,
      SortKey: dateObj.getUTCMonth(),
      Total_Tickets: 0,
      SLA_Met: 0,
      FCR_Yes: 0,
      CSAT_Sum: 0,
      CSAT_Count: 0
    };
  }
  const stat = monthlyMap[monthName];
  stat.Total_Tickets++;
  if (t.SLA_Status === 'Met') stat.SLA_Met++;
  if (t.First_Contact_Resolution === 'Yes') stat.FCR_Yes++;
  stat.CSAT_Sum += Number(t.Customer_Satisfaction_Score);
  stat.CSAT_Count++;
});

const monthlySummary = Object.values(monthlyMap)
  .sort((x, y) => x.SortKey - y.SortKey)
  .map(m => {
    return {
      Month: m.Month,
      Total_Tickets: m.Total_Tickets,
      SLA_Compliance_Rate: parseFloat(((m.SLA_Met / m.Total_Tickets) * 100).toFixed(1)),
      First_Contact_Resolution_Rate: parseFloat(((m.FCR_Yes / m.Total_Tickets) * 100).toFixed(1)),
      Average_CSAT: parseFloat((m.CSAT_Sum / m.CSAT_Count).toFixed(2))
    };
  });

fs.writeFileSync(path.join(__dirname, '../outputs/monthly_summary.csv'), convertToCSV(monthlySummary));
console.log('✓ Successfully generated outputs/monthly_summary.csv');
